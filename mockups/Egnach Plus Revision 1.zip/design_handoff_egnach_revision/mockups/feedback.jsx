// Egnach Plus — Hilfe & Rückmeldungen (2.3)
// Reusable feedback primitives: HelpButton, HelpSheet, Toast,
// ConfirmDialog and a friendly inline ErrorNote.
// All overlays render INSIDE the Phone content box (position:absolute),
// so they letterbox neatly within each mockup screen.

// ─── Shared keyframes (mounted once) ─────────────────────────
function FeedbackStyles() {
  return (
    <style>{`
      @keyframes egp-fade   { from { opacity: 0 } to { opacity: 1 } }
      @keyframes egp-sheet  { from { transform: translateY(100%) } to { transform: translateY(0) } }
      @keyframes egp-pop    { from { opacity: 0; transform: translateY(8px) scale(0.96) } to { opacity: 1; transform: translateY(0) scale(1) } }
      @keyframes egp-toast  { from { opacity: 0; transform: translateY(14px) } to { opacity: 1; transform: translateY(0) } }
    `}</style>
  );
}

// ─── Help button — the small "?" in headers ─────────────────
function HelpButton({ onClick, size = 32, tone = 'soft' }) {
  const styles = tone === 'ghost'
    ? { background: 'transparent', border: 'none', color: 'var(--ink)' }
    : { background: 'var(--surface-2)', border: '1px solid var(--line)', color: 'var(--ink-2)' };
  return (
    <button onClick={onClick} aria-label="Hilfe" style={{
      width: size, height: size, borderRadius: '50%',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', flexShrink: 0, padding: 0,
      fontFamily: 'var(--font)', fontWeight: 700, fontSize: size * 0.5,
      lineHeight: 1, ...styles,
    }}>?</button>
  );
}

// ─── Scrim ───────────────────────────────────────────────────
function Scrim({ onClick, z = 90 }) {
  return (
    <div onClick={onClick} style={{
      position: 'absolute', inset: 0, zIndex: z,
      background: 'rgba(13,22,34,0.42)',
      animation: 'egp-fade 0.18s ease both',
    }} />
  );
}

// ─── Bottom sheet (generic) ──────────────────────────────────
function Sheet({ open, onClose, children, z = 95 }) {
  if (!open) return null;
  return (
    <React.Fragment>
      <Scrim onClick={onClose} z={z - 1} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: z,
        background: 'var(--card)',
        borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
        boxShadow: '0 -10px 40px rgba(13,22,34,0.22)',
        maxHeight: '82%', display: 'flex', flexDirection: 'column',
        animation: 'egp-sheet 0.26s cubic-bezier(0.22,1,0.36,1) both',
        paddingBottom: 22,
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 4px' }}>
          <div style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--line-2)' }} />
        </div>
        {children}
      </div>
    </React.Fragment>
  );
}

// ─── Help sheet — short, friendly explanations ───────────────
// items: [{ icon, title, text }]
function HelpSheet({ open, onClose, title = 'Hilfe', intro, items = [] }) {
  return (
    <Sheet open={open} onClose={onClose}>
      <div style={{ padding: '4px 20px 0', display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{
          width: 40, height: 40, borderRadius: 12, flexShrink: 0,
          background: 'var(--primary-tint)', color: 'var(--primary)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="info" size={22} stroke={2} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'var(--ink)', letterSpacing: -0.2 }}>{title}</div>
          {intro && <div style={{ fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5, marginTop: 4 }}>{intro}</div>}
        </div>
        <button onClick={onClose} aria-label="Schliessen" style={{
          width: 30, height: 30, borderRadius: '50%', flexShrink: 0,
          border: 'none', background: 'var(--surface-2)', color: 'var(--ink-2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}><Icon name="close" size={16} /></button>
      </div>

      <div style={{ overflow: 'auto', padding: '16px 20px 4px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {items.map((it, i) => (
          <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10, flexShrink: 0,
              background: 'var(--surface-2)', color: 'var(--ink-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name={it.icon} size={17} stroke={1.9} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'var(--font)', fontSize: 13.5, fontWeight: 700, color: 'var(--ink)' }}>{it.title}</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.5, marginTop: 2 }}>{it.text}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ padding: '16px 20px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Button full size="lg" onClick={onClose}>Verstanden</Button>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)',
        }}>
          <span>Brauchst du mehr Hilfe?</span>
          <span style={{ color: 'var(--primary)', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon name="chat" size={13} stroke={2} /> Support kontaktieren
          </span>
        </div>
      </div>
    </Sheet>
  );
}

// ─── Toast — confirmation / status, friendly + simple ────────
// tone: success | error | info ; action: { label, onClick }
function Toast({ open, tone = 'success', title, msg, action, bottom = 24 }) {
  if (!open) return null;
  const tones = {
    success: { bg: '#1F8A5B', icon: 'check' },
    error:   { bg: 'var(--danger)', icon: 'warning' },
    info:    { bg: 'var(--primary)', icon: 'info' },
  };
  const c = tones[tone] || tones.success;
  return (
    <div style={{
      position: 'absolute', left: 14, right: 14, bottom, zIndex: 80,
      animation: 'egp-toast 0.3s cubic-bezier(0.22,1,0.36,1) both',
    }}>
      <div style={{
        background: 'var(--card)', borderRadius: 'var(--radius)',
        border: '1px solid var(--line)',
        boxShadow: '0 12px 32px rgba(13,22,34,0.20)',
        padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{
          width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
          background: c.bg, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name={c.icon} size={18} stroke={2.4} color="#fff" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          {title && <div style={{ fontFamily: 'var(--font)', fontSize: 13.5, fontWeight: 700, color: 'var(--ink)' }}>{title}</div>}
          {msg && <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-2)', marginTop: title ? 1 : 0, lineHeight: 1.4 }}>{msg}</div>}
        </div>
        {action && (
          <button onClick={action.onClick} style={{
            border: 'none', background: 'transparent', cursor: 'pointer', flexShrink: 0,
            fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: 'var(--primary)',
            padding: '6px 4px',
          }}>{action.label}</button>
        )}
      </div>
    </div>
  );
}

// ─── Confirm dialog — "Möchtest du wirklich …?" ──────────────
function ConfirmDialog({
  open, onCancel, onConfirm,
  tone = 'danger', icon = 'trash',
  title, body,
  cancelLabel = 'Abbrechen', confirmLabel = 'Löschen',
}) {
  if (!open) return null;
  const accent = tone === 'danger' ? 'var(--danger)' : 'var(--primary)';
  const tint   = tone === 'danger' ? '#FAE5E2' : 'var(--primary-tint)';
  return (
    <React.Fragment>
      <Scrim onClick={onCancel} z={99} />
      <div style={{
        position: 'absolute', inset: 0, zIndex: 100,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 28, pointerEvents: 'none',
      }}>
        <div style={{
          width: '100%', maxWidth: 320, background: 'var(--card)',
          borderRadius: 'var(--radius-lg)', padding: '22px 20px 18px',
          boxShadow: '0 20px 60px rgba(13,22,34,0.32)',
          pointerEvents: 'auto', textAlign: 'center',
          animation: 'egp-pop 0.22s cubic-bezier(0.22,1,0.36,1) both',
        }}>
          <div style={{
            width: 52, height: 52, borderRadius: '50%', margin: '0 auto 14px',
            background: tint, color: accent,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name={icon} size={26} stroke={2} />
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'var(--ink)', letterSpacing: -0.2, lineHeight: 1.25 }}>{title}</div>
          {body && <div style={{ fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5, marginTop: 8 }}>{body}</div>}
          <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
            <button onClick={onCancel} style={{
              flex: 1, height: 48, borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--line-2)', background: 'var(--card)', color: 'var(--ink)',
              fontFamily: 'var(--font)', fontWeight: 600, fontSize: 14, cursor: 'pointer',
            }}>{cancelLabel}</button>
            <button onClick={onConfirm} style={{
              flex: 1, height: 48, borderRadius: 'var(--radius-sm)',
              border: 'none', background: accent, color: '#fff',
              fontFamily: 'var(--font)', fontWeight: 700, fontSize: 14, cursor: 'pointer',
              boxShadow: '0 1px 2px rgba(0,0,0,0.08)',
            }}>{confirmLabel}</button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

// ─── Friendly inline error note ──────────────────────────────
// A soft, reassuring error block in plain German, with a retry action.
function ErrorNote({ title = 'Das hat leider nicht geklappt', body, retryLabel = 'Nochmals versuchen', onRetry }) {
  return (
    <div style={{
      background: '#FBEAE7', border: '1px solid #F0C8C1',
      borderRadius: 'var(--radius-sm)', padding: 14,
      display: 'flex', gap: 12, alignItems: 'flex-start',
    }}>
      <div style={{
        width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
        background: '#fff', color: 'var(--danger)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name="warning" size={18} stroke={2.2} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: '#7a1a15' }}>{title}</div>
        {body && <div style={{ fontFamily: 'var(--font)', fontSize: 12.5, color: '#8a3a33', lineHeight: 1.5, marginTop: 3 }}>{body}</div>}
        {onRetry && (
          <button onClick={onRetry} style={{
            marginTop: 10, height: 36, padding: '0 14px', borderRadius: 'var(--radius-sm)',
            border: 'none', background: 'var(--danger)', color: '#fff',
            fontFamily: 'var(--font)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer',
            display: 'inline-flex', alignItems: 'center', gap: 6,
          }}><Icon name="reload" size={14} stroke={2.2} color="#fff" /> {retryLabel}</button>
        )}
      </div>
    </div>
  );
}

Object.assign(window, {
  FeedbackStyles, HelpButton, Scrim, Sheet, HelpSheet, Toast, ConfirmDialog, ErrorNote,
});
