// Egnach Plus — Icon-Bibliothek (icon system showcase)
// Presents every category glyph grouped by area, plus a short note on how
// the icons are used. This is the reference page the team signs off on; the
// same glyphs are wired into Home, Marktplatz and Anlässe.

function M_Icons() {
  const groups = [
    {
      title: 'Anlässe',
      sub: 'Kategorie-Tags für Veranstaltungen',
      names: ['gemeinde', 'sport', 'familie', 'senioren', 'sprache', 'kultur', 'party', 'natur'],
    },
    {
      title: 'Marktplatz',
      sub: 'Inserat-Arten',
      names: ['werkzeug', 'handwerk', 'tausch', 'jobs'],
    },
    {
      title: 'Nachbarschaftshilfe',
      sub: 'Hilfe anbieten & finden',
      names: ['garten', 'eltern', 'kinder', 'tiere', 'einkauf', 'fahrdienst'],
    },
  ];
  return (
    <Screen background="var(--surface)">
      <div style={{ padding: '10px 16px 8px' }}>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: -0.4, color: 'var(--ink)' }}>Symbole</h1>
        <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)', marginTop: 3, lineHeight: 1.45 }}>
          Ein klares Symbol pro Funktion — damit man Egnach Plus auf einen Blick versteht.
        </div>
      </div>

      <Body padding="4px 0 20px">
        {groups.map((g, gi) => (
          <div key={gi} style={{ marginTop: gi === 0 ? 8 : 22 }}>
            <div style={{ padding: '0 16px 12px', display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: 'var(--ink)', letterSpacing: 0.6, textTransform: 'uppercase' }}>{g.title}</span>
              <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>· {g.sub}</span>
            </div>
            <div style={{
              padding: '0 16px',
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
              rowGap: 18, columnGap: 8, justifyItems: 'center',
            }}>
              {g.names.map((n) => <CatTile key={n} name={n} size={60} />)}
            </div>
          </div>
        ))}

        {/* Usage note: chips */}
        <div style={{ padding: '24px 16px 0' }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: 'var(--ink)', letterSpacing: 0.6, textTransform: 'uppercase', marginBottom: 12 }}>Als Tag verwendet</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <CatChip name="sport" />
            <CatChip name="familie" />
            <CatChip name="senioren" />
            <CatChip name="sprache" />
            <CatChip name="party" />
            <CatChip name="garten" />
          </div>
        </div>
      </Body>
    </Screen>
  );
}

Object.assign(window, { M_Icons });
