// Egnach Plus — Mockup theme + design tokens
// All visual tokens flow as CSS variables on a single root wrapper.
// Tweaks mutate the tokens; every component reads via var(--…).

const PALETTES = {
  egnach: {
    label: 'Egnach Wappen',
    primary: '#009944',     // heraldic green (tree)
    primaryTint: '#E0F2E7',
    primaryInk: '#00391A',
    accent: '#0093DD',      // heraldic blue (Bodensee water)
    accentTint: '#D6EFFA',
  },
  bodensee: {
    label: 'Bodensee',
    primary: '#2563A8',   // lake blue
    primaryTint: '#E6EFF8',
    primaryInk: '#0E2A47',
    accent: '#D97757',    // warm coral
    accentTint: '#FBEBE0',
  },
  alpenwiese: {
    label: 'Alpenwiese',
    primary: '#3E7C4A',   // meadow green
    primaryTint: '#E6EFE7',
    primaryInk: '#1B3D24',
    accent: '#C18A2B',    // wheat
    accentTint: '#F6ECD7',
  },
  apfelblust: {
    label: 'Apfelblüst',
    primary: '#B0436B',   // apple blossom rose
    primaryTint: '#F6E4EB',
    primaryInk: '#4A1A2A',
    accent: '#3E7C4A',
    accentTint: '#E6EFE7',
  },
  monolith: {
    label: 'Monolith',
    primary: '#1F2933',
    primaryTint: '#EDEEF0',
    primaryInk: '#0B1116',
    accent: '#D97757',
    accentTint: '#FBEBE0',
  },
};

const FONTS = {
  inter:   { label: 'Inter',         stack: "'Inter', system-ui, sans-serif" },
  manrope: { label: 'Manrope',       stack: "'Manrope', system-ui, sans-serif" },
  dmsans:  { label: 'DM Sans',       stack: "'DM Sans', system-ui, sans-serif" },
  ibmplex: { label: 'IBM Plex Sans', stack: "'IBM Plex Sans', system-ui, sans-serif" },
};

const DISPLAY_FONTS = {
  same:    { label: 'Same as body', stack: null },
  fraunces:{ label: 'Fraunces',     stack: "'Fraunces', Georgia, serif" },
  space:   { label: 'Space Grotesk',stack: "'Space Grotesk', system-ui, sans-serif" },
  dmserif: { label: 'DM Serif',     stack: "'DM Serif Display', Georgia, serif" },
};

// Density multiplies vertical paddings; corner radius is a slider.
const DENSITY = { compact: 0.85, regular: 1.0, comfy: 1.15 };

function buildCssVars({ palette, font, displayFont, radius, density, dark }) {
  const p = PALETTES[palette] || PALETTES.egnach;
  const f = FONTS[font] || FONTS.inter;
  const d = DISPLAY_FONTS[displayFont] || DISPLAY_FONTS.same;
  const dm = DENSITY[density] ?? 1;

  // light defaults
  let ink = '#15202D';
  let ink2 = '#5A6478';
  let ink3 = '#8B93A4';
  let surface = '#FBFAF7';
  let surface2 = '#F3F0E9';
  let surface3 = '#ECE8DE';
  let line = '#E4E0D5';
  let line2 = '#CFC9BB';
  let card = '#FFFFFF';

  if (dark) {
    ink = '#F1ECE2';
    ink2 = '#A8B0C0';
    ink3 = '#6E7588';
    surface = '#0F1620';
    surface2 = '#181F2A';
    surface3 = '#222B38';
    line = '#28323F';
    line2 = '#3A4654';
    card = '#141B25';
  }

  return {
    '--primary': p.primary,
    '--primary-tint': p.primaryTint,
    '--primary-ink': p.primaryInk,
    '--accent': p.accent,
    '--accent-tint': p.accentTint,
    '--ink': ink,
    '--ink-2': ink2,
    '--ink-3': ink3,
    '--surface': surface,
    '--surface-2': surface2,
    '--surface-3': surface3,
    '--card': card,
    '--line': line,
    '--line-2': line2,
    '--success': '#1F8A5B',
    '--danger': '#C84B3F',
    '--warning': '#C9892A',
    // Heraldic palette of Egnach — always available regardless of active brand palette.
    '--heraldic-green': '#009944',
    '--heraldic-blue':  '#0093DD',
    '--heraldic-red':   '#E60000',
    '--radius': radius + 'px',
    '--radius-sm': Math.max(4, radius - 6) + 'px',
    '--radius-lg': (radius + 8) + 'px',
    '--font': f.stack,
    '--font-display': d.stack || f.stack,
    '--density': String(dm),
  };
}

// Helpful: a tiny tint-on-primary helper for chips/badges using rgba.
// (Tweakable palettes ship a tint already; this is for ad-hoc cases.)
function rgba(hex, a) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

Object.assign(window, { PALETTES, FONTS, DISPLAY_FONTS, DENSITY, buildCssVars, rgba });
