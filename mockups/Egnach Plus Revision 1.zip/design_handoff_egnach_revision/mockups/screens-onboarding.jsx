// Egnach Plus — Onboarding · Neue Version (ISO 9241-110 · 2.1 + 3.4)
// Kürzer, symbolstark, weniger Text. Jeder Schritt zeigt EIN grosses
// Symbol und nur wenige, einfache Worte — gut für ältere Personen und
// Menschen mit weniger Deutschkenntnissen.

// ─── Grosses Symbol im farbigen Kreis ────────────────────────
function BigGlyph({ glyph, icon, bg, ink, size = 132 }) {
  const is = Math.round(size * 0.46);
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      background: bg, color: ink,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 10px 30px rgba(13,22,34,0.10)',
    }}>
      {glyph
        ? <CatGlyph name={glyph} size={is} stroke={1.8} color={ink} />
        : <Icon name={icon} size={is} stroke={1.7} color={ink} />}
    </div>
  );
}

// ─── Ein Onboarding-Schritt ──────────────────────────────────
// Bild oben (grosses Symbol auf Farbfläche), darunter sehr kurzer Text.
function OnbStep({ step, total, tint, glyph, icon, bg, ink, title, line, cta = 'Weiter' }) {
  return (
    <Screen background="var(--surface)">
      <div style={{ padding: '12px 20px 0', display: 'flex', justifyContent: 'flex-end' }}>
        <span style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 600, color: 'var(--ink-3)' }}>Überspringen</span>
      </div>

      {/* Grosse Bildfläche mit einem klaren Symbol */}
      <div style={{ padding: '8px 24px 0' }}>
        <div style={{
          height: 248, borderRadius: 24, background: tint,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          border: '1px solid var(--line)',
        }}>
          <BigGlyph glyph={glyph} icon={icon} bg={bg} ink={ink} />
        </div>
      </div>

      {/* Sehr kurzer Text */}
      <div style={{ flex: 1, padding: '26px 28px 0', textAlign: 'center' }}>
        <h2 style={{
          margin: '0 0 10px', fontFamily: 'var(--font-display)',
          fontSize: 28, lineHeight: 1.12, fontWeight: 700, letterSpacing: -0.5, color: 'var(--ink)',
        }}>{title}</h2>
        <p style={{
          margin: '0 auto', maxWidth: 256, fontFamily: 'var(--font)',
          fontSize: 16, lineHeight: 1.5, color: 'var(--ink-2)',
        }}>{line}</p>
      </div>

      <div style={{ padding: '18px 24px 28px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <Dots count={total} active={step} accent="var(--primary)" />
        <Button full size="lg" trailing={<Icon name="arrowSmall" size={18} color="#fff" stroke={2.2}/>}>{cta}</Button>
      </div>
    </Screen>
  );
}

// 02 · Schritt 1 — Nachbarschaftshilfe
function M02_OnbV2_Help() {
  return (
    <OnbStep step={0} total={3} tint="#EFF3E2"
      glyph="garten" bg="#E8EBD2" ink="#6C792D"
      title="Hilf mit. Lass dir helfen."
      line="Garten, Einkauf, Fahrdienst – Nachbarn für Nachbarn." />
  );
}

// 02b · Schritt 2 — Marktplatz / Leihen
function M02_OnbV2_Lend() {
  return (
    <OnbStep step={1} total={3} tint="#ECEFF3"
      glyph="werkzeug" bg="#E3E6EB" ink="#536078"
      title="Leihen statt kaufen."
      line="Werkzeug, Dinge und Dienste – direkt aus dem Dorf." />
  );
}

// 02c · Schritt 3 — Anlässe
function M02_OnbV2_Events() {
  return (
    <OnbStep step={2} total={3} tint="#FBEFE0"
      glyph="party" bg="#F4DEE6" ink="#AE4269"
      title="Sei dabei."
      line="Alle Anlässe von Gemeinde und Vereinen an einem Ort."
      cta="Los geht's" />
  );
}

// 02d · Übersicht — grosses Symbol-Raster, fast ohne Text
function M02_OnbV2_Overview() {
  const tiles = [
    { glyph: 'party',    label: 'Anlässe',  bg: '#F4DEE6', ink: '#AE4269' },
    { glyph: 'werkzeug', label: 'Leihen',   bg: '#E3E6EB', ink: '#536078' },
    { glyph: 'garten',   label: 'Helfen',   bg: '#E8EBD2', ink: '#6C792D' },
    { icon:  'map',      label: 'Karte',    bg: '#DBEAF4', ink: '#2E6CA8' },
  ];
  return (
    <Screen background="var(--surface)">
      <div style={{ padding: '32px 28px 4px', textAlign: 'center' }}>
        <Mark size={56} variant="wappen" />
        <h2 style={{
          margin: '16px 0 6px', fontFamily: 'var(--font-display)',
          fontSize: 26, lineHeight: 1.12, fontWeight: 700, letterSpacing: -0.5, color: 'var(--ink)',
        }}>Das kannst du tun</h2>
        <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 15, color: 'var(--ink-2)' }}>
          Tippe auf ein Symbol.
        </p>
      </div>

      <div style={{ flex: 1, padding: '22px 24px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {tiles.map((t, i) => (
            <div key={i} style={{
              borderRadius: 20, border: '1px solid var(--line)', background: 'var(--card)',
              padding: '20px 12px 16px', display: 'flex', flexDirection: 'column',
              alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 76, height: 76, borderRadius: '50%',
                background: t.bg, color: t.ink,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {t.glyph
                  ? <CatGlyph name={t.glyph} size={38} stroke={1.8} color={t.ink} />
                  : <Icon name={t.icon} size={38} stroke={1.7} color={t.ink} />}
              </div>
              <span style={{ fontFamily: 'var(--font)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>{t.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '20px 24px 28px' }}>
        <Button full size="lg">Loslegen</Button>
      </div>
    </Screen>
  );
}

Object.assign(window, {
  M02_OnbV2_Help, M02_OnbV2_Lend, M02_OnbV2_Events, M02_OnbV2_Overview,
});
