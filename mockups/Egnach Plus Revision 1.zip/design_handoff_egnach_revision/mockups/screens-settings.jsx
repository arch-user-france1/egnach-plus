// Egnach Plus — Einstellungen · Individualisierbarkeit (3.7)
// Interaktive Ansicht: Einfach-Modus, Schriftgrösse (mit Live-Vorschau),
// Benachrichtigungen granular ein/aus, Datenschutz-Optionen.
// Alle Steuerungen sind echt bedienbar (React-State).

// ─── Interaktiver Schalter ───────────────────────────────────
function FlipSwitch({ on, onClick, size = 'md' }) {
  const w = size === 'sm' ? 38 : 50;
  const h = size === 'sm' ? 23 : 30;
  const k = h - 6;
  return (
    <button onClick={onClick} role="switch" aria-checked={on} style={{
      width: w, height: h, borderRadius: h / 2, border: 'none', padding: 0,
      flexShrink: 0, cursor: 'pointer', position: 'relative',
      background: on ? 'var(--primary)' : 'var(--line-2)',
      transition: 'background 0.2s ease',
    }}>
      <span style={{
        position: 'absolute', top: 3, left: on ? w - k - 3 : 3,
        width: k, height: k, borderRadius: '50%', background: '#fff',
        boxShadow: '0 1px 3px rgba(0,0,0,0.25)', transition: 'left 0.2s cubic-bezier(0.22,1,0.36,1)',
      }} />
    </button>
  );
}

// ─── Zeile mit Schalter ──────────────────────────────────────
function ToggleRow({ icon, label, hint, on, onToggle, last, scale = 1, disabled }) {
  return (
    <div style={{
      padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
      borderBottom: last ? 'none' : '1px solid var(--line)',
      opacity: disabled ? 0.45 : 1,
    }}>
      <div style={{
        width: 34, height: 34, borderRadius: 9, flexShrink: 0,
        background: 'var(--surface-2)', color: 'var(--ink-2)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}><Icon name={icon} size={17} stroke={1.9} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font)', fontSize: 15 * scale, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.25 }}>{label}</div>
        {hint && <div style={{ fontFamily: 'var(--font)', fontSize: 12 * scale, color: 'var(--ink-3)', marginTop: 2, lineHeight: 1.35 }}>{hint}</div>}
      </div>
      <FlipSwitch on={on} onClick={disabled ? undefined : onToggle} />
    </div>
  );
}

// ─── Auswahlzeile (Radio-Stil) ───────────────────────────────
function ChoiceRow({ icon, label, value, options, onPick, last, scale = 1 }) {
  return (
    <div style={{
      padding: '12px 16px', borderBottom: last ? 'none' : '1px solid var(--line)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <div style={{
          width: 34, height: 34, borderRadius: 9, flexShrink: 0,
          background: 'var(--surface-2)', color: 'var(--ink-2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon name={icon} size={17} stroke={1.9} /></div>
        <div style={{ fontFamily: 'var(--font)', fontSize: 15 * scale, fontWeight: 600, color: 'var(--ink)' }}>{label}</div>
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        {options.map((o) => {
          const active = o === value;
          return (
            <button key={o} onClick={() => onPick(o)} style={{
              flex: 1, height: 38, borderRadius: 'var(--radius-sm)', cursor: 'pointer',
              border: `1.5px solid ${active ? 'var(--primary)' : 'var(--line)'}`,
              background: active ? 'var(--primary-tint)' : 'var(--card)',
              color: active ? 'var(--primary-ink)' : 'var(--ink-2)',
              fontFamily: 'var(--font)', fontSize: 13 * scale, fontWeight: active ? 700 : 500,
            }}>{o}</button>
          );
        })}
      </div>
    </div>
  );
}

const SectionLabel = ({ children, scale = 1 }) => (
  <div style={{ padding: '20px 18px 8px', fontFamily: 'var(--font)', fontSize: 11 * scale, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1 }}>{children}</div>
);

// ─── 14 · Einstellungen ──────────────────────────────────────
function M14_Settings({ defaultSimple = false } = {}) {
  const [help, setHelp]   = React.useState(false);
  const [toast, setToast] = React.useState(false);
  React.useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(false), 3200); return () => clearTimeout(id); }, [toast]);

  const FONT = { 'Klein': 0.9, 'Normal': 1, 'Gross': 1.15, 'Sehr gross': 1.32 };
  const [simple, setSimple]   = React.useState(defaultSimple);
  const [fontSize, setFont]   = React.useState(defaultSimple ? 'Gross' : 'Normal');
  const [notifAll, setNotifAll] = React.useState(true);
  const [nMsg, setNMsg]       = React.useState(true);
  const [nEvents, setNEvents] = React.useState(true);
  const [nMarket, setNMarket] = React.useState(false);
  const [nDigest, setNDigest] = React.useState(true);
  const [profilePublic, setProfilePublic] = React.useState('Verifizierte');
  const [location, setLocation] = React.useState('Ungefähr');
  const [readReceipts, setReadReceipts] = React.useState(true);

  const s = FONT[fontSize]; // global Schrift-Skalierung für Live-Vorschau

  return (
    <React.Fragment>
    <Screen background="var(--surface)">
      <TopBar
        leading={<IconButton name="back" />}
        title="Einstellungen"
        trailing={<HelpButton onClick={() => setHelp(true)} />}
      />

      <Body padding="0 0 28px">
        {/* Einfach-Modus — prominent */}
        <div style={{ padding: '14px 16px 4px' }}>
          <div style={{
            borderRadius: 'var(--radius)', padding: 16,
            background: simple ? 'var(--primary-tint)' : 'var(--card)',
            border: `1.5px solid ${simple ? 'var(--primary)' : 'var(--line)'}`,
            display: 'flex', alignItems: 'center', gap: 14,
            transition: 'background 0.2s ease, border-color 0.2s ease',
          }}>
            <div style={{
              width: 46, height: 46, borderRadius: 13, flexShrink: 0,
              background: simple ? 'var(--primary)' : 'var(--surface-2)',
              color: simple ? '#fff' : 'var(--ink-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon name="paws" size={24} stroke={1.8} color={simple ? '#fff' : undefined} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 17 * s, fontWeight: 700, color: 'var(--ink)', letterSpacing: -0.2 }}>Einfach-Modus</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 12.5 * s, color: 'var(--ink-2)', lineHeight: 1.4, marginTop: 2 }}>
                Grössere Knöpfe, weniger Funktionen und nur das Wichtigste.
              </div>
            </div>
            <FlipSwitch on={simple} onClick={() => setSimple(v => !v)} />
          </div>
          {simple && (
            <div style={{
              marginTop: 8, padding: '10px 14px', borderRadius: 'var(--radius-sm)',
              background: 'var(--surface-2)', display: 'flex', alignItems: 'center', gap: 8,
              fontFamily: 'var(--font)', fontSize: 12.5 * s, color: 'var(--ink-2)', lineHeight: 1.4,
            }}>
              <Icon name="check" size={15} stroke={2.4} color="var(--primary)" />
              Einfach-Modus ist an. Erweiterte Optionen sind ausgeblendet.
            </div>
          )}
        </div>

        {/* Schriftgrösse — mit Live-Vorschau */}
        <SectionLabel scale={s}>ANSICHT</SectionLabel>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <div style={{ padding: '14px 16px 12px', borderBottom: '1px solid var(--line)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <div style={{
                width: 34, height: 34, borderRadius: 9, flexShrink: 0,
                background: 'var(--surface-2)', color: 'var(--ink-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}><span style={{ fontFamily: 'var(--font)', fontWeight: 800, fontSize: 16, color: 'var(--ink-2)' }}>A</span></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font)', fontSize: 15 * s, fontWeight: 600, color: 'var(--ink)' }}>Schriftgrösse</div>
                <div style={{ fontFamily: 'var(--font)', fontSize: 12 * s, color: 'var(--ink-3)', marginTop: 1 }}>{fontSize}</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'flex-end' }}>
              {Object.keys(FONT).map((label, i) => {
                const active = label === fontSize;
                return (
                  <button key={label} onClick={() => setFont(label)} style={{
                    flex: 1, height: 44, borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                    border: `1.5px solid ${active ? 'var(--primary)' : 'var(--line)'}`,
                    background: active ? 'var(--primary-tint)' : 'var(--card)',
                    color: active ? 'var(--primary-ink)' : 'var(--ink-2)',
                    fontFamily: 'var(--font)', fontWeight: active ? 800 : 600,
                    fontSize: 12 + i * 3, lineHeight: 1,
                  }}>A</button>
                );
              })}
            </div>
            {/* Live-Vorschau */}
            <div style={{
              marginTop: 12, padding: '12px 14px', borderRadius: 'var(--radius-sm)',
              background: 'var(--surface-2)', border: '1px solid var(--line)',
            }}>
              <div style={{ fontFamily: 'var(--font)', fontSize: 10.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 0.8, marginBottom: 4 }}>VORSCHAU</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 15 * s, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3 }}>Grüezi Anna!</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 13 * s, color: 'var(--ink-2)', lineHeight: 1.4, marginTop: 2 }}>So gross erscheint der Text in der App.</div>
            </div>
          </div>
          <ToggleRow icon="image" label="Hoher Kontrast" hint="Stärkere Farben für bessere Lesbarkeit" on={false} onToggle={() => {}} scale={s} last />
        </Card>

        {/* Benachrichtigungen */}
        <SectionLabel scale={s}>BENACHRICHTIGUNGEN</SectionLabel>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <ToggleRow icon="bell" label="Benachrichtigungen" hint={notifAll ? 'An – du wirst informiert' : 'Aus – du bekommst keine Meldungen'} on={notifAll} onToggle={() => setNotifAll(v => !v)} scale={s} last={!notifAll || simple} />
          {notifAll && !simple && (
            <React.Fragment>
              <ToggleRow icon="chat"     label="Nachrichten" on={nMsg}    onToggle={() => setNMsg(v => !v)}    scale={s} />
              <ToggleRow icon="calendar" label="Anlässe in der Nähe" on={nEvents} onToggle={() => setNEvents(v => !v)} scale={s} />
              <ToggleRow icon="store"    label="Marktplatz-Antworten" on={nMarket} onToggle={() => setNMarket(v => !v)} scale={s} />
              <ToggleRow icon="log"      label="Wochenübersicht" hint="Eine Zusammenfassung am Sonntag" on={nDigest} onToggle={() => setNDigest(v => !v)} scale={s} last />
            </React.Fragment>
          )}
        </Card>

        {/* Datenschutz */}
        <SectionLabel scale={s}>DATENSCHUTZ</SectionLabel>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <ChoiceRow icon="user" label="Mein Profil sehen" value={profilePublic}
            options={['Alle', 'Verifizierte', 'Niemand']} onPick={setProfilePublic} scale={s} />
          <ChoiceRow icon="pin" label="Mein Standort" value={location}
            options={['Genau', 'Ungefähr', 'Aus']} onPick={setLocation} scale={s} last={simple} />
          {!simple && (
            <ToggleRow icon="check" label="Lesebestätigungen" hint="Andere sehen, wann du gelesen hast" on={readReceipts} onToggle={() => setReadReceipts(v => !v)} scale={s} last />
          )}
        </Card>

        {!simple && (
          <div style={{ padding: '14px 18px 0', display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--font)', fontSize: 12 * s, color: 'var(--ink-3)' }}>
            <Icon name="lock" size={13} stroke={2} />
            Deine Daten bleiben bei der Gemeinde Egnach.
          </div>
        )}

        <div style={{ padding: '18px 16px 0' }}>
          <Button full size="lg" onClick={() => setToast(true)}>Speichern</Button>
        </div>
      </Body>

      <TabBar active={4} />
    </Screen>

    <Toast open={toast} tone="success"
      title="Einstellungen gespeichert"
      msg="Deine Anpassungen gelten ab sofort in der ganzen App."
      bottom={92} />

    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="App an dich anpassen"
      intro="Stelle die App so ein, wie es für dich am besten passt. Du kannst alles jederzeit ändern."
      items={[
        { icon: 'paws', title: 'Einfach-Modus', text: 'Blendet erweiterte Optionen aus und zeigt grössere Knöpfe – ideal, wenn du es übersichtlich magst.' },
        { icon: 'info', title: 'Schriftgrösse', text: 'Wähle, wie gross der Text sein soll. Die Vorschau zeigt dir sofort, wie es aussieht.' },
        { icon: 'bell', title: 'Weniger Meldungen', text: 'Schalte einzelne Benachrichtigungen aus, wenn du nur das Wichtigste sehen möchtest.' },
        { icon: 'lock', title: 'Datenschutz', text: 'Bestimme, wer dein Profil sieht und wie genau dein Standort geteilt wird.' },
      ]} />
    </React.Fragment>
  );
}

Object.assign(window, { M14_Settings });
