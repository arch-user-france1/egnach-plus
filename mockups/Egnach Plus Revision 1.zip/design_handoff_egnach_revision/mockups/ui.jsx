// Egnach Plus — Mockup UI primitives
// Branded, hi-fi versions of the wireframe primitives.
// All colors via CSS vars from theme.jsx.

// ─── Icon library ────────────────────────────────────────────
// Small line icons, 24×24 viewBox, current stroke colour.
const ICON_PATHS = {
  search:    'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14Zm5.3 11.3 4.2 4.2',
  bell:      'M6 16V11a6 6 0 0 1 12 0v5l1.5 2H4.5L6 16Zm4 4a2 2 0 0 0 4 0',
  user:      'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8a7 7 0 0 1 14 0',
  chat:      'M4 5h16v11H8l-4 4V5Z',
  home:      'M3 11 12 4l9 7v9h-6v-6H9v6H3v-9Z',
  store:     'M4 9h16l-1 11H5L4 9Zm0 0 1.5-4h13L20 9M9 13a3 3 0 0 0 6 0',
  calendar:  'M5 6h14v14H5V6Zm0 4h14M9 3v4m6-4v4',
  map:       'M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Zm0 0v14m6-14v14',
  pin:       'M12 22s7-7.6 7-13a7 7 0 1 0-14 0c0 5.4 7 13 7 13Zm0-10a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  back:      'M14 5l-7 7 7 7',
  chevron:   'M9 5l7 7-7 7',
  chevronDown:'M5 9l7 7 7-7',
  close:     'M6 6l12 12M18 6 6 18',
  plus:      'M12 5v14M5 12h14',
  send:      'M3 12 21 4 15 21l-3-8-9-1Z',
  filter:    'M4 6h16M7 12h10m-7 6h4',
  options:   'M12 6h.01M12 12h.01M12 18h.01',
  share:     'M4 12v7h16v-7M12 3v12m0-12-4 4m4-4 4 4',
  heart:     'M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.7A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z',
  check:     'M4 12l5 5 11-11',
  globe:     'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm0 0c3 3 3 15 0 18M3 12h18M5 7h14M5 17h14',
  shield:    'M12 3 4 6v6c0 5 4 8 8 9 4-1 8-4 8-9V6l-8-3Z',
  camera:    'M4 8h4l1-2h6l1 2h4v11H4V8Zm8 2.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z',
  image:     'M4 5h16v14H4V5Zm0 11 5-5 4 4 3-3 4 4',
  star:      'M12 4l2.6 5.4 5.9.8-4.3 4 1 5.8L12 17.3 6.8 20l1-5.8-4.3-4 5.9-.8L12 4Z',
  arrow:     'M5 12h14m-5-5 5 5-5 5',
  arrowSmall:'M4 12h12m-3-3 3 3-3 3',
  info:      'M12 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm0 7v6m0-9v.01',
  lock:      'M6 11h12v9H6v-9Zm2 0V8a4 4 0 0 1 8 0v3',
  euro:      'M16 6a6 6 0 1 0 0 12M4 10h7M4 14h7',
  swiss:     'M9 4h6v5h5v6h-5v5H9v-5H4V9h5V4Z',
  briefcase: 'M4 8h16v12H4V8Zm5 0V5h6v3M4 13h16',
  car:       'M5 13l2-6h10l2 6v4h-2v2h-2v-2H9v2H7v-2H5v-4Zm2 0h10',
  language:  'M3 6h10M8 4v2c0 5-2.5 9-5 11m2-7c1 2 3 4 7 5M14 20l4-9 4 9m-7-2h6',
  qr:        'M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h2v2h-2v-2Zm4 0h2v2h-2v-2Zm-4 4h2v2h-2v-2Zm4 0h2v2h-2v-2Z',
  fingerprint:'M12 4a8 8 0 0 0-8 8m4 8a8 8 0 0 1 0-12m4 14a4 4 0 0 0 0-12m4 12a8 8 0 0 0 0-12',
  paperclip: 'M18 7 9 16a3 3 0 0 0 4 4l9-9a5 5 0 0 0-7-7L5 14a7 7 0 0 0 10 10',
  mic:       'M12 4a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V7a3 3 0 0 0-3-3Zm-6 8a6 6 0 0 0 12 0M12 18v3',
  edit:      'M4 20h4l11-11-4-4L4 16v4Zm10-13 4 4',
  log:       'M5 5h14v14H5V5Zm3 4h8M8 12h8M8 15h5',
  trash:     'M5 7h14M9 7V5h6v2m-7 0 1 13h8l1-13',
  pause:     'M9 5v14m6-14v14',
  play:      'M7 5l11 7-11 7V5Z',
  warning:   'M12 4 3 20h18L12 4Zm0 6v5m0 2v.01',
  reload:    'M4 12a8 8 0 0 1 14-5l2-2m0 7V5M20 12a8 8 0 0 1-14 5l-2 2m0-7v7',
  paws:      'M6 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM9 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm6 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm-3 7c-3 0-5-2-5-4 0-1.5 2-3 5-3s5 1.5 5 3-2 4-5 4Z',
};

function Icon({ name, size = 20, stroke = 1.6, color = 'currentColor' }) {
  const d = ICON_PATHS[name];
  if (!d) return <div style={{ width: size, height: size, border: '1px dashed currentColor', opacity: 0.4 }} />;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
         stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
         style={{ flexShrink: 0 }}>
      <path d={d} />
    </svg>
  );
}

// ─── Button ──────────────────────────────────────────────────
function Button({
  children, variant = 'primary', size = 'md', full = false,
  leading, trailing, onClick, style,
}) {
  const heights = { sm: 36, md: 44, lg: 52 };
  const pad = { sm: '0 14px', md: '0 18px', lg: '0 22px' };
  const fs = { sm: 13, md: 14, lg: 15 };
  const isPrimary = variant === 'primary';
  const isGhost = variant === 'ghost';
  const isOutline = variant === 'outline';
  const isAccent = variant === 'accent';
  const isDanger = variant === 'danger';

  let bg = 'var(--primary)';
  let fg = '#fff';
  let border = 'transparent';
  if (isGhost)    { bg = 'transparent'; fg = 'var(--ink)'; border = 'transparent'; }
  if (isOutline)  { bg = 'transparent'; fg = 'var(--ink)'; border = 'var(--line-2)'; }
  if (isAccent)   { bg = 'var(--accent)'; fg = '#fff'; }
  if (isDanger)   { bg = 'transparent'; fg = 'var(--danger)'; border = 'transparent'; }

  return (
    <button onClick={onClick} style={{
      height: heights[size], padding: pad[size],
      width: full ? '100%' : undefined,
      borderRadius: 'var(--radius-sm)',
      background: bg, color: fg, border: `1px solid ${border}`,
      fontFamily: 'var(--font)', fontWeight: 600, fontSize: fs[size],
      letterSpacing: 0.1,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      cursor: 'pointer', boxShadow: isPrimary ? '0 1px 1px rgba(0,0,0,0.06)' : 'none',
      ...style,
    }}>
      {leading}
      <span>{children}</span>
      {trailing}
    </button>
  );
}

// ─── Chip / Pill ─────────────────────────────────────────────
function Chip({ children, active = false, leading, onClick, size = 'md', tone = 'default' }) {
  const h = size === 'sm' ? 24 : 30;
  const fs = size === 'sm' ? 11 : 12;
  let bg = active ? 'var(--ink)' : 'var(--card)';
  let fg = active ? 'var(--surface)' : 'var(--ink)';
  let bd = active ? 'var(--ink)' : 'var(--line)';
  if (tone === 'soft') { bg = 'var(--surface-2)'; bd = 'transparent'; fg = 'var(--ink-2)'; }
  if (tone === 'primary' && !active) { bg = 'var(--primary-tint)'; bd = 'transparent'; fg = 'var(--primary-ink)'; }
  if (tone === 'accent' && !active) { bg = 'var(--accent-tint)'; bd = 'transparent'; fg = '#7a3318'; }
  return (
    <button onClick={onClick} style={{
      height: h, padding: leading ? '0 12px 0 10px' : '0 12px',
      borderRadius: 999, background: bg, color: fg,
      border: `1px solid ${bd}`,
      fontFamily: 'var(--font)', fontSize: fs, fontWeight: 500,
      display: 'inline-flex', alignItems: 'center', gap: 6,
      flexShrink: 0, cursor: 'pointer', letterSpacing: 0.1,
    }}>
      {leading}
      {children}
    </button>
  );
}

// ─── Badge ───────────────────────────────────────────────────
function Badge({ children, tone = 'primary', size = 'md' }) {
  const h = size === 'sm' ? 18 : 22;
  let bg = 'var(--primary-tint)', fg = 'var(--primary-ink)';
  if (tone === 'accent')  { bg = 'var(--accent-tint)'; fg = '#7a3318'; }
  if (tone === 'success') { bg = '#E1F1E7';            fg = '#155E3E'; }
  if (tone === 'neutral') { bg = 'var(--surface-2)';   fg = 'var(--ink-2)'; }
  if (tone === 'danger')  { bg = '#FAE5E2';            fg = '#7a1a15'; }
  return (
    <span style={{
      height: h, padding: '0 8px', borderRadius: 999,
      background: bg, color: fg,
      fontFamily: 'var(--font)', fontSize: size === 'sm' ? 10 : 11, fontWeight: 600,
      display: 'inline-flex', alignItems: 'center', gap: 4, letterSpacing: 0.2,
    }}>{children}</span>
  );
}

// ─── Field ───────────────────────────────────────────────────
function Field({
  label, value, placeholder, required, hint, error,
  type = 'text', leading, trailing, multiline = false, rows = 3,
}) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{
          fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600,
          color: 'var(--ink)', letterSpacing: 0.1,
        }}>{label}</span>
        {required && <span style={{ color: 'var(--danger)', fontSize: 12 }}>*</span>}
      </span>
      <div style={{
        minHeight: multiline ? rows * 22 + 18 : 46,
        borderRadius: 'var(--radius-sm)',
        background: 'var(--card)',
        border: `1px solid ${error ? 'var(--danger)' : 'var(--line)'}`,
        padding: multiline ? '12px 14px' : '0 14px',
        display: 'flex', alignItems: multiline ? 'flex-start' : 'center', gap: 10,
        fontFamily: 'var(--font)', fontSize: 14,
        color: value ? 'var(--ink)' : 'var(--ink-3)',
        boxShadow: error ? '0 0 0 3px rgba(200,75,63,0.10)' : 'none',
      }}>
        {leading}
        <span style={{ flex: 1, lineHeight: multiline ? 1.5 : 'normal' }}>
          {value || placeholder || ' '}
        </span>
        {trailing}
      </div>
      {hint && !error && (
        <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>{hint}</span>
      )}
      {error && (
        <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--danger)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <Icon name="warning" size={12} stroke={2}/>
          {error}
        </span>
      )}
    </label>
  );
}

// ─── Switch ──────────────────────────────────────────────────
function Switch({ on = false, size = 'md' }) {
  const w = size === 'sm' ? 36 : 44;
  const h = size === 'sm' ? 22 : 26;
  const k = h - 4;
  return (
    <div style={{
      width: w, height: h, borderRadius: 999,
      background: on ? 'var(--primary)' : 'var(--surface-3)',
      position: 'relative', transition: 'background 0.2s',
      flexShrink: 0,
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? w - k - 2 : 2,
        width: k, height: k, borderRadius: '50%',
        background: '#fff',
        boxShadow: '0 1px 2px rgba(0,0,0,0.18)',
        transition: 'left 0.2s',
      }} />
    </div>
  );
}

// ─── Checkbox ────────────────────────────────────────────────
function Checkbox({ on = false, size = 18 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 5,
      background: on ? 'var(--primary)' : 'var(--card)',
      border: `1.5px solid ${on ? 'var(--primary)' : 'var(--line-2)'}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      {on && <Icon name="check" size={size - 6} color="#fff" stroke={2.4} />}
    </div>
  );
}

// ─── Avatar ──────────────────────────────────────────────────
function Avatar({ size = 40, initials = '', verified = false, bg, fg }) {
  const colors = ['#2563A8', '#3E7C4A', '#B0436B', '#C18A2B', '#7B5EA7', '#0E6E73'];
  const idx = (initials.charCodeAt(0) + (initials.charCodeAt(1) || 0)) % colors.length;
  const c = bg || colors[idx] || '#2563A8';
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: c, color: fg || '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font)', fontWeight: 600, fontSize: size * 0.38,
        letterSpacing: 0.5,
      }}>{initials}</div>
      {verified && (
        <div style={{
          position: 'absolute', right: -2, bottom: -2,
          width: size * 0.36, height: size * 0.36, borderRadius: '50%',
          background: 'var(--primary)', color: '#fff',
          border: '2px solid var(--card)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="check" size={size * 0.2} stroke={3} color="#fff" />
        </div>
      )}
    </div>
  );
}

// ─── Mark / Logo ─────────────────────────────────────────────
function Mark({ size = 40, variant = 'badge' }) {
  // Egnach civic mark — uses the official Wappen image (heraldic green tree
  // with red pears over the Bodensee blue) when variant='wappen'. Other
  // variants are abstract fallbacks for when the heraldry would be too busy.
  if (variant === 'wappen') {
    return (
      <div style={{
        width: size, height: size * (563/500),
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }}>
        <img src="mockups/assets/egnach-wappen.png" alt="Wappen Egnach"
             style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }} />
      </div>
    );
  }
  if (variant === 'wave') {
    return (
      <svg width={size} height={size} viewBox="0 0 40 40">
        <rect width="40" height="40" rx={size * 0.28} fill="var(--primary)" />
        <path d="M6 26 Q12 20 18 24 T30 22 T34 26"
              fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
        <path d="M6 18 Q12 12 18 16 T30 14"
              fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <div style={{
      width: size, height: size, borderRadius: size * 0.28,
      background: variant === 'badge' ? 'var(--primary)' : 'transparent',
      border: variant === 'mono' ? '1.6px solid var(--ink)' : 'none',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      <span style={{
        fontFamily: 'var(--font-display)', fontWeight: 700,
        fontSize: size * 0.5, color: variant === 'mono' ? 'var(--ink)' : '#fff',
        letterSpacing: -0.5,
      }}>E<span style={{ opacity: variant === 'mono' ? 0.4 : 0.7 }}>+</span></span>
    </div>
  );
}

// ─── TopBar ──────────────────────────────────────────────────
function TopBar({ title, leading, trailing, subtitle, transparent = false, dense = false }) {
  return (
    <div style={{
      padding: dense ? '8px 12px' : '10px 16px',
      display: 'flex', alignItems: 'center', gap: 8,
      background: transparent ? 'transparent' : 'var(--surface)',
      borderBottom: transparent ? 'none' : '1px solid var(--line)',
      minHeight: 52,
    }}>
      <div style={{ width: 32, display: 'flex' }}>{leading}</div>
      <div style={{ flex: 1, textAlign: 'center' }}>
        {title && <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, color: 'var(--ink)' }}>{title}</div>}
        {subtitle && <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      <div style={{ width: 32, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>{trailing}</div>
    </div>
  );
}

function IconButton({ name, onClick, size = 36, badge }) {
  return (
    <button onClick={onClick} style={{
      width: size, height: size, borderRadius: '50%',
      border: 'none', background: 'transparent',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--ink)', cursor: 'pointer', position: 'relative',
    }}>
      <Icon name={name} size={size > 36 ? 22 : 20} />
      {badge && (
        <span style={{
          position: 'absolute', top: 6, right: 6,
          minWidth: 14, height: 14, padding: '0 4px',
          borderRadius: 7, background: 'var(--accent)', color: '#fff',
          fontFamily: 'var(--font)', fontSize: 9, fontWeight: 700,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          border: '1.5px solid var(--surface)',
        }}>{badge}</span>
      )}
    </button>
  );
}

// ─── TabBar ──────────────────────────────────────────────────
function TabBar({ active = 0 }) {
  const tabs = [
    { name: 'home',     label: 'Start' },
    { name: 'store',    label: 'Markt' },
    { name: 'calendar', label: 'Anlässe' },
    { name: 'chat',     label: 'Chat' },
    { name: 'user',     label: 'Profil' },
  ];
  return (
    <div style={{
      display: 'flex', background: 'var(--card)',
      borderTop: '1px solid var(--line)',
      paddingTop: 6, paddingBottom: 18,
      flexShrink: 0,
    }}>
      {tabs.map((t, i) => {
        const on = i === active;
        return (
          <div key={i} style={{
            flex: 1, display: 'flex', flexDirection: 'column',
            alignItems: 'center', gap: 4, padding: '4px 0',
            color: on ? 'var(--primary)' : 'var(--ink-3)',
          }}>
            <Icon name={t.name} size={22} stroke={on ? 2 : 1.6} />
            <span style={{ fontFamily: 'var(--font)', fontSize: 10, fontWeight: on ? 600 : 500, letterSpacing: 0.2 }}>{t.label}</span>
          </div>
        );
      })}
    </div>
  );
}

// ─── Phone shell (clean, brand-aware) ────────────────────────
const DEVICE_W = 390;
const DEVICE_H = 800;
function Phone({ children, background = 'var(--surface)' }) {
  return (
    <div style={{
      width: DEVICE_W, height: DEVICE_H,
      borderRadius: 42, overflow: 'hidden',
      background,
      boxShadow: '0 24px 48px rgba(15,30,55,0.18), 0 2px 6px rgba(15,30,55,0.08), 0 0 0 1px rgba(0,0,0,0.04)',
      position: 'relative',
      fontFamily: 'var(--font)',
      isolation: 'isolate',
    }}>
      {/* Status bar (clean, abstract — works on any bg) */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 50,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 30px 0', zIndex: 50, pointerEvents: 'none',
      }}>
        <span style={{
          fontFamily: 'var(--font)', fontWeight: 700, fontSize: 14,
          color: 'var(--ink)', fontVariantNumeric: 'tabular-nums',
        }}>9:41</span>
        {/* Dynamic island */}
        <div style={{
          position: 'absolute', top: 11, left: '50%', transform: 'translateX(-50%)',
          width: 120, height: 32, borderRadius: 18, background: '#0a0a0a',
        }} />
        <div style={{ display: 'flex', gap: 5, alignItems: 'center', color: 'var(--ink)' }}>
          <Icon name="reload" size={12} stroke={2} />
          <svg width="16" height="10" viewBox="0 0 16 10">
            <rect x="0" y="0" width="13" height="8" rx="2" stroke="currentColor" strokeWidth="1" fill="none"/>
            <rect x="1.5" y="1.5" width="9" height="5" rx="0.6" fill="currentColor"/>
            <rect x="14" y="3" width="1.5" height="4" rx="0.4" fill="currentColor" opacity="0.5"/>
          </svg>
        </div>
      </div>
      <div style={{ width: '100%', height: '100%', paddingTop: 50, boxSizing: 'border-box', position: 'relative' }}>
        {children}
      </div>
      {/* Home indicator */}
      <div style={{
        position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)',
        width: 130, height: 4, borderRadius: 2, background: 'var(--ink)', opacity: 0.35, zIndex: 60,
      }} />
    </div>
  );
}

// Stage wrapper for the design canvas — pads + labels each phone artboard.
function Stage({ label, bg = 'var(--surface-2)', children }) {
  return (
    <div data-screen-label={label} style={{
      width: '100%', height: '100%', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: bg, padding: 20, boxSizing: 'border-box',
    }}>
      <Phone>{children}</Phone>
    </div>
  );
}

// ─── Screen (paint area inside the phone) ────────────────────
function Screen({ children, background = 'var(--surface)', scroll = false, sticky }) {
  return (
    <div style={{
      width: '100%', height: '100%', background, color: 'var(--ink)',
      display: 'flex', flexDirection: 'column',
      overflow: scroll ? 'auto' : 'hidden',
      fontFamily: 'var(--font)',
    }}>
      {children}
    </div>
  );
}

// scrollable region (use when Screen scroll=false + sticky chrome)
function Body({ children, padding = 0, background }) {
  return (
    <div style={{
      flex: 1, minHeight: 0, overflow: 'auto', padding, background,
    }}>{children}</div>
  );
}

// horizontal scroll row
function HScroll({ children, gap = 10, padding = '0 16px' }) {
  return (
    <div style={{
      display: 'flex', gap, padding, overflowX: 'auto',
      scrollbarWidth: 'none',
    }}>{children}</div>
  );
}

// Section header
function SectionHeader({ title, action, dense = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      padding: dense ? '4px 16px 8px' : '20px 16px 10px',
    }}>
      <h3 style={{
        margin: 0, fontFamily: 'var(--font-display)',
        fontSize: 17, fontWeight: 700, color: 'var(--ink)',
        letterSpacing: -0.2,
      }}>{title}</h3>
      {action && (
        <span style={{
          fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600,
          color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: 2,
        }}>{action}<Icon name="chevron" size={12} stroke={2.2} /></span>
      )}
    </div>
  );
}

// Card
function Card({ children, padding = 14, style }) {
  return (
    <div style={{
      background: 'var(--card)', borderRadius: 'var(--radius)',
      border: '1px solid var(--line)', padding,
      boxShadow: '0 1px 2px rgba(15,30,55,0.04)',
      ...style,
    }}>{children}</div>
  );
}

// Photo placeholder — striped, monospace caption (no AI imagery).
function Photo({ width = '100%', height = 140, hint = 'foto', radius = 12, tone = 'sand' }) {
  const palettes = {
    sand:  { a: '#E9E2D2', b: '#DDD2BB' },
    lake:  { a: '#D1DDE8', b: '#B7C8DA' },
    moss:  { a: '#D7DFCC', b: '#BFCAB0' },
    rose:  { a: '#EBD6DE', b: '#D9BAC6' },
    slate: { a: '#D4D9DF', b: '#B8C0C9' },
  };
  const p = palettes[tone] || palettes.sand;
  return (
    <div style={{
      width, height, borderRadius: radius, overflow: 'hidden',
      position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: `repeating-linear-gradient(135deg, ${p.a} 0 14px, ${p.b} 14px 28px)`,
      color: 'rgba(0,0,0,0.45)',
    }}>
      <span style={{
        fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace',
        fontSize: 11, letterSpacing: 0.5,
        background: 'rgba(255,255,255,0.7)', padding: '4px 8px', borderRadius: 4,
      }}>{hint}</span>
    </div>
  );
}

// Page indicator (dots)
function Dots({ count = 3, active = 0, accent = 'var(--ink)' }) {
  return (
    <div style={{ display: 'flex', gap: 6, justifyContent: 'center' }}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} style={{
          width: i === active ? 22 : 6, height: 6, borderRadius: 3,
          background: i === active ? accent : 'var(--line-2)',
          transition: 'width 0.2s',
        }} />
      ))}
    </div>
  );
}

// Help/banner box
function HelpBanner({ tone = 'info', title, children }) {
  const tones = {
    info:    { bg: 'var(--primary-tint)', ink: 'var(--primary-ink)', icon: 'info' },
    warning: { bg: '#FBF3DE',             ink: '#6E4F0E',            icon: 'warning' },
    success: { bg: '#E1F1E7',             ink: '#155E3E',            icon: 'check' },
    accent:  { bg: 'var(--accent-tint)',  ink: '#7a3318',            icon: 'info' },
  };
  const c = tones[tone] || tones.info;
  return (
    <div style={{
      background: c.bg, color: c.ink, borderRadius: 'var(--radius-sm)',
      padding: 12, display: 'flex', gap: 10, alignItems: 'flex-start',
    }}>
      <div style={{ marginTop: 1 }}><Icon name={c.icon} size={18} stroke={2} /></div>
      <div style={{ flex: 1 }}>
        {title && <div style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{title}</div>}
        <div style={{ fontFamily: 'var(--font)', fontSize: 12, lineHeight: 1.45, opacity: 0.88 }}>{children}</div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ICON_PATHS, Icon, Button, Chip, Badge, Field, Switch, Checkbox,
  Avatar, Mark, TopBar, IconButton, TabBar, Phone, Stage, Screen, Body,
  HScroll, SectionHeader, Card, Photo, Dots, HelpBanner,
  DEVICE_W, DEVICE_H,
});
