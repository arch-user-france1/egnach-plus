// Egnach Plus — Map screen with OpenStreetMap (Leaflet)
// Centered on Egnach (47.5474° N, 9.3838° E). Pins for Anlässe + Jobs,
// floating filters, bottom-sheet preview, "Du bist hier" user dot.

const EGNACH = [47.5474, 9.3838];

const MAP_PINS = [
  { id: 'e1', kind: 'event', pos: [47.5475, 9.3865], title: 'Hafenfest am Bodensee', sub: 'Sa, 14. Juni · 14:00', meta: '600 m', tone: 'lake' },
  { id: 'e2', kind: 'event', pos: [47.5455, 9.3795], title: 'Sprachcafé DE/EN',     sub: 'Do, 19:00 · Bibliothek', meta: '1.1 km', tone: 'moss' },
  { id: 'e3', kind: 'event', pos: [47.5510, 9.3920], title: 'Vereinsapero TVE',     sub: 'Fr, 18:30 · Turnhalle', meta: '1.6 km', tone: 'sand' },
  { id: 'j1', kind: 'job',   pos: [47.5495, 9.3820], title: 'Gartenarbeit am Sa.',  sub: 'CHF 35 / Std.', meta: '0.5 km', tone: 'moss' },
  { id: 'j2', kind: 'job',   pos: [47.5440, 9.3870], title: 'Hund hüten 3 Tage',    sub: 'CHF 25 / Tag', meta: '1.4 km', tone: 'sand' },
  { id: 'j3', kind: 'job',   pos: [47.5480, 9.3760], title: 'Umzugshilfe gesucht',  sub: 'CHF 30 / Std.', meta: '2.0 km', tone: 'lake' },
];

function M_Map() {
  const containerRef = React.useRef(null);
  const mapRef = React.useRef(null);
  const [activePin, setActivePin] = React.useState('e1');
  const [filter, setFilter] = React.useState('all');

  // Initialize Leaflet (lazy — Leaflet is loaded from CDN in index)
  React.useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    if (!window.L) return; // safety; should be loaded

    const map = window.L.map(containerRef.current, {
      center: EGNACH,
      zoom: 15,
      zoomControl: false,
      attributionControl: true,
    });
    mapRef.current = map;

    window.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap',
    }).addTo(map);

    // Custom div-icon pins
    const buildPinIcon = (kind, active) => {
      const accent = kind === 'event'
        ? 'var(--primary)'
        : 'var(--accent)';
      const glyph = kind === 'event'
        ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 6h14v14H5V6Zm0 4h14M9 3v4m6-4v4"/></svg>'
        : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v12H4V8Zm5 0V5h6v3M4 13h16"/></svg>';
      const size = active ? 40 : 32;
      return window.L.divIcon({
        className: 'egnach-pin',
        html: `
          <div style="
            width:${size}px;height:${size}px;
            border-radius:50% 50% 50% 0;
            transform: rotate(-45deg) translate(-50%, -50%);
            background:${accent};
            border: 2.5px solid #fff;
            box-shadow: 0 4px 10px rgba(15,30,55,0.28);
            display:flex; align-items:center; justify-content:center;
            transform-origin: 0 0;
          ">
            <div style="transform: rotate(45deg);">${glyph}</div>
          </div>
        `,
        iconSize: [size, size],
        iconAnchor: [0, 0],
      });
    };

    const markers = {};
    MAP_PINS.forEach(p => {
      const m = window.L.marker(p.pos, { icon: buildPinIcon(p.kind, p.id === 'e1') }).addTo(map);
      m.on('click', () => setActivePin(p.id));
      markers[p.id] = { marker: m, kind: p.kind };
    });

    // "Du bist hier" — pulsing user dot
    const meIcon = window.L.divIcon({
      className: 'egnach-me',
      html: `
        <div style="position:relative; width:44px; height:44px;">
          <div style="position:absolute; inset:0; border-radius:50%; background: rgba(37,99,168,0.18); animation: egnach-pulse 2s ease-out infinite;"></div>
          <div style="position:absolute; left:50%; top:50%; transform: translate(-50%,-50%); width:18px; height:18px; border-radius:50%; background:#2563A8; border:3px solid #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.25);"></div>
        </div>
      `,
      iconSize: [44, 44],
      iconAnchor: [22, 22],
    });
    window.L.marker(EGNACH, { icon: meIcon, interactive: false }).addTo(map);

    // expose for filter re-render
    mapRef.current._egnachMarkers = markers;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Re-render markers visibility on filter change
  React.useEffect(() => {
    const map = mapRef.current;
    if (!map || !map._egnachMarkers) return;
    Object.entries(map._egnachMarkers).forEach(([id, { marker, kind }]) => {
      const show = filter === 'all' || (filter === 'events' && kind === 'event') || (filter === 'jobs' && kind === 'job');
      if (show) { if (!map.hasLayer(marker)) marker.addTo(map); }
      else      { if (map.hasLayer(marker))   map.removeLayer(marker); }
    });
  }, [filter]);

  const visiblePins = MAP_PINS.filter(p =>
    filter === 'all' || (filter === 'events' && p.kind === 'event') || (filter === 'jobs' && p.kind === 'job'));

  return (
    <Screen background="var(--surface)">
      <div style={{ position: 'relative', flex: 1, minHeight: 0, overflow: 'hidden' }}>
        {/* Leaflet container */}
        <div ref={containerRef} style={{
          position: 'absolute', inset: 0,
          background: 'var(--surface-2)',
        }} />

        {/* keyframes for the user pulse */}
        <style>{`
          @keyframes egnach-pulse {
            0% { transform: scale(0.6); opacity: 0.6; }
            70% { transform: scale(1.6); opacity: 0; }
            100% { transform: scale(1.6); opacity: 0; }
          }
          .leaflet-control-attribution {
            font-family: var(--font), system-ui, sans-serif !important;
            font-size: 9px !important;
            background: rgba(255,255,255,0.85) !important;
            color: var(--ink-3) !important;
          }
          .leaflet-control-attribution a { color: var(--primary) !important; }
        `}</style>

        {/* Top floating chrome — search + filters */}
        <div style={{
          position: 'absolute', top: 8, left: 12, right: 12, zIndex: 400,
          display: 'flex', flexDirection: 'column', gap: 8, pointerEvents: 'none',
        }}>
          <div style={{
            height: 44, borderRadius: 22, background: 'var(--card)',
            border: '1px solid var(--line)', padding: '0 12px',
            display: 'flex', alignItems: 'center', gap: 10,
            boxShadow: '0 4px 14px rgba(15,30,55,0.12), 0 1px 3px rgba(15,30,55,0.06)',
            pointerEvents: 'auto',
          }}>
            <IconButton name="back" size={32} />
            <span style={{ flex: 1, fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-3)' }}>Karte · Egnach</span>
            <Icon name="filter" size={18} color="var(--ink)" />
          </div>

          <HScroll gap={6} padding="0">
            <Chip active={filter==='all'}    onClick={()=>setFilter('all')}>Alle</Chip>
            <Chip active={filter==='events'} onClick={()=>setFilter('events')}
                  leading={<span style={{ width:8,height:8,borderRadius:4,background:'var(--primary)' }}/>}>Anlässe</Chip>
            <Chip active={filter==='jobs'} onClick={()=>setFilter('jobs')}
                  leading={<span style={{ width:8,height:8,borderRadius:2,background:'var(--accent)' }}/>}>Jobs</Chip>
            <Chip>Heute</Chip>
            <Chip>2 km</Chip>
            <Chip>Gratis</Chip>
          </HScroll>
        </div>

        {/* Right-side controls */}
        <div style={{
          position: 'absolute', right: 12, top: 110, zIndex: 400,
          display: 'flex', flexDirection: 'column', gap: 8,
        }}>
          {[
            { icon: 'pin',    aria: 'Mein Standort' },
            { icon: 'plus',   aria: 'Hineinzoomen' },
            { icon: 'edit',   aria: 'Schichten' },
          ].map((c,i)=>(
            <button key={i} onClick={() => {
              if (i === 0 && mapRef.current) mapRef.current.flyTo(EGNACH, 16);
              if (i === 1 && mapRef.current) mapRef.current.zoomIn();
            }} style={{
              width: 42, height: 42, borderRadius: 12,
              background: 'var(--card)', border: '1px solid var(--line)',
              boxShadow: '0 2px 6px rgba(15,30,55,0.08)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--ink)', cursor: 'pointer',
            }}>
              <Icon name={c.icon} size={18} />
            </button>
          ))}
        </div>

        {/* Legend */}
        <div style={{
          position: 'absolute', left: 12, top: 110, zIndex: 400,
          background: 'var(--card)', border: '1px solid var(--line)',
          borderRadius: 10, padding: '8px 10px',
          display: 'flex', flexDirection: 'column', gap: 5,
          boxShadow: '0 2px 6px rgba(15,30,55,0.06)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 10, height: 10, borderRadius: 5, background: 'var(--primary)' }} />
            <span style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-2)', fontWeight: 600 }}>Anlässe</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--accent)' }} />
            <span style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-2)', fontWeight: 600 }}>Jobs</span>
          </div>
        </div>

        {/* Bottom sheet */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 400,
          background: 'var(--card)',
          borderTopLeftRadius: 22, borderTopRightRadius: 22,
          boxShadow: '0 -10px 28px rgba(15,30,55,0.12)',
          padding: '8px 14px 16px',
          maxHeight: '46%',
          display: 'flex', flexDirection: 'column',
        }}>
          {/* Handle */}
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
            <div style={{ width: 44, height: 4, borderRadius: 2, background: 'var(--line-2)' }} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>
                {visiblePins.length} in der Nähe
              </div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 1 }}>
                Sortiert nach Distanz
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="map" size={14} color="var(--primary)" />
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--primary)', fontWeight: 600 }}>Liste</span>
            </div>
          </div>

          <HScroll padding="0" gap={10}>
            {visiblePins.map(p => {
              const on = p.id === activePin;
              return (
                <div key={p.id} onClick={() => setActivePin(p.id)} style={{
                  width: 220, flexShrink: 0,
                  border: `1.5px solid ${on ? 'var(--primary)' : 'var(--line)'}`,
                  borderRadius: 'var(--radius)',
                  background: on ? 'var(--primary-tint)' : 'var(--card)',
                  padding: 10, cursor: 'pointer',
                  boxShadow: on ? '0 4px 14px rgba(37,99,168,0.18)' : 'none',
                }}>
                  <div style={{ display: 'flex', gap: 10 }}>
                    <Photo width={54} height={54} tone={p.tone} radius={10} hint={p.kind === 'event' ? 'anlass' : 'job'} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <Badge tone={p.kind === 'event' ? 'primary' : 'accent'} size="sm">
                        {p.kind === 'event' ? 'Anlass' : 'Job'}
                      </Badge>
                      <div style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: 'var(--ink)', marginTop: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {p.title}
                      </div>
                      <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-2)', marginTop: 2 }}>
                        {p.sub}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6 }}>
                        <Icon name="pin" size={11} color="var(--ink-3)" stroke={2}/>
                        <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>{p.meta}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </HScroll>
        </div>
      </div>

      <TabBar active={0} />
    </Screen>
  );
}

Object.assign(window, { M_Map });
