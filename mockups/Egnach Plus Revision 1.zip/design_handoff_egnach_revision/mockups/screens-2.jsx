// Egnach Plus — Mockup screens 06–10
// 06 Marktplatz
// 07 Inserat Detail
// 08 Inserat erstellen
// 09 Anlässe (Liste + Kalender)
// 10 Anlass Detail

// ─── 06 · Marktplatz ─────────────────────────────────────────
function M06_Marketplace() {
  const [help, setHelp] = React.useState(false);
  const items = [
    { title: 'Bohrhammer Bosch GBH',  cat: 'Leihen',  q: 'Egnach Dorf', price: 'CHF 12 / Tag', rating: '4.9', avatar: 'TH', tone: 'sand', verified: true },
    { title: 'Französisch-Nachhilfe', cat: 'Dienste', q: 'Neuhof',      price: 'CHF 40 / Std.',rating: '5.0', avatar: 'CR', tone: 'lake', verified: true },
    { title: 'Anhänger 1.5 m',        cat: 'Leihen',  q: 'Seefeld',     price: 'CHF 25 / Tag', rating: '4.7', avatar: 'PS', tone: 'slate', verified: false },
    { title: 'Velo-Service Lehrling', cat: 'Jobs',    q: 'Egnach Dorf', price: 'CHF 28 / Std.',rating: '4.8', avatar: 'LM', tone: 'moss', verified: true },
    { title: 'Apfelmost 5 L',         cat: 'Tausch',  q: 'Buchen',      price: 'Tausch',       rating: '4.9', avatar: 'OK', tone: 'rose', verified: true },
  ];
  return (
    <React.Fragment>
    <Screen background="var(--surface)">
      <div style={{ padding: '10px 16px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: -0.4, color: 'var(--ink)' }}>Marktplatz</h1>
          <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>146 aktive Inserate</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <HelpButton onClick={() => setHelp(true)} />
          <IconButton name="options" />
        </div>
      </div>

      <Body>
        <div style={{ padding: '4px 16px 12px' }}>
          <div style={{
            height: 44, borderRadius: 22, background: 'var(--card)',
            border: '1px solid var(--line)', padding: '0 16px',
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <Icon name="search" size={18} color="var(--ink-3)"/>
            <span style={{ flex: 1, fontFamily: 'var(--font)', fontSize: 14, color: 'var(--ink-3)' }}>Was suchst du?</span>
            <div style={{ width: 1, height: 18, background: 'var(--line)' }}/>
            <Icon name="filter" size={18} color="var(--ink)" />
          </div>
        </div>

        <HScroll padding="0 16px">
          <Chip active>Alle</Chip>
          <CatChip name="werkzeug">Leihen</CatChip>
          <CatChip name="handwerk">Dienste</CatChip>
          <CatChip name="tausch">Tausch</CatChip>
          <CatChip name="jobs">Jobs</CatChip>
        </HScroll>

        <div style={{ padding: '14px 16px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>146 Ergebnisse · Egnach</span>
          <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--ink)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon name="filter" size={12} stroke={2}/> Distanz
          </span>
        </div>

        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {items.map((it,i)=>(
            <Card key={i} padding={10}>
              <div style={{ display: 'flex', gap: 12 }}>
                <Photo width={84} height={84} tone={it.tone} radius={10} hint="foto" />
                <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <CatChip name={it.cat} size="sm" />
                  </div>
                  <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)', lineHeight: 1.25 }}>{it.title}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}>
                    <Avatar size={18} initials={it.avatar} verified={it.verified}/>
                    <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>{it.q} · ⭐ {it.rating}</span>
                  </div>
                  <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--primary)', marginTop: 2 }}>{it.price}</div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'space-between' }}>
                  <IconButton name="heart" size={28} />
                </div>
              </div>
            </Card>
          ))}
          <div style={{ height: 80 }} />
        </div>
      </Body>

      {/* FAB */}
      <div style={{ position: 'absolute', right: 18, bottom: 92, zIndex: 5 }}>
        <button style={{
          width: 56, height: 56, borderRadius: 18,
          background: 'var(--accent)', color: '#fff', border: 'none',
          boxShadow: '0 6px 16px rgba(217,119,87,0.45), 0 2px 4px rgba(0,0,0,0.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <Icon name="plus" size={26} color="#fff" stroke={2.4}/>
        </button>
      </div>

      <TabBar active={1} />
    </Screen>
    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="So funktioniert der Marktplatz"
      intro="Leihen, tauschen, Dienste anbieten – alles unter Nachbarn in Egnach."
      items={[
        { icon: 'search', title: 'Suchen & filtern', text: 'Tippe ins Suchfeld oder wähle eine Kategorie. Mit dem Filter sortierst du z. B. nach Distanz.' },
        { icon: 'store',  title: 'Kategorien', text: '«Leihen» für Gegenstände, «Dienste» für Hilfe, «Tausch» ohne Geld, «Jobs» für bezahlte Arbeit.' },
        { icon: 'shield', title: 'Verifizierte Nachbarn', text: 'Das blaue Häkchen zeigt geprüfte Mitglieder. So weisst du, mit wem du es zu tun hast.' },
        { icon: 'plus',   title: 'Eigenes Inserat', text: 'Mit dem orangen Plus-Knopf gibst du in wenigen Schritten dein eigenes Inserat auf.' },
      ]} />
    </React.Fragment>
  );
}

// ─── 07 · Inserat Detail ─────────────────────────────────────
function M07_ListingDetail() {
  const [help, setHelp] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  React.useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(false), 3200); return () => clearTimeout(id); }, [toast]);
  return (
    <React.Fragment>
    <Screen background="var(--surface)" scroll>
      {/* Hero gallery */}
      <div style={{ position: 'relative', height: 280 }}>
        <Photo width="100%" height={280} radius={0} tone="sand" hint="produktfoto" />
        <div style={{ position: 'absolute', top: 8, left: 12, right: 12, display: 'flex', justifyContent: 'space-between' }}>
          <button style={{
            width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
            border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
            backdropFilter: 'blur(8px)', boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
          }}><Icon name="back" size={20}/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setHelp(true)} aria-label="Hilfe" style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              backdropFilter: 'blur(8px)', boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
              fontFamily: 'var(--font)', fontWeight: 700, fontSize: 18, color: 'var(--ink)', cursor: 'pointer',
            }}>?</button>
            <button style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              backdropFilter: 'blur(8px)', boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
            }}><Icon name="share" size={18}/></button>
            <button style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              backdropFilter: 'blur(8px)', boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
            }}><Icon name="heart" size={18}/></button>
          </div>
        </div>
        <div style={{ position: 'absolute', bottom: 12, left: 0, right: 0 }}>
          <Dots count={4} active={0} accent="#fff" />
        </div>
      </div>

      <div style={{ padding: '18px 18px 12px' }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
          <Badge tone="primary" size="sm">LEIHEN</Badge>
          <Badge tone="neutral" size="sm">Egnach Dorf</Badge>
        </div>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)', lineHeight: 1.2 }}>
          Bohrhammer Bosch GBH 2-26
        </h1>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, color: 'var(--primary)' }}>CHF 12</span>
          <span style={{ fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)' }}>/ Tag · CHF 50 / Woche</span>
        </div>
      </div>

      {/* Owner card */}
      <div style={{ padding: '8px 18px 14px' }}>
        <Card padding={14}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Avatar size={48} initials="TH" verified />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>Thomas Hofer</span>
                <Badge tone="success" size="sm">VERIFIZIERT</Badge>
              </div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>
                ⭐ 4.9 · 23 Bewertungen · seit Mai 2024
              </div>
            </div>
            <button style={{
              border: '1px solid var(--line-2)', background: 'transparent',
              borderRadius: 999, padding: '6px 12px',
              fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--ink)',
            }}>Profil</button>
          </div>
        </Card>
      </div>

      <div style={{ padding: '0 18px 16px' }}>
        <h3 style={{ margin: '4px 0 8px', fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>Beschreibung</h3>
        <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 13, lineHeight: 1.55, color: 'var(--ink-2)' }}>
          Professioneller Bohr- und Meisselhammer, SDS-plus, inkl. Zusatzhandgriff und Tiefenanschlag. Wenig benutzt, im Originalkoffer. Abholung in Egnach Dorf, Übergabe persönlich.
        </p>
      </div>

      {/* Key facts */}
      <div style={{ padding: '0 18px 16px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { label: 'Verfügbar', value: 'Ab Mi, 11. Juni' },
            { label: 'Übergabe',  value: 'Persönlich' },
            { label: 'Kaution',   value: 'CHF 50' },
            { label: 'Sprachen',  value: 'DE · EN' },
          ].map((f,i)=>(
            <div key={i} style={{
              padding: 12, borderRadius: 'var(--radius-sm)',
              background: 'var(--surface-2)',
            }}>
              <div style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)', letterSpacing: 0.8, fontWeight: 700 }}>{f.label.toUpperCase()}</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 600, color: 'var(--ink)', marginTop: 4 }}>{f.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Reviews summary */}
      <div style={{ padding: '0 18px 14px' }}>
        <h3 style={{ margin: '4px 0 10px', fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>Bewertungen</h3>
        <Card padding={14}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, fontWeight: 700, color: 'var(--ink)', lineHeight: 1 }}>4.9</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)', marginTop: 4, letterSpacing: 0.5 }}>23 BEWERTUNGEN</div>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
              {[5,4,3,2,1].map(n => (
                <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>
                  <span style={{ width: 8 }}>{n}</span>
                  <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'var(--surface-2)', overflow: 'hidden' }}>
                    <div style={{ width: n === 5 ? '88%' : n === 4 ? '60%' : n === 3 ? '8%' : '0', height: '100%', background: 'var(--accent)' }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <div style={{ height: 100 }} />

      {/* Action bar */}
      <div style={{
        position: 'sticky', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 22px', background: 'var(--card)',
        borderTop: '1px solid var(--line)',
        display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <button style={{
          width: 48, height: 48, borderRadius: 'var(--radius-sm)',
          border: '1.5px solid var(--line-2)', background: 'var(--card)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="chat" size={20}/>
        </button>
        <div style={{ flex: 1 }}>
          <Button full size="lg" onClick={() => setToast(true)}>Anfrage senden</Button>
        </div>
      </div>
    </Screen>
    <Toast open={toast} tone="success"
      title="Anfrage gesendet"
      msg="Thomas erhält deine Nachricht. Du findest die Antwort im Chat."
      bottom={96} />
    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="Etwas leihen – so geht’s"
      intro="Du fragst unverbindlich an und klärst die Details direkt mit dem Anbieter."
      items={[
        { icon: 'send',   title: 'Anfrage senden', text: 'Tippe auf «Anfrage senden». Der Anbieter bekommt eine Nachricht – noch ist nichts verbindlich.' },
        { icon: 'chat',   title: 'Details besprechen', text: 'Über den Chat klärt ihr Übergabe, Zeit und Kaution. Bei Bedarf wird automatisch übersetzt.' },
        { icon: 'euro',   title: 'Kaution & Preis', text: 'Preis pro Tag und Kaution stehen oben. Die Kaution bekommst du bei Rückgabe zurück.' },
        { icon: 'star',   title: 'Bewerten', text: 'Nach der Rückgabe könnt ihr euch gegenseitig bewerten. Das hilft der ganzen Nachbarschaft.' },
      ]} />
    </React.Fragment>
  );
}

// ─── 08 · Inserat erstellen ──────────────────────────────────
function M08_CreateListing() {
  const types = [
    { cat: 'werkzeug', label: 'Leihen',  on: true },
    { cat: 'handwerk', label: 'Dienste' },
    { cat: 'tausch',   label: 'Tausch' },
    { cat: 'jobs',     label: 'Jobs' },
  ];
  const [help, setHelp] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  React.useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(false), 3200); return () => clearTimeout(id); }, [toast]);
  return (
    <React.Fragment>
    <Screen background="var(--surface)">
      <TopBar
        leading={<IconButton name="close" />}
        title="Neues Inserat"
        trailing={<HelpButton onClick={() => setHelp(true)} />}
      />

      <Body padding="14px 18px 20px">
        {/* Progress */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
            <span style={{ fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 0.8 }}>SCHRITT 1 VON 3</span>
            <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>ca. 2 min</span>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'var(--primary)' }} />
            <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'var(--line)' }} />
            <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'var(--line)' }} />
          </div>
        </div>

        <h2 style={{ margin: '6px 0 14px', fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)' }}>
          Was bietest du an?
        </h2>

        {/* Type cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 18 }}>
          {types.map((t,i)=>(
            <div key={i} style={{
              padding: 14, borderRadius: 'var(--radius-sm)',
              background: t.on ? 'var(--primary-tint)' : 'var(--card)',
              border: `1.5px solid ${t.on ? 'var(--primary)' : 'var(--line)'}`,
              display: 'flex', flexDirection: 'column', gap: 8,
              color: t.on ? 'var(--primary)' : 'var(--ink)',
            }}>
              <CatGlyph name={t.cat} size={24} stroke={1.9} color={CAT_META[t.cat].ink}/>
              <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 600, color: t.on ? 'var(--primary-ink)' : 'var(--ink)' }}>{t.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Field label="Titel" required value="Bohrhammer Bosch GBH 2-26"
                 hint="Max. 60 Zeichen · 31 / 60" />

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
              <span style={{ display: 'flex', gap: 4, alignItems: 'baseline' }}>
                <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>Beschreibung</span>
                <span style={{ color: 'var(--danger)', fontSize: 12 }}>*</span>
              </span>
              <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>142 / 500</span>
            </div>
            <div style={{
              minHeight: 96, padding: 12, borderRadius: 'var(--radius-sm)',
              background: 'var(--card)', border: '1px solid var(--line)',
              fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink)', lineHeight: 1.5,
            }}>
              Professioneller Bohrhammer, SDS-plus, inkl. Koffer und Zubehör. Wenig benutzt — perfekt für Renovationen.
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Preis" required value="12.00" hint="CHF / Tag"
                   trailing={<span style={{ fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-3)', fontWeight: 600 }}>CHF</span>} />
            <Field label="Verfügbar ab" required value="11.06.2026" hint="TT.MM.JJJJ"
                   trailing={<Icon name="calendar" size={14} color="var(--ink-3)"/>} />
          </div>

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>Fotos</span>
              <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>2 / 6</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <Photo width={72} height={72} tone="sand" radius={10} hint="01" />
              <Photo width={72} height={72} tone="slate" radius={10} hint="02" />
              <div style={{
                width: 72, height: 72, borderRadius: 10,
                border: '1.5px dashed var(--line-2)', background: 'var(--surface-2)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
                color: 'var(--ink-3)',
              }}>
                <Icon name="plus" size={20}/>
                <span style={{ fontFamily: 'var(--font)', fontSize: 10 }}>JPG / PNG</span>
              </div>
            </div>
            <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>
              Empfohlen: hell, gerade, ohne Wasserzeichen. Max. 5 MB pro Foto.
            </div>
          </div>

          <HelpBanner tone="info" title="Tipp">
            Klare Fotos und ein präziser Titel erhöhen deine Antwortrate um über 60%.
          </HelpBanner>

          <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>
            Pflichtfelder sind mit <span style={{ color: 'var(--danger)' }}>*</span> markiert.
          </div>
        </div>
      </Body>

      <div style={{ padding: '12px 16px 22px', borderTop: '1px solid var(--line)', background: 'var(--card)', display: 'flex', gap: 10 }}>
        <div style={{ flex: 1 }}><Button full size="lg" variant="outline" onClick={() => setToast(true)}>Entwurf speichern</Button></div>
        <div style={{ flex: 1 }}><Button full size="lg" trailing={<Icon name="arrowSmall" size={18} color="#fff" stroke={2.2}/>}>Weiter</Button></div>
      </div>
    </Screen>
    <Toast open={toast} tone="success"
      title="Entwurf gespeichert"
      msg="Du findest dein Inserat unter «Meine Inserate» und kannst später weitermachen."
      bottom={92} />
    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="Inserat aufgeben – Schritt für Schritt"
      intro="In drei kurzen Schritten ist dein Inserat online. Du kannst jederzeit pausieren."
      items={[
        { icon: 'store',  title: 'Art wählen', text: 'Leihen, Dienste, Tausch oder Job – wähle oben, was am besten passt.' },
        { icon: 'edit',   title: 'Klar beschreiben', text: 'Ein kurzer, genauer Titel und eine ehrliche Beschreibung bringen mehr Anfragen.' },
        { icon: 'camera', title: 'Gute Fotos', text: 'Hell, gerade und ohne Wasserzeichen. Max. 5 MB pro Foto, bis zu 6 Bilder.' },
        { icon: 'log',    title: 'Entwurf speichern', text: 'Noch nicht fertig? «Entwurf speichern» sichert alles – du machst später weiter.' },
      ]} />
    </React.Fragment>
  );
}

// ─── 09 · Anlässe (Liste) ────────────────────────────────────
function M09_Events() {
  const days = [
    {
      label: 'Heute · Mittwoch, 11. Juni',
      events: [
        { time: '18:30', title: 'Sommerlauf Egnach',  loc: 'Schulhaus',    cats: ['Sport', 'Familie'],   tone: 'moss' },
        { time: '19:30', title: 'Sprachcafé DE/EN',   loc: 'Bibliothek',   cats: ['Sprache'],            tone: 'lake' },
      ],
    },
    {
      label: 'Donnerstag, 12. Juni',
      events: [
        { time: '14:00', title: 'Senioren-Zmittag',   loc: 'Gemeindesaal', cats: ['Senioren'],           tone: 'sand' },
      ],
    },
    {
      label: 'Samstag, 14. Juni',
      events: [
        { time: '14:00', title: 'Hafenfest am Bodensee', loc: 'Seefeld',   cats: ['Gemeinde', 'Familie'], tone: 'lake' },
        { time: '20:00', title: 'Live-Musik «de Trio»',  loc: 'Restaurant Sonne', cats: ['Kultur'],      tone: 'rose' },
      ],
    },
  ];
  const [help, setHelp] = React.useState(false);
  return (
    <React.Fragment>
    <Screen background="var(--surface)">
      <div style={{ padding: '10px 16px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: -0.4, color: 'var(--ink)' }}>Anlässe</h1>
          <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>23 Anlässe · diese Woche</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <HelpButton onClick={() => setHelp(true)} />
          <IconButton name="search" />
        </div>
      </div>

      <Body>
        {/* Segmented */}
        <div style={{ padding: '4px 16px 12px' }}>
          <div style={{
            height: 40, borderRadius: 20, padding: 4,
            background: 'var(--surface-2)', border: '1px solid var(--line)',
            display: 'flex', gap: 4,
          }}>
            <div style={{
              flex: 1, borderRadius: 16, background: 'var(--card)',
              boxShadow: '0 1px 2px rgba(15,30,55,0.06)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              color: 'var(--ink)',
            }}>
              <Icon name="log" size={14}/>
              <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 600 }}>Liste</span>
            </div>
            <div style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              color: 'var(--ink-3)',
            }}>
              <Icon name="calendar" size={14}/>
              <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 500 }}>Kalender</span>
            </div>
          </div>
        </div>

        <HScroll padding="0 16px 4px">
          <Chip active>Alle</Chip>
          <CatChip name="gemeinde" />
          <CatChip name="sport" />
          <CatChip name="familie" />
          <CatChip name="senioren" />
          <CatChip name="sprache" />
          <CatChip name="kultur" />
          <CatChip name="party" />
        </HScroll>

        {days.map((d, di) => (
          <div key={di}>
            <div style={{ padding: '18px 16px 8px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: 'var(--ink-2)', letterSpacing: 0.5, textTransform: 'uppercase' }}>{d.label}</span>
              <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
            </div>
            <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {d.events.map((e,i)=>(
                <Card key={i} padding={0} style={{ overflow: 'hidden' }}>
                  <div style={{ display: 'flex' }}>
                    <div style={{
                      width: 70, padding: '14px 8px', textAlign: 'center',
                      background: 'var(--surface-2)',
                      borderRight: '1px solid var(--line)',
                      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <div style={{ fontFamily: 'var(--font)', fontSize: 10, fontWeight: 700, color: 'var(--accent)', letterSpacing: 1 }}>JUN</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--ink)', lineHeight: 1, marginTop: 4 }}>{di === 0 ? 11 : di === 1 ? 12 : 14}</div>
                      <div style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)', marginTop: 6, fontWeight: 600 }}>{e.time}</div>
                    </div>
                    <div style={{ flex: 1, padding: 12 }}>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: 'var(--ink)', lineHeight: 1.25 }}>{e.title}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                        <Icon name="pin" size={11} color="var(--ink-3)" stroke={2}/>
                        <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>{e.loc}</span>
                      </div>
                      <div style={{ display: 'flex', gap: 4, marginTop: 8, flexWrap: 'wrap' }}>
                        {e.cats.map((c, ci) => <CatChip key={ci} name={c} size="sm" />)}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))}

        <div style={{ height: 80 }} />
      </Body>

      {/* FAB */}
      <div style={{ position: 'absolute', right: 18, bottom: 92, zIndex: 5 }}>
        <button style={{
          width: 56, height: 56, borderRadius: 18,
          background: 'var(--accent)', color: '#fff', border: 'none',
          boxShadow: '0 6px 16px rgba(217,119,87,0.45), 0 2px 4px rgba(0,0,0,0.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}><Icon name="plus" size={26} color="#fff" stroke={2.4}/></button>
      </div>

      <TabBar active={2} />
    </Screen>
    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="Anlässe finden & teilnehmen"
      intro="Alle Veranstaltungen der Gemeinde und Vereine – übersichtlich nach Tag sortiert."
      items={[
        { icon: 'log',      title: 'Liste oder Kalender', text: 'Wechsle oben zwischen der Tagesliste und der Kalenderansicht.' },
        { icon: 'filter',   title: 'Nach Thema filtern', text: 'Tippe auf eine Kategorie wie Sport, Familie oder Senioren, um passende Anlässe zu sehen.' },
        { icon: 'check',    title: 'Teilnehmen', text: 'Öffne einen Anlass und tippe auf «Teilnehmen». Du bekommst eine Erinnerung vor dem Termin.' },
        { icon: 'plus',     title: 'Eigenen Anlass', text: 'Mit dem orangen Plus-Knopf meldest du einen Anlass deines Vereins an.' },
      ]} />
    </React.Fragment>
  );
}

// ─── 10 · Anlass Detail ──────────────────────────────────────
function M10_EventDetail() {
  const [help, setHelp] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  React.useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(false), 3200); return () => clearTimeout(id); }, [toast]);
  return (
    <React.Fragment>
    <Screen background="var(--surface)" scroll>
      {/* Hero */}
      <div style={{ position: 'relative', height: 240 }}>
        <Photo width="100%" height={240} radius={0} tone="lake" hint="hafenfest" />
        {/* Gradient overlay for legibility */}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.32) 0%, rgba(0,0,0,0) 30%, rgba(0,0,0,0) 60%, rgba(15,30,55,0.55) 100%)' }}/>
        <div style={{ position: 'absolute', top: 8, left: 12, right: 12, display: 'flex', justifyContent: 'space-between' }}>
          <button style={{
            width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
            border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Icon name="back" size={20}/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setHelp(true)} aria-label="Hilfe" style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font)', fontWeight: 700, fontSize: 18, color: 'var(--ink)', cursor: 'pointer',
            }}>?</button>
            <button style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon name="share" size={18}/></button>
            <button style={{
              width: 40, height: 40, borderRadius: 20, background: 'rgba(255,255,255,0.92)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon name="heart" size={18}/></button>
          </div>
        </div>
        <div style={{ position: 'absolute', left: 18, right: 18, bottom: 14 }}>
          <Badge tone="accent" size="md">DORFFEST · GEMEINDE</Badge>
          <h1 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: -0.4, color: '#fff', lineHeight: 1.15 }}>
            Hafenfest am Bodensee 2026
          </h1>
        </div>
      </div>

      {/* Meta rows */}
      <div style={{ padding: '14px 18px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {[
          { icon: 'calendar', main: 'Samstag, 14. Juni · 14:00 – 23:00',  sub: 'Bei jedem Wetter', action: '+ Kalender' },
          { icon: 'pin',      main: 'Hafenanlage Seefeld',                sub: 'Seestrasse 12, 9322 Egnach', action: 'Karte' },
          { icon: 'euro',     main: 'Eintritt frei',                      sub: 'Verpflegung vor Ort' },
          { icon: 'language', main: 'DE · EN · IT · SQ',                  sub: 'Programm in 4 Sprachen' },
        ].map((row,i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: 'var(--primary-tint)', color: 'var(--primary)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name={row.icon} size={18} stroke={2}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{row.main}</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>{row.sub}</div>
            </div>
            {row.action && (
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--primary)', flexShrink: 0 }}>{row.action}</span>
            )}
          </div>
        ))}
      </div>

      <div style={{ padding: '12px 18px 0' }}>
        <div style={{ height: 1, background: 'var(--line)' }}/>
      </div>

      {/* Description */}
      <div style={{ padding: '16px 18px 8px' }}>
        <h3 style={{ margin: '0 0 8px', fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>Über den Anlass</h3>
        <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 13, lineHeight: 1.55, color: 'var(--ink-2)' }}>
          Das traditionelle Hafenfest der Gemeinde Egnach mit Live-Musik, Foodständen der Dorfvereine, Kinderprogramm und Bootsfahrten ab Hafen. Ab 21:00 grosses Seefeuerwerk.
        </p>
        <div style={{ display: 'flex', gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
          <CatChip name="familie" size="sm" />
          <CatChip name="Musik" size="sm" />
          <CatChip name="Kulinarik" size="sm" />
          <CatChip name="Feuerwerk" size="sm" />
        </div>
      </div>

      {/* Organisator */}
      <div style={{ padding: '14px 18px 8px' }}>
        <Card padding={14}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)', letterSpacing: 1, fontWeight: 700 }}>ORGANISIERT VON</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
            <Mark size={42} variant="wappen" />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>Gemeinde Egnach</span>
                <Badge tone="success" size="sm"><Icon name="check" size={9} stroke={3} color="#155E3E"/> Offiziell</Badge>
              </div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>Offizielle Veranstaltung · seit 1987</div>
            </div>
            <Icon name="chevron" size={16} color="var(--ink-3)"/>
          </div>
        </Card>
      </div>

      {/* Attendees */}
      <div style={{ padding: '14px 18px 16px' }}>
        <h3 style={{ margin: '0 0 10px', fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>247 nehmen teil</h3>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {['SM','TH','AR','LB','NK'].map((n,i)=>(
            <div key={i} style={{ marginLeft: i === 0 ? 0 : -10 }}>
              <Avatar size={34} initials={n} />
            </div>
          ))}
          <div style={{ marginLeft: -10, width: 34, height: 34, borderRadius: 17, background: 'var(--surface-2)', border: '2px solid var(--card)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font)', fontSize: 10, fontWeight: 700, color: 'var(--ink-2)' }}>+ 242</div>
          <div style={{ marginLeft: 12, fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>davon 18 Nachbarn aus deinem Quartier</div>
        </div>
      </div>

      <div style={{ height: 100 }} />

      <div style={{
        position: 'sticky', bottom: 0, padding: '12px 16px 22px', background: 'var(--card)',
        borderTop: '1px solid var(--line)',
        display: 'flex', gap: 10,
      }}>
        <button style={{
          width: 48, height: 48, borderRadius: 'var(--radius-sm)',
          border: '1.5px solid var(--line-2)', background: 'var(--card)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="share" size={18}/>
        </button>
        <div style={{ flex: 1 }}>
          <Button full size="lg" leading={<Icon name="check" size={18} color="#fff" stroke={2.2}/>} onClick={() => setToast(true)}>Teilnehmen</Button>
        </div>
      </div>
    </Screen>
    <Toast open={toast} tone="success"
      title="Du bist dabei!"
      msg="Der Anlass ist gespeichert. Wir erinnern dich am Samstag rechtzeitig."
      bottom={96} />
    <HelpSheet open={help} onClose={() => setHelp(false)}
      title="Über diesen Anlass"
      intro="Alle wichtigen Infos auf einen Blick – und mit einem Tipp bist du angemeldet."
      items={[
        { icon: 'check',    title: 'Teilnehmen', text: 'Tippe unten auf «Teilnehmen». Du erscheinst in der Teilnehmerliste und wirst erinnert.' },
        { icon: 'calendar', title: 'In Kalender', text: 'Mit «+ Kalender» überträgst du Datum und Zeit in den Kalender deines Handys.' },
        { icon: 'pin',      title: 'Anfahrt', text: 'Tippe bei der Adresse auf «Karte», um den Weg zum Hafen Seefeld zu sehen.' },
        { icon: 'share',    title: 'Weitersagen', text: 'Teile den Anlass mit Nachbarn oder Freunden über den Teilen-Knopf.' },
      ]} />
    </React.Fragment>
  );
}

Object.assign(window, { M06_Marketplace, M07_ListingDetail, M08_CreateListing, M09_Events, M10_EventDetail });
