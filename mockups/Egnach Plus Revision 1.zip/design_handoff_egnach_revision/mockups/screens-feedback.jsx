// Egnach Plus — Showcase: Hilfe & Rückmeldungen (2.3)
// Dedicated artboards that present each feedback pattern in its
// open state, so reviewers see them without interacting.

// 15 · Hilfe-Sheet (über dem Marktplatz)
function MF_HelpSheet() {
  return (
    <React.Fragment>
      <M06_Marketplace />
      <HelpSheet open onClose={() => {}}
        title="So funktioniert der Marktplatz"
        intro="Leihen, tauschen, Dienste anbieten – alles unter Nachbarn in Egnach."
        items={[
          { icon: 'search', title: 'Suchen & filtern', text: 'Tippe ins Suchfeld oder wähle eine Kategorie. Mit dem Filter sortierst du z.\u202fB. nach Distanz.' },
          { icon: 'store',  title: 'Kategorien', text: '«Leihen» für Gegenstände, «Dienste» für Hilfe, «Tausch» ohne Geld, «Jobs» für bezahlte Arbeit.' },
          { icon: 'shield', title: 'Verifizierte Nachbarn', text: 'Das blaue Häkchen zeigt geprüfte Mitglieder. So weisst du, mit wem du es zu tun hast.' },
          { icon: 'plus',   title: 'Eigenes Inserat', text: 'Mit dem orangen Plus-Knopf gibst du in wenigen Schritten dein eigenes Inserat auf.' },
        ]} />
    </React.Fragment>
  );
}

// 16 · Bestätigung (Erfolgs-Toast)
function MF_Saved() {
  return (
    <React.Fragment>
      <M08_CreateListing />
      <Toast open tone="success"
        title="Inserat wurde gespeichert"
        msg="Dein Inserat ist jetzt im Marktplatz sichtbar. Interessenten können dich kontaktieren."
        bottom={92} />
    </React.Fragment>
  );
}

// 17 · Löschen bestätigen (Dialog)
function MF_Delete() {
  return (
    <React.Fragment>
      <M07_ListingDetail />
      <ConfirmDialog open tone="danger" icon="trash"
        title="Möchtest du dieses Inserat wirklich löschen?"
        body="«Bohrhammer Bosch» wird gelöscht und ist danach nicht mehr sichtbar. Das kannst du nicht mehr rückgängig machen."
        cancelLabel="Abbrechen" confirmLabel="Löschen"
        onCancel={() => {}} onConfirm={() => {}} />
    </React.Fragment>
  );
}

// 18 · Freundlicher Fehler (Verbindung)
function MF_Error() {
  return (
    <Screen background="var(--surface)">
      <TopBar leading={<IconButton name="back" />} title="Marktplatz" trailing={<HelpButton onClick={() => {}} />} />
      <Body padding="0">
        <div style={{
          flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', textAlign: 'center',
          padding: '24px 28px', gap: 4, height: '100%',
        }}>
          <div style={{
            width: 92, height: 92, borderRadius: '50%',
            background: 'var(--surface-2)', color: 'var(--ink-3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8,
          }}>
            <Icon name="globe" size={46} stroke={1.4} />
          </div>
          <h2 style={{ margin: '8px 0 6px', fontFamily: 'var(--font-display)', fontSize: 21, fontWeight: 700, color: 'var(--ink)', letterSpacing: -0.3 }}>
            Keine Verbindung
          </h2>
          <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 14, lineHeight: 1.55, color: 'var(--ink-2)', maxWidth: 280 }}>
            Wir konnten den Marktplatz gerade nicht laden. Bitte prüfe deine Internet-Verbindung – dann versuchen wir es nochmals.
          </p>
          <div style={{ marginTop: 22, width: '100%', maxWidth: 240, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Button full size="lg" leading={<Icon name="reload" size={18} color="#fff" stroke={2.2} />}>Nochmals versuchen</Button>
          </div>
        </div>

        <div style={{ padding: '0 18px 18px' }}>
          <ErrorNote
            title="Nachricht nicht gesendet"
            body="Deine Nachricht an Luan konnte nicht gesendet werden. Bitte versuche es nochmals."
            retryLabel="Nochmals senden"
            onRetry={() => {}} />
        </div>
      </Body>
      <TabBar active={1} />
    </Screen>
  );
}

Object.assign(window, { MF_HelpSheet, MF_Saved, MF_Delete, MF_Error });
