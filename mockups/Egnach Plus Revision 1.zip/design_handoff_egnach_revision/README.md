# Handoff: Egnach Plus — Revision 1 (Help & Feedback, Onboarding, Settings)

## Overview
This package documents Revision 1 of the **Egnach Plus** community app — a
civic neighbourhood app for the municipality of Egnach (marketplace / lending,
local events, neighbour-to-neighbour help, translated chat). This revision adds
three things and removes one:

1. **Help & feedback (2.3)** — a "?" help button + help sheet on every key
   screen, confirmation toasts, confirm dialogs, and friendly error messages.
2. **New onboarding (2.1 + 3.4)** — a shorter, symbol-led onboarding variant.
3. **Settings / customisability (3.7)** — an "Einfach-Modus", adjustable font
   size with live preview, granular notifications, and privacy options.
4. **Removed** all "offline" feature messaging (not part of this prototype).

The full, current changelog is in **`CHANGES.md`** (included in this bundle).

## About the Design Files
The files in this bundle are **design references created in HTML** — React
components transpiled in the browser with Babel, rendered inside a pannable
"design canvas". They show the intended **look and behaviour**; they are **not**
production code to copy directly.

The task is to **recreate these designs in the target codebase's existing
environment** (React, Vue, SwiftUI, Flutter, native, etc.) using its established
components, tokens, and patterns. If no front-end environment exists yet, choose
the most appropriate framework for the project and implement the designs there.

Entry point: **`Mockups.html`** loads `mockups/theme.jsx` (design tokens) →
`mockups/ui.jsx` (primitives) → `mockups/glyphs.jsx` (category glyphs) →
`mockups/feedback.jsx` → the screen files. To view, open `Mockups.html`; pan the
canvas and double-click any artboard to open it fullscreen.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, and interactions. Recreate
the UI faithfully using the codebase's own component library and design tokens.
All controls in the new Settings screen are genuinely interactive.

---

## Design Tokens
Tokens are CSS custom properties produced by `buildCssVars()` in
`mockups/theme.jsx`. Active brand palette is **"Egnach Wappen"**. Light theme
values:

### Colour
| Token | Value | Use |
|---|---|---|
| `--primary` | `#009944` | Heraldic green — primary actions, active states |
| `--primary-tint` | `#E0F2E7` | Tinted backgrounds, active chips |
| `--primary-ink` | `#00391A` | Text on tint |
| `--accent` | `#0093DD` | Heraldic blue — secondary accents |
| `--accent-tint` | `#D6EFFA` | Accent backgrounds |
| `--ink` | `#15202D` | Primary text |
| `--ink-2` | `#5A6478` | Secondary text |
| `--ink-3` | `#8B93A4` | Tertiary / hints |
| `--surface` | `#FBFAF7` | App background |
| `--surface-2` | `#F3F0E9` | Insets, icon chips |
| `--surface-3` | `#ECE8DE` | Deeper insets |
| `--card` | `#FFFFFF` | Card / sheet surfaces |
| `--line` | `#E4E0D5` | Hairline borders |
| `--line-2` | `#CFC9BB` | Stronger borders, switch off-track |
| `--success` | `#1F8A5B` | Success toast icon |
| `--danger` | `#C84B3F` | Destructive actions, errors |
| `--warning` | `#C9892A` | Warnings |

Success-toast green disc uses `#1F8A5B`; error uses `--danger`; the friendly
error block (`ErrorNote`) uses `#FBEAE7` bg / `#F0C8C1` border / `#7a1a15` title.

### Radius
`--radius` = 14px · `--radius-sm` = 8px (radius−6) · `--radius-lg` = 22px (radius+8).

### Type
- Body font `--font`: **Inter**, stack `'Inter', system-ui, sans-serif`.
- Display font `--font-display`: **Fraunces**, stack `'Fraunces', Georgia, serif`.
- Common sizes: section labels 11px/700/letter-spacing 1; body 13–16px;
  screen titles 24px/700 display; sheet titles 18px/700 display.

---

## Screens / Views

### A. Reusable feedback primitives (`mockups/feedback.jsx`)

**HelpButton** — round button, default 32×32, `border-radius:50%`,
bg `--surface-2`, 1px `--line` border, bold "?" at `0.5×size`. `ghost` tone is
transparent (used over photos as a 40×40 white translucent circle).

**HelpSheet** — bottom sheet. Scrim `rgba(13,22,34,0.42)`; sheet bg `--card`,
top corners `--radius-lg`, shadow `0 -10px 40px rgba(13,22,34,0.22)`, max-height
82%, slide-up animation 0.26s `cubic-bezier(0.22,1,0.36,1)`. 38×4 grab handle.
Header: 40px `--primary-tint` info-icon tile + title (18px/700 display) + intro
(13px `--ink-2`) + a 30px close circle. Body: list of items, each a 34px
`--surface-2` icon tile + title (13.5px/700) + text (12.5px `--ink-2`). Footer:
full-width primary "Verstanden" + a centred "Support kontaktieren" link.

**Toast** — absolutely positioned `left:14 right:14 bottom:<n>`, slide-up 0.3s.
Card bg `--card`, 1px `--line`, radius `--radius`, shadow
`0 12px 32px rgba(13,22,34,0.20)`, padding 12/14. 34px coloured status disc
(success `#1F8A5B`/check, error `--danger`/warning, info `--primary`/info) +
title (13.5px/700) + msg (12px `--ink-2`) + optional right-aligned text action
(13px/700 `--primary`). Auto-dismiss ~3200ms (caller-managed `setTimeout`).

**ConfirmDialog** — centred modal, max-width 320, padding 22/20/18, radius
`--radius-lg`, shadow `0 20px 60px rgba(13,22,34,0.32)`, pop-in 0.22s. 52px tint
disc (danger `#FAE5E2`/`--danger`, else `--primary-tint`/`--primary`) + title
(18px/700 display) + body (13px `--ink-2`) + two 48px buttons: cancel (outline,
1px `--line-2`) and confirm (solid accent). Tap scrim = cancel.

**ErrorNote** — inline block, bg `#FBEAE7`, 1px `#F0C8C1`, radius `--radius-sm`,
padding 14. 34px white disc with `--danger` warning icon + title (13px/700
`#7a1a15`) + body (12.5px `#8a3a33`) + optional 36px danger retry button.

### B. Updated existing screens
For each (see table in `CHANGES.md`): a "?" `HelpButton` was added to the header,
and primary actions now fire a `Toast` (e.g. "Anfrage gesendet",
"Inserat/Entwurf gespeichert", "Du bist dabei!", "Verfügbarkeit gespeichert") or
a `ConfirmDialog` ("Wirklich abmelden?", "Änderungen verwerfen?", delete listing).
Each help sheet contains 4 short, plain-German items.

### C. New onboarding (`mockups/screens-onboarding.jsx`)
4 frames. Each step: a "Überspringen" link top-right; a 248px rounded tinted
hero panel (radius 24) holding a 132px circular glyph disc; below, a 28px/700
display title and a ≤256px 16px line; footer has page `Dots` + a full-width
primary button. The overview frame is a 2×2 grid of cards (radius 20), each a
76px circular symbol disc + a 16px/700 label, with a "Loslegen" button.
Step tints: Helfen `#EFF3E2`, Leihen `#ECEFF3`, Anlässe `#FBEFE0`.

### D. New settings screen (`mockups/screens-settings.jsx`)
`M14_Settings({ defaultSimple })`. `TopBar` (back / "Einstellungen" / "?").
Scrolling body, `TabBar active={4}`.
- **Einfach-Modus card** — radius `--radius`, 1.5px border; when on, border/bg
  become `--primary`/`--primary-tint`, a 46px disc turns solid green, and a
  note row appears. Toggling it hides the advanced notification sub-rows and the
  read-receipts row.
- **Schriftgrösse** — 4 buttons labelled "A" at increasing sizes (12/15/18/21px);
  active = 1.5px `--primary` + `--primary-tint`. A "VORSCHAU" inset shows
  "Grüezi Anna!" + a line; the whole screen's text multiplies by
  `s ∈ {0.9, 1, 1.15, 1.32}`.
- **Benachrichtigungen** — master `ToggleRow` + (when on) sub-rows Nachrichten /
  Anlässe in der Nähe / Marktplatz-Antworten / Wochenübersicht.
- **Datenschutz** — `ChoiceRow` "Mein Profil sehen" (Alle / Verifizierte /
  Niemand), "Mein Standort" (Genau / Ungefähr / Aus), and a "Lesebestätigungen"
  toggle. Footer lock-note "Deine Daten bleiben bei der Gemeinde Egnach."
- "Speichern" → success toast "Einstellungen gespeichert".

**FlipSwitch** — 50×30 (sm 38×23), track radius = h/2, off `--line-2` / on
`--primary`, knob = h−6 white circle, 0.2s transition.

---

## Interactions & Behavior
- **Sheets/dialogs/toasts** are React-state driven; scrim tap closes sheets and
  dialogs. Toasts auto-dismiss after ~3.2s (`setTimeout`, cleared on unmount).
- **Chat error flow**: tapping send shows an error `Toast` with a "Nochmals"
  action; tapping it shows the success toast. (No offline/queue messaging.)
- **Settings**: every control mutates local state immediately; font-size changes
  reflow the screen live; Einfach-Modus shows/hides advanced rows.
- Animations: sheet slide 0.26s, toast slide 0.3s, dialog pop 0.22s — all
  `cubic-bezier(0.22,1,0.36,1)`; fades 0.18s ease.

## State Management
Per-screen local state only (no global store in the mock):
`help: boolean`, `toast: boolean | 'error' | 'success' | null`,
`confirm: boolean`. Settings adds: `simple`, `fontSize`, `notifAll`, `nMsg`,
`nEvents`, `nMarket`, `nDigest`, `profilePublic`, `location`, `readReceipts`.
In production, persist settings to the user profile/preferences store and apply
font scale + simple-mode app-wide.

## Assets
No raster assets in these new screens — all imagery is line icons
(`ICON_PATHS` in `ui.jsx`) and category glyphs (`glyphs.jsx`), drawn as inline
SVG. The civic "Wappen" mark (`Mark` component) may reference a crest image in
`mockups/assets/` for the onboarding overview; substitute the official Egnach
crest from your asset system.

## Files in this bundle
- `Mockups.html` — entry point / design canvas.
- `CHANGES.md` — full changelog for this revision.
- `mockups/theme.jsx` — design tokens (`buildCssVars`, palettes, fonts).
- `mockups/ui.jsx` — shared primitives (Button, Card, TopBar, Switch, Icon…).
- `mockups/glyphs.jsx` — category glyph SVGs.
- `mockups/feedback.jsx` — **new** help/toast/dialog/error primitives.
- `mockups/screens-1.jsx … screens-3.jsx` — existing screens (now wired for help/feedback).
- `mockups/screens-feedback.jsx` — **new** 2.3 showcase artboards.
- `mockups/screens-onboarding.jsx` — **new** onboarding variant.
- `mockups/screens-settings.jsx` — **new** settings / customisability screen.
- Other `mockups/screens-*.jsx` — supporting screens referenced by the canvas.
