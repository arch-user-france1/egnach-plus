# CHANGES.md — Egnach Plus, Revision 1

Changelog of all changes made in this revision, organised so they can be
re-applied to the production prototype. All work targets the HTML mockup
in `Mockups.html`, which loads a set of `*.jsx` files (Babel-in-browser
React) from `mockups/`.

> **Note on terminology:** these mockup files are *design references*, not
> production code. "Apply to the prototype" means recreating the same screens,
> components, copy, and interactions in the target codebase's own environment.

---

## New files

| File | Purpose |
|---|---|
| `mockups/feedback.jsx` | Reusable feedback primitives (help, toasts, dialogs, errors) |
| `mockups/screens-feedback.jsx` | Showcase artboards for the 2.3 help/feedback patterns |
| `mockups/screens-onboarding.jsx` | New, symbol-led onboarding version (2.1 + 3.4) |
| `mockups/screens-settings.jsx` | New settings / customisability screen (3.7) |

Each is registered in `Mockups.html` as a `<script type="text/babel" src="…">`.
Load order matters: `feedback.jsx` and `screens-settings.jsx` must load
**before** the screen files that use their exports. `<FeedbackStyles />`
is mounted **once** at the app root (keyframes for sheets/toasts/dialogs).

---

## 2.3 — Fehlende Hilfe und Rückmeldungen

### New primitives — `mockups/feedback.jsx` (exported to `window`)
- **`HelpButton`** — small round "?" for headers. Props: `onClick`, `size`, `tone` (`soft` | `ghost`).
- **`HelpSheet`** — bottom sheet with short, plain-German explanations.
  Props: `open`, `onClose`, `title`, `intro`, `items: [{ icon, title, text }]`.
  Footer has "Verstanden" + a "Support kontaktieren" link.
- **`Toast`** — confirmation/status banner. Props: `open`, `tone`
  (`success` | `error` | `info`), `title`, `msg`, `action: { label, onClick }`,
  `bottom`. Auto-dismiss handled by caller (≈3.2 s `setTimeout`).
- **`ConfirmDialog`** — "Möchtest du wirklich…?" modal. Props: `open`,
  `onCancel`, `onConfirm`, `tone` (`danger` | `primary`), `icon`, `title`,
  `body`, `cancelLabel`, `confirmLabel`.
- **`ErrorNote`** — friendly inline error block with retry. Props: `title`,
  `body`, `retryLabel`, `onRetry`.
- Helpers: `Scrim`, `Sheet`, `FeedbackStyles` (shared keyframes).

### Screens wired up
Each screen gained local state (`help` / `toast` / `confirm`), was wrapped in a
`<React.Fragment>`, got a "?" `HelpButton` in its header, and had toasts/dialogs
attached to its primary actions:

| Screen | Help | Confirmation toast | Confirm dialog / error |
|---|---|---|---|
| Login (`M02b_Login`) | ✓ | — | — |
| Registrierung (`M03_Register`) | ✓ | — | — |
| Verifikation (`M04_Verify`) | ✓ | — | — |
| Home (`M05_Home`) | ✓ | — | — |
| Marktplatz (`M06_Marketplace`) | ✓ | — | — |
| Inserat-Detail (`M07_ListingDetail`) | ✓ | "Anfrage gesendet" | — |
| Inserat erstellen (`M08_CreateListing`) | ✓ | "Entwurf gespeichert" | — |
| Anlässe (`M09_Events`) | ✓ | — | — |
| Anlass-Detail (`M10_EventDetail`) | ✓ | "Du bist dabei!" | — |
| Chat (`M11_Chat`) | ✓ | "Nachricht gesendet" | friendly send-error toast → retry |
| Profil (`M12_Profile`) | ✓ | "Du wurdest abgemeldet" | "Wirklich abmelden?" |
| Verfügbarkeit (`M13_Availability`) | ✓ | "Verfügbarkeit gespeichert" | "Änderungen verwerfen?" |

### Showcase section
`Mockups.html` gained section **"6 · Hilfe & Rückmeldungen"** with artboards
15–18 (`screens-feedback.jsx`): Hilfe-Sheet, Bestätigung, Löschen bestätigen,
Freundlicher Fehler — each shows a pattern in its open state.

---

## 2.1 + 3.4 — New onboarding — `mockups/screens-onboarding.jsx`

Shorter, symbol-led alternative: one large brand glyph + a few simple words
per step. Body 16 px, titles 28 px, centred.
- `M02_OnbV2_Help` — "Hilf mit. Lass dir helfen." (Garten glyph)
- `M02_OnbV2_Lend` — "Leihen statt kaufen." (Werkzeug glyph)
- `M02_OnbV2_Events` — "Sei dabei." (Party glyph)
- `M02_OnbV2_Overview` — 2×2 symbol grid (Anlässe / Leihen / Helfen / Karte)

Added as section **"1b · Onboarding — Neue Version"**, alongside the original
(original kept for comparison).

---

## 3.7 — Individualisierbarkeit — `mockups/screens-settings.jsx`

New, fully-interactive `M14_Settings({ defaultSimple })` screen with local
primitives `FlipSwitch`, `ToggleRow`, `ChoiceRow`, `SectionLabel`:

- **Einfach-Modus** — prominent toggle; when on, hides advanced options and
  shows a confirmation note (and presets a larger font in the `defaultSimple` artboard).
- **Schriftgrösse** — 4 steps (Klein / Normal / Gross / Sehr gross) with a
  **live preview** that scales the whole view via a font multiplier `s`.
- **Benachrichtigungen** — master switch + granular sub-toggles
  (Nachrichten, Anlässe, Marktplatz-Antworten, Wochenübersicht).
- **Datenschutz** — profile visibility (Alle / Verifizierte / Niemand),
  location precision (Genau / Ungefähr / Aus), read-receipts.
- "Speichern" → success toast; "?" → `HelpSheet`.

Added as section **"7 · Einstellungen & Individualisierbarkeit"** with
artboards **14 (Standard)** and **14b (Einfach-Modus)**.

---

## Copy edits

- **Bestätigung toast** (`screens-feedback.jsx`): "Nachbarn" → **"Interessenten"**.
- **Delete dialog** (`screens-feedback.jsx`): reworded to
  *"«Bohrhammer Bosch» wird gelöscht und ist danach nicht mehr sichtbar.
  Das kannst du nicht mehr rückgängig machen."*
- **Error screen** (`screens-feedback.jsx`): reworded to
  *"…Bitte prüfe deine Internet-Verbindung – dann versuchen wir es nochmals."*
  (removed awkward "kurz").

---

## Removed: offline feature

The prototype does **not** include an offline feature, so all offline mentions
were removed:
- `screens-feedback.jsx` — deleted the **"Offline weiterschauen"** button on the
  error screen.
- `screens-feedback.jsx` — `ErrorNote` no longer promises offline send
  ("…wird automatisch verschickt, sobald du wieder online bist" → *"…konnte
  nicht gesendet werden. Bitte versuche es nochmals."*).
- `screens-3.jsx` — chat send-error toast no longer says the message is saved
  offline ("Die Verbindung ist gerade unterbrochen. Keine Sorge – deine
  Nachricht ist gespeichert." → *"Das hat leider nicht geklappt. Bitte versuche
  es gleich nochmals."*).

> The "Online" presence dot in the chat header and "Inserat ist online" in the
> publish help text are **not** the offline feature and were left unchanged.

---

## How to apply to the prototype

1. Recreate the four primitive groups (`HelpButton`, `HelpSheet`, `Toast`,
   `ConfirmDialog`, `ErrorNote`, and the settings controls) as components in
   the target codebase.
2. For each existing screen, add the help/toast/confirm state, a "?" in the
   header, and wire toasts/dialogs to the relevant action buttons (table above).
3. Add the new onboarding flow and the settings screen; route to settings from
   Profil → "Einstellungen".
4. Apply the copy edits and ensure no offline messaging remains.
