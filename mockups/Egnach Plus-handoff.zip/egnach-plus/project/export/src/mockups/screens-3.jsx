// Egnach Plus — Mockup screens 11–13
// 11 Chat (Übersetzung)
// 12 Profil
// 13 Verfügbarkeit verwalten

// ─── 11 · Chat ───────────────────────────────────────────────
function M11_Chat() {
  // Bubble — bidirectional translation aware.
  // For incoming (!own): original SQ comes in; show DE translation on top,
  // SQ original below, so Anna sees what was actually written.
  // For outgoing (own): Anna writes DE; show her DE on top, plus a hint of
  // the SQ version Luan will read, so the translation loop is explicit.
  const Bubble = ({ own, text, translatedFrom, translatedTo, translation, time, translateOn }) => {
    const showTrans = translateOn && (translatedFrom || translatedTo);
    return (
    <div style={{ display: 'flex', justifyContent: own ? 'flex-end' : 'flex-start', gap: 8, alignItems: 'flex-end' }}>
      {!own && <Avatar size={28} initials="LK" />}
      <div style={{ maxWidth: '78%' }}>
        <div style={{
          padding: '10px 14px',
          borderRadius: own ? '16px 16px 4px 16px' : '4px 16px 16px 16px',
          background: own ? 'var(--primary)' : 'var(--card)',
          color: own ? '#fff' : 'var(--ink)',
          border: own ? 'none' : '1px solid var(--line)',
          fontFamily: 'var(--font)', fontSize: 13, lineHeight: 1.45,
        }}>
          {showTrans && translatedFrom && (
            <div style={{
              fontFamily: 'var(--font)', fontSize: 10, fontWeight: 700, letterSpacing: 0.5,
              color: 'var(--accent)',
              display: 'flex', alignItems: 'center', gap: 4, marginBottom: 5,
              textTransform: 'uppercase',
            }}>
              <Icon name="language" size={11} stroke={2}/>
              Übersetzt aus {translatedFrom}
            </div>
          )}
          {/* Main text: incoming uses the translation; outgoing uses the original (what Anna typed). */}
          <div>{showTrans && translatedFrom ? translation : text}</div>
          {showTrans && translatedFrom && (
            <div style={{
              marginTop: 8, paddingTop: 8,
              borderTop: '1px solid var(--line)',
              fontFamily: 'var(--font)', fontSize: 11, opacity: 0.65,
              fontStyle: 'italic',
            }}>{text}</div>
          )}
          {showTrans && translatedTo && (
            <div style={{
              marginTop: 8, paddingTop: 8,
              borderTop: '1px solid rgba(255,255,255,0.22)',
              fontFamily: 'var(--font)', fontSize: 11, lineHeight: 1.4,
            }}>
              <div style={{
                fontFamily: 'var(--font)', fontSize: 10, fontWeight: 700, letterSpacing: 0.5,
                color: 'rgba(255,255,255,0.75)',
                display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4,
                textTransform: 'uppercase',
              }}>
                <Icon name="language" size={11} stroke={2} color="rgba(255,255,255,0.75)"/>
                Gesendet an Luan auf {translatedTo}
              </div>
              <div style={{ opacity: 0.92, fontStyle: 'italic' }}>{translation}</div>
            </div>
          )}
        </div>
        <div style={{
          fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)',
          marginTop: 4, textAlign: own ? 'right' : 'left',
        }}>
          {time}{own && ' · Gelesen'}
        </div>
      </div>
    </div>
    );
  };

  return (
    <Screen background="var(--surface)">
      {/* Custom header */}
      <div style={{
        padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 10,
        background: 'var(--surface)', borderBottom: '1px solid var(--line)',
      }}>
        <IconButton name="back" />
        <Avatar size={36} initials="LK" verified />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>Luan Krasniqi</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}>
            <span style={{ width: 7, height: 7, borderRadius: 3.5, background: 'var(--success)' }}/>
            <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>Online · spricht SQ · DE</span>
          </div>
        </div>
        <IconButton name="bell" />
        <IconButton name="options" />
      </div>

      {/* Translate banner */}
      <div style={{
        margin: 12, padding: '10px 12px',
        background: 'var(--accent-tint)', borderRadius: 'var(--radius-sm)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8, background: 'var(--accent)',
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="language" size={18} stroke={2}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: '#5e2410' }}>Übersetzung aktiv · SQ → DE</div>
          <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: '#7a3318', marginTop: 1 }}>Eingehende Nachrichten werden auf Deutsch übersetzt</div>
        </div>
        <Switch on size="sm" />
      </div>

      {/* Messages */}
      <div style={{ flex: 1, padding: '4px 14px 14px', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ textAlign: 'center', margin: '4px 0' }}>
          <span style={{
            fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)',
            background: 'var(--surface-2)', padding: '4px 12px', borderRadius: 999,
          }}>Heute · 09:30</span>
        </div>
        <Bubble
          translatedFrom="SQ"
          text="Përshëndetje! A është bohrhammer-i ende i lirë për fundjavën?"
          translation="Grüezi! Ist der Bohrhammer am Wochenende noch frei?"
          time="09:32"
          translateOn
        />
        <Bubble
          own
          text="Hoi Luan, ja — Samstag und Sonntag passt. Komm um 9 vorbei."
          translatedTo="SQ"
          translation="Tungjatjeta Luan, po — e shtuna dhe e diela më shkojnë. Eja rreth orës 9."
          time="09:42"
          translateOn
        />
        <Bubble
          translatedFrom="SQ"
          text="Faleminderit! A duhet të sjell diçka? Kaucionin?"
          translation="Danke! Soll ich etwas mitbringen? Die Kaution?"
          time="09:44"
          translateOn
        />
        <Bubble
          own
          text="Nur einen Ausweis und CHF 50 Kaution in bar."
          translatedTo="SQ"
          translation="Vetëm një dokument identifikimi dhe 50 CHF kaucion në para të gatshme."
          time="09:45"
          translateOn
        />
        <div style={{
          alignSelf: 'flex-start',
          padding: '8px 14px', borderRadius: '4px 16px 16px 16px',
          background: 'var(--card)', border: '1px solid var(--line)',
          display: 'flex', gap: 4,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 3, background: 'var(--ink-3)', animation: 'egnach-typ 1.4s infinite' }} />
          <span style={{ width: 6, height: 6, borderRadius: 3, background: 'var(--ink-3)', animation: 'egnach-typ 1.4s 0.2s infinite' }} />
          <span style={{ width: 6, height: 6, borderRadius: 3, background: 'var(--ink-3)', animation: 'egnach-typ 1.4s 0.4s infinite' }} />
          <style>{`@keyframes egnach-typ { 0%, 60%, 100% { opacity: 0.3; } 30% { opacity: 1; } }`}</style>
        </div>
      </div>

      {/* Composer */}
      <div style={{
        padding: '10px 12px 18px', borderTop: '1px solid var(--line)',
        background: 'var(--card)',
        display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <IconButton name="plus" />
        <div style={{
          flex: 1, height: 40, borderRadius: 20, background: 'var(--surface-2)',
          padding: '0 16px', display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ flex: 1, fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-3)' }}>Nachricht schreiben…</span>
          <Icon name="image" size={18} color="var(--ink-3)" />
          <Icon name="mic"   size={18} color="var(--ink-3)" />
        </div>
        <button style={{
          width: 40, height: 40, borderRadius: 20,
          background: 'var(--primary)', color: '#fff', border: 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon name="send" size={18} color="#fff" stroke={2}/></button>
      </div>
    </Screen>
  );
}

// ─── 12 · Profil ─────────────────────────────────────────────
function M12_Profile() {
  const Row = ({ icon, label, value, toggle, last }) => (
    <div style={{
      padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
      borderBottom: last ? 'none' : '1px solid var(--line)',
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 8,
        background: 'var(--surface-2)', color: 'var(--ink-2)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={16} stroke={1.8}/>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 500, color: 'var(--ink)' }}>{label}</div>
        {value && <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 1 }}>{value}</div>}
      </div>
      {toggle !== undefined
        ? <Switch on={toggle} size="sm" />
        : <Icon name="chevron" size={14} color="var(--ink-3)" stroke={2}/>}
    </div>
  );

  return (
    <Screen background="var(--surface)">
      <div style={{ padding: '10px 16px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: -0.4, color: 'var(--ink)' }}>Profil</h1>
        <IconButton name="options" />
      </div>

      <Body>
        {/* Hero */}
        <div style={{ padding: '12px 16px 18px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <Avatar size={84} initials="AM" verified />
          <div style={{ textAlign: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 700, color: 'var(--ink)' }}>Anna Müller</span>
              <Badge tone="success" size="md"><Icon name="check" size={10} stroke={3} color="#155E3E"/> Verifiziert</Badge>
            </div>
            <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)', marginTop: 4 }}>
              Egnach Dorf · seit Mai 2024
            </div>
          </div>
          <div style={{ display: 'flex', gap: 28, marginTop: 4 }}>
            {[
              { n: 12, l: 'Anlässe' },
              { n: 8,  l: 'Inserate' },
              { n: 4.9,l: '⭐ 23' },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>{s.n}</div>
                <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 1, letterSpacing: 0.3 }}>{s.l}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8, width: '100%', marginTop: 6 }}>
            <div style={{ flex: 1 }}><Button full size="md" variant="outline" leading={<Icon name="edit" size={14}/>}>Bearbeiten</Button></div>
            <div style={{ flex: 1 }}><Button full size="md" variant="outline" leading={<Icon name="share" size={14}/>}>Teilen</Button></div>
          </div>
        </div>

        {/* Kompetenzen */}
        <div style={{ padding: '4px 16px 12px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 0.8 }}>KOMPETENZEN</span>
            <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--primary)' }}>+ Hinzufügen</span>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <Chip tone="primary">Gartenarbeit</Chip>
            <Chip tone="primary">Übersetzen DE/EN</Chip>
            <Chip tone="primary">Kinderhüten</Chip>
            <Chip tone="soft">+ 2 weitere</Chip>
          </div>
        </div>

        {/* Section: Einstellungen */}
        <div style={{ padding: '12px 16px 6px', fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1 }}>EINSTELLUNGEN</div>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <Row icon="bell"     label="Benachrichtigungen" toggle={true} />
          <Row icon="globe"    label="Sprache & Region" value="Deutsch · Schweiz" />
          <Row icon="language" label="Auto-Übersetzung" value="Aktiv für EN, SQ, IT" toggle={true} />
          <Row icon="pin"      label="Mein Quartier" value="Egnach Dorf" last />
        </Card>

        {/* Section: Barrierefreiheit */}
        <div style={{ padding: '20px 16px 6px', fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1 }}>BARRIEREFREIHEIT</div>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <Row icon="info"     label="Grosser Text" toggle={false} />
          <Row icon="image"    label="Hoher Kontrast" toggle={false} />
          <Row icon="mic"      label="Sprachausgabe" toggle={false} last />
        </Card>

        {/* Section: Sicherheit */}
        <div style={{ padding: '20px 16px 6px', fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1 }}>KONTO &amp; SICHERHEIT</div>
        <Card padding={0} style={{ margin: '0 16px' }}>
          <Row icon="shield"   label="Verifizierung" value="Verifiziert · Mai 2025" />
          <Row icon="lock"     label="Passkey verwalten" />
          <Row icon="info"     label="Hilfe &amp; Support" last />
        </Card>

        <div style={{ padding: '24px 16px 16px' }}>
          <Button full size="md" variant="danger">Abmelden</Button>
        </div>
        <div style={{ textAlign: 'center', padding: '0 16px 16px', fontFamily: 'var(--font)', fontSize: 10, color: 'var(--ink-3)' }}>
          Egnach Plus · v1.0.0 · Gemeinde Egnach
        </div>
      </Body>

      <TabBar active={4} />
    </Screen>
  );
}

// ─── 13 · Verfügbarkeit ──────────────────────────────────────
function M13_Availability() {
  const states = {
    3: 'partial', 4: 'partial', 7: 'booked', 10: 'booked',
    12: 'selected', 13: 'selected', 14: 'selected',
    18: 'partial', 21: 'booked', 25: 'partial',
  };
  const days = [];
  for (let i = 0; i < 2; i++) days.push({ empty: true });
  for (let d = 1; d <= 30; d++) days.push({ d });
  while (days.length < 35) days.push({ empty: true });

  const Slot = ({ from, to, label, booked }) => (
    <div style={{
      padding: '12px 14px',
      borderRadius: 'var(--radius-sm)',
      background: booked ? 'var(--surface-2)' : 'var(--card)',
      border: `1px solid ${booked ? 'var(--line)' : 'var(--line)'}`,
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 8,
        background: booked ? 'var(--accent-tint)' : 'var(--primary-tint)',
        color: booked ? '#7a3318' : 'var(--primary)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}><Icon name={booked ? 'log' : 'calendar'} size={16} stroke={2}/></div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)', fontVariantNumeric: 'tabular-nums' }}>
          {from} <span style={{ color: 'var(--ink-3)', fontWeight: 500 }}>–</span> {to}
        </div>
        <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{label}</div>
      </div>
      {booked
        ? <Badge tone="accent" size="sm">GEBUCHT</Badge>
        : <Icon name="chevron" size={14} color="var(--ink-3)" stroke={2}/>}
    </div>
  );

  return (
    <Screen background="var(--surface)">
      <TopBar
        leading={<IconButton name="back" />}
        title="Verfügbarkeit"
        trailing={<IconButton name="info" />}
      />

      <Body padding="0 0 8px">
        <div style={{ padding: '14px 18px 4px' }}>
          <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)' }}>
            Wann bist du verfügbar?
          </h2>
          <p style={{ margin: '4px 0 0', fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>
            Tippe einen Tag, um Zeitfenster zu setzen. Wöchentlich wiederholend möglich.
          </p>
        </div>

        {/* Segmented */}
        <div style={{ padding: '12px 18px' }}>
          <div style={{
            height: 36, borderRadius: 18, padding: 3,
            background: 'var(--surface-2)', border: '1px solid var(--line)',
            display: 'flex', gap: 4,
          }}>
            {['Monat','Woche','Tag'].map((l, i) => (
              <div key={i} style={{
                flex: 1, borderRadius: 14,
                background: i === 0 ? 'var(--card)' : 'transparent',
                boxShadow: i === 0 ? '0 1px 2px rgba(15,30,55,0.06)' : 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--font)', fontSize: 12, fontWeight: i === 0 ? 700 : 500,
                color: i === 0 ? 'var(--ink)' : 'var(--ink-3)',
              }}>{l}</div>
            ))}
          </div>
        </div>

        {/* Month header */}
        <div style={{ padding: '4px 18px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconButton name="back" />
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700, color: 'var(--ink)' }}>Juni</span>
            <span style={{ fontFamily: 'var(--font)', fontSize: 14, color: 'var(--ink-3)', fontVariantNumeric: 'tabular-nums' }}>2026</span>
          </div>
          <IconButton name="chevron" />
        </div>

        {/* Weekday header */}
        <div style={{ padding: '0 18px', display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginBottom: 4 }}>
          {['M','D','M','D','F','S','S'].map((d, i) => (
            <div key={i} style={{ textAlign: 'center', fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 0.5 }}>{d}</div>
          ))}
        </div>

        {/* Days grid */}
        <div style={{ padding: '0 18px', display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
          {days.map((cell, i) => {
            if (cell.empty) return <div key={i} style={{ aspectRatio: '1' }} />;
            const s = states[cell.d];
            const sel = s === 'selected';
            const booked = s === 'booked';
            const partial = s === 'partial';
            return (
              <div key={i} style={{
                aspectRatio: '1',
                borderRadius: 10,
                background: sel ? 'var(--primary)' : booked ? 'var(--surface-3)' : partial ? 'var(--primary-tint)' : 'transparent',
                border: `1px solid ${sel ? 'var(--primary)' : booked ? 'var(--line-2)' : 'transparent'}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                color: sel ? '#fff' : booked ? 'var(--ink-3)' : 'var(--ink)',
                position: 'relative',
                opacity: booked ? 0.7 : 1,
              }}>
                <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: sel ? 700 : 500, fontVariantNumeric: 'tabular-nums' }}>{cell.d}</span>
                {partial && !sel && (
                  <div style={{ position: 'absolute', bottom: 4, width: 4, height: 4, borderRadius: 2, background: 'var(--primary)' }}/>
                )}
                {booked && (
                  <div style={{ position: 'absolute', bottom: 4, width: 12, height: 2, background: 'var(--ink-3)' }}/>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div style={{ padding: '12px 18px 12px', display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          {[
            { l: 'Frei',      sw: { border: '1px dashed var(--line-2)' } },
            { l: 'Teilweise', sw: { background: 'var(--primary-tint)', border: '1px solid var(--primary-tint)' } },
            { l: 'Gebucht',   sw: { background: 'var(--surface-3)' } },
            { l: 'Auswahl',   sw: { background: 'var(--primary)' } },
          ].map((it, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 14, height: 14, borderRadius: 4, ...it.sw }} />
              <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-2)', fontWeight: 500 }}>{it.l}</span>
            </div>
          ))}
        </div>

        <div style={{ height: 1, background: 'var(--line)', margin: '4px 18px' }}/>

        {/* Selected day */}
        <div style={{ padding: '14px 18px 10px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>Samstag, 13. Juni</div>
            <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>3 Zeitfenster · 1 gebucht</div>
          </div>
          <span style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600, color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon name="plus" size={12} stroke={2.2}/> Zeitfenster
          </span>
        </div>

        <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <Slot from="09:00" to="11:00" label="Wiederholt wöchentlich" />
          <Slot from="13:30" to="15:00" label="Maja R. · Gartenarbeit" booked />
          <Slot from="16:00" to="18:00" label="Einmalig" />
        </div>

        {/* New slot card */}
        <div style={{ padding: '14px 18px 4px' }}>
          <div style={{
            borderRadius: 'var(--radius)', padding: 14,
            border: '1.5px dashed var(--line-2)',
            background: 'var(--surface-2)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>Neues Zeitfenster</span>
              <Icon name="close" size={16} color="var(--ink-3)" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Von" required value="19:00" hint="HH:MM" />
              <Field label="Bis" required value="20:30" hint="HH:MM" />
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12 }}>
              <Checkbox on />
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-2)' }}>Wöchentlich wiederholen</span>
            </label>
          </div>
        </div>

        <div style={{ padding: '14px 18px 8px' }}>
          <HelpBanner tone="info" title="Hinweis">
            Setze realistische Zeitfenster — Nachbarn können nur deine freien Slots anfragen. Du erhältst eine Push-Benachrichtigung bei neuen Anfragen.
          </HelpBanner>
        </div>
      </Body>

      <div style={{ padding: '10px 16px 12px', background: 'var(--card)', borderTop: '1px solid var(--line)', display: 'flex', gap: 10 }}>
        <div style={{ flex: 1 }}><Button full size="lg" variant="outline">Verwerfen</Button></div>
        <div style={{ flex: 1 }}><Button full size="lg">Speichern</Button></div>
      </div>

      <TabBar active={4} />
    </Screen>
  );
}

Object.assign(window, { M11_Chat, M12_Profile, M13_Availability });
