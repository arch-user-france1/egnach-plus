// Egnach Plus — Mockup screens 01–05
// 01 Splash + Sprache
// 02 Onboarding
// 02b Login
// 03 Registrierung
// 04 Identitätsverifikation
// 05 Home / Feed

// ─── 01 · Splash / Sprache ───────────────────────────────────
function M01_Splash() {
  const langs = [
    { code: 'de', label: 'Deutsch',     sub: 'Schweiz',     on: true },
    { code: 'en', label: 'English',     sub: 'Switzerland' },
    { code: 'it', label: 'Italiano',    sub: 'Svizzera' },
    { code: 'sq', label: 'Shqip',       sub: 'Zvicra' },
    { code: 'tr', label: 'Türkçe',      sub: 'İsviçre' },
    { code: 'pt', label: 'Português',   sub: 'Suíça' },
  ];
  return (
    <Screen background="var(--surface)" scroll>
      {/* Hero — soft lake-blue gradient + brand */}
      <div style={{
        padding: '36px 28px 28px',
        background: 'linear-gradient(180deg, var(--primary-tint) 0%, var(--surface) 100%)',
      }}>
        <Mark size={84} variant="wappen" />
        <h1 style={{
          margin: '20px 0 8px', fontFamily: 'var(--font-display)',
          fontSize: 30, lineHeight: 1.1, fontWeight: 700, letterSpacing: -0.8,
          color: 'var(--ink)',
        }}>Willkommen in<br/>Egnach.</h1>
        <p style={{
          margin: 0, fontFamily: 'var(--font)', fontSize: 14, lineHeight: 1.5,
          color: 'var(--ink-2)', maxWidth: 280,
        }}>Das digitale Dorfzentrum für Anlässe, Nachbarschaftshilfe und den lokalen Marktplatz.</p>
      </div>

      {/* Language selection */}
      <div style={{ padding: '22px 20px 20px', flex: 1 }}>
        <div style={{
          fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700,
          color: 'var(--ink-3)', letterSpacing: 1.2, marginBottom: 10,
        }}>SPRACHE · LANGUAGE · LINGUA</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {langs.map(l => (
            <div key={l.code} style={{
              padding: '12px 14px', borderRadius: 'var(--radius-sm)',
              border: `1.5px solid ${l.on ? 'var(--primary)' : 'var(--line)'}`,
              background: l.on ? 'var(--primary-tint)' : 'var(--card)',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: 'var(--surface-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700,
                color: 'var(--ink-2)', letterSpacing: 0.5,
              }}>{l.code.toUpperCase()}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{l.label}</div>
                <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', marginTop: 1 }}>{l.sub}</div>
              </div>
              {l.on && <Icon name="check" size={18} color="var(--primary)" stroke={2.4} />}
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '14px 20px 26px', borderTop: '1px solid var(--line)', background: 'var(--card)', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Button full size="lg">Loslegen</Button>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
          <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>Schon dabei?</span>
          <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--primary)', fontWeight: 600 }}>Anmelden</span>
        </div>
      </div>
    </Screen>
  );
}

// ─── 02 · Onboarding (1 of 3) ────────────────────────────────
function M02_Onboarding() {
  return (
    <Screen background="var(--surface)">
      <div style={{ padding: '12px 20px 0', display: 'flex', justifyContent: 'flex-end' }}>
        <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 600, color: 'var(--ink-2)' }}>Überspringen</span>
      </div>

      <div style={{ flex: 1, padding: '14px 28px 0', display: 'flex', flexDirection: 'column', gap: 24, overflow: 'hidden' }}>
        {/* Schematic illustration — abstract village + lake */}
        <div style={{
          height: 240, borderRadius: 22,
          background: `linear-gradient(180deg, var(--primary-tint) 0%, #F1E8DA 100%)`,
          position: 'relative', overflow: 'hidden',
          border: '1px solid var(--line)',
        }}>
          {/* sun */}
          <div style={{ position: 'absolute', top: 28, right: 36, width: 44, height: 44, borderRadius: '50%', background: 'var(--accent)', opacity: 0.85 }} />
          {/* hills */}
          <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 320 240" preserveAspectRatio="none" width="100%" height="100%">
            <path d="M0 160 Q60 130 120 150 T240 140 T320 150 V200 H0 Z" fill="rgba(62,124,74,0.55)"/>
            <path d="M0 180 Q80 160 160 175 T320 172 V200 H0 Z" fill="rgba(62,124,74,0.85)"/>
          </svg>
          {/* houses */}
          <div style={{ position: 'absolute', left: 60, bottom: 60, display: 'flex', alignItems: 'flex-end', gap: 4 }}>
            <div style={{ width: 28, height: 36, background: '#fff', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -10, left: -2, right: -2, height: 12, background: 'var(--accent)', clipPath: 'polygon(0 100%, 50% 0, 100% 100%)' }}/>
            </div>
            <div style={{ width: 22, height: 28, background: '#fff', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -8, left: -2, right: -2, height: 10, background: '#9D3B2B', clipPath: 'polygon(0 100%, 50% 0, 100% 100%)' }}/>
            </div>
            <div style={{ width: 30, height: 42, background: '#fff', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -12, left: -2, right: -2, height: 14, background: 'var(--accent)', clipPath: 'polygon(0 100%, 50% 0, 100% 100%)' }}/>
            </div>
          </div>
          {/* lake band */}
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 56, background: 'linear-gradient(180deg, rgba(37,99,168,0.35), rgba(37,99,168,0.55))' }}>
            <svg style={{ width: '100%', height: '100%' }} viewBox="0 0 320 56" preserveAspectRatio="none">
              <path d="M0 14 Q40 8 80 14 T160 14 T240 14 T320 14" stroke="rgba(255,255,255,0.45)" strokeWidth="1.2" fill="none"/>
              <path d="M0 30 Q40 24 80 30 T160 30 T240 30 T320 30" stroke="rgba(255,255,255,0.35)" strokeWidth="1.2" fill="none"/>
            </svg>
          </div>
        </div>

        <div>
          <Badge tone="primary" size="sm">SCHRITT 1 VON 3</Badge>
          <h2 style={{ margin: '12px 0 8px', fontFamily: 'var(--font-display)', fontSize: 26, lineHeight: 1.15, fontWeight: 700, letterSpacing: -0.5, color: 'var(--ink)' }}>
            Egnach in deiner Hand.
          </h2>
          <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 14, lineHeight: 1.55, color: 'var(--ink-2)' }}>
            Entdecke Anlässe der Gemeinde und Vereine, leihe vom Nachbarn, biete deine Hilfe an — alles an einem Ort.
          </p>
        </div>
      </div>

      <div style={{ padding: '18px 24px 28px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Dots count={3} active={0} accent="var(--primary)" />
        <Button full size="lg" trailing={<Icon name="arrowSmall" size={18} color="#fff" stroke={2.2}/>}>Weiter</Button>
      </div>
    </Screen>
  );
}

// ─── 02b · Login ─────────────────────────────────────────────
function M02b_Login() {
  return (
    <Screen background="var(--surface)">
      <TopBar leading={<IconButton name="back" />} title="Anmelden" />
      <Body padding="20px 22px">
        <h2 style={{ margin: '4px 0 6px', fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)' }}>
          Willkommen zurück.
        </h2>
        <p style={{ margin: '0 0 22px', fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5 }}>
          Melde dich mit Passkey an — schnell, sicher und ohne Passwort.
        </p>

        {/* Passkey card (primary) */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 11, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1.2, marginBottom: 8 }}>EMPFOHLEN</div>
          <div style={{
            border: '1.5px solid var(--primary)', borderRadius: 'var(--radius)',
            background: 'var(--primary-tint)', padding: 16,
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12, background: 'var(--card)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--primary)',
            }}>
              <Icon name="fingerprint" size={24} stroke={1.8} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--primary-ink)' }}>Mit Passkey anmelden</div>
              <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-2)', marginTop: 2 }}>Face ID · Touch ID · Geräte-PIN</div>
            </div>
            <Icon name="chevron" size={18} color="var(--primary-ink)" stroke={2}/>
          </div>
        </div>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
          <div style={{ flex: 1, height: 1, background: 'var(--line)' }} />
          <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)', letterSpacing: 0.5 }}>ODER MIT E-MAIL</span>
          <div style={{ flex: 1, height: 1, background: 'var(--line)' }} />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Field label="E-Mail" placeholder="name@example.ch" value="anna.mueller@example.ch"
                 leading={<Icon name="globe" size={16} color="var(--ink-3)" />} />
          <div>
            <Field label="Passwort" value="••••••••••"
                   leading={<Icon name="lock" size={16} color="var(--ink-3)" />}
                   trailing={<span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-2)', fontWeight: 600 }}>Zeigen</span>} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, alignItems: 'center' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Checkbox on />
                <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-2)' }}>Angemeldet bleiben</span>
              </label>
              <span style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--primary)', fontWeight: 600 }}>Vergessen?</span>
            </div>
          </div>
        </div>

        <div style={{ marginTop: 20 }}>
          <Button full size="lg" variant="outline">Mit E-Mail anmelden</Button>
        </div>

        <div style={{ marginTop: 18 }}>
          <HelpBanner tone="info" title="Probleme beim Anmelden?">
            Schreibe uns oder ruf direkt im Gemeindehaus an: 071 474 11 11 (Mo–Fr, 08:00–11:30).
          </HelpBanner>
        </div>
      </Body>

      <div style={{ padding: '12px 22px 24px', borderTop: '1px solid var(--line)', background: 'var(--card)', textAlign: 'center' }}>
        <span style={{ fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)' }}>Noch kein Konto? </span>
        <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: 'var(--primary)' }}>Konto erstellen</span>
      </div>
    </Screen>
  );
}

// ─── 03 · Registrierung ──────────────────────────────────────
function M03_Register() {
  return (
    <Screen background="var(--surface)">
      <TopBar leading={<IconButton name="back" />} title="Konto erstellen" />
      <Body padding="16px 22px 24px">
        <div style={{ marginBottom: 14 }}>
          <Badge tone="primary" size="sm">SCHRITT 2 VON 4</Badge>
          <h2 style={{ margin: '10px 0 4px', fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)' }}>
            Erzähl uns von dir.
          </h2>
          <p style={{ margin: 0, fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>
            Pflichtfelder sind mit <span style={{ color: 'var(--danger)' }}>*</span> markiert.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Vorname" required value="Anna" />
            <Field label="Nachname" required value="Müller" />
          </div>
          <Field label="E-Mail-Adresse" required value="anna.mueller@example.ch"
                 hint="Wir senden dir einen Bestätigungslink." />
          <Field label="Telefonnummer" required value="+41 79 412 88 03"
                 hint="Format: +41 79 123 45 67" />
          <Field label="Geburtsdatum" required value="14.03.1992"
                 hint="TT.MM.JJJJ — du musst mind. 16 Jahre alt sein."
                 trailing={<Icon name="calendar" size={16} color="var(--ink-3)" />} />
          <Field label="Quartier" required placeholder="Egnach Dorf · Neuhof · Seefeld …"
                 trailing={<Icon name="chevronDown" size={14} color="var(--ink-3)" />} />
          <Field label="Passwort" required value="••••••••••••"
                 hint="Mind. 8 Zeichen, eine Zahl und ein Sonderzeichen."
                 leading={<Icon name="lock" size={16} color="var(--ink-3)" />} />
          <Field label="Passwort bestätigen" required value="••••••••••"
                 error="Die Passwörter stimmen nicht überein."
                 leading={<Icon name="lock" size={16} color="var(--ink-3)" />} />

          <label style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginTop: 4 }}>
            <Checkbox on />
            <span style={{ flex: 1, fontFamily: 'var(--font)', fontSize: 12, lineHeight: 1.5, color: 'var(--ink-2)' }}>
              Ich akzeptiere die <u>Nutzungsbedingungen</u> und die <u>Datenschutzerklärung</u> der Gemeinde Egnach.
            </span>
          </label>
        </div>
      </Body>

      <div style={{ padding: '12px 22px 24px', borderTop: '1px solid var(--line)', background: 'var(--card)', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Button full size="lg">Konto erstellen</Button>
        <div style={{ textAlign: 'center', fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>
          Schon dabei? <span style={{ color: 'var(--primary)', fontWeight: 700 }}>Anmelden</span>
        </div>
      </div>
    </Screen>
  );
}

// ─── 04 · Identitätsverifikation ─────────────────────────────
function M04_Verify() {
  const Stepper = ({ active = 1 }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, margin: '4px 0 8px' }}>
      {[1,2,3].map(n => {
        const done = n < active;
        const on = n === active;
        return (
          <React.Fragment key={n}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%',
              background: done ? 'var(--primary)' : on ? 'var(--primary-tint)' : 'var(--card)',
              border: `1.5px solid ${done || on ? 'var(--primary)' : 'var(--line-2)'}`,
              color: done ? '#fff' : on ? 'var(--primary-ink)' : 'var(--ink-3)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700,
            }}>{done ? <Icon name="check" size={14} stroke={2.4} color="#fff"/> : n}</div>
            {n < 3 && <div style={{ flex: 1, height: 2, background: done ? 'var(--primary)' : 'var(--line)' }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
  const checks = [
    { label: 'Vollständiger Name', done: true },
    { label: 'Geburtsdatum',       done: true },
    { label: 'Ausweisfoto',        done: false },
    { label: 'Foto-Selfie',        done: false },
  ];
  return (
    <Screen>
      <TopBar leading={<IconButton name="back" />} title="Verifikation" />
      <Body padding="14px 20px 16px">
        <Stepper active={2} />
        <p style={{ margin: '0 0 14px', fontFamily: 'var(--font)', fontSize: 12, color: 'var(--ink-3)' }}>
          Schritt 2 · Ausweis fotografieren
        </p>

        <h2 style={{ margin: '0 0 6px', fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, letterSpacing: -0.3, color: 'var(--ink)' }}>
          Bestätige deine Identität.
        </h2>
        <p style={{ margin: '0 0 18px', fontFamily: 'var(--font)', fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.55 }}>
          So wissen Nachbarn, dass du in Egnach wohnst. Deine Daten bleiben verschlüsselt — nur deine Verifikation ist sichtbar.
        </p>

        {/* Camera frame */}
        <div style={{
          height: 180, borderRadius: 'var(--radius)',
          background: 'var(--ink)', position: 'relative', overflow: 'hidden',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {/* ID card silhouette */}
          <div style={{
            width: 220, height: 130, borderRadius: 10,
            border: '2px dashed rgba(255,255,255,0.55)',
            position: 'relative',
            background: 'repeating-linear-gradient(135deg, rgba(255,255,255,0.04) 0 8px, transparent 8px 16px)',
          }}>
            <div style={{ position: 'absolute', left: 12, top: 12, width: 36, height: 46, borderRadius: 4, background: 'rgba(255,255,255,0.12)' }}/>
            <div style={{ position: 'absolute', left: 60, top: 18, width: 80, height: 6, background: 'rgba(255,255,255,0.25)', borderRadius: 2 }}/>
            <div style={{ position: 'absolute', left: 60, top: 32, width: 50, height: 5, background: 'rgba(255,255,255,0.18)', borderRadius: 2 }}/>
            <div style={{ position: 'absolute', left: 60, top: 46, width: 64, height: 5, background: 'rgba(255,255,255,0.18)', borderRadius: 2 }}/>
            {/* corners */}
            {[[8,8],[8,'auto'],[
              'auto',8],['auto','auto']].map(([t,b],i)=>(
              <div key={i} style={{
                position: 'absolute',
                top: i<2?8:undefined, bottom: i>=2?8:undefined,
                left: i%2===0?8:undefined, right: i%2===1?8:undefined,
                width: 14, height: 14,
                borderTop:    i<2 ?'2px solid #fff':'none',
                borderBottom: i>=2?'2px solid #fff':'none',
                borderLeft:   i%2===0?'2px solid #fff':'none',
                borderRight:  i%2===1?'2px solid #fff':'none',
              }}/>
            ))}
          </div>
          <span style={{
            position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)',
            fontFamily: 'var(--font)', fontSize: 11, color: 'rgba(255,255,255,0.85)',
            background: 'rgba(0,0,0,0.4)', padding: '4px 10px', borderRadius: 999,
          }}>Vorderseite scannen</span>
        </div>

        <div style={{ marginTop: 18 }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1, marginBottom: 10 }}>WAS WIR PRÜFEN</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {checks.map((c,i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 22, height: 22, borderRadius: '50%',
                  background: c.done ? 'var(--primary)' : 'transparent',
                  border: `1.5px solid ${c.done ? 'var(--primary)' : 'var(--line-2)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{c.done && <Icon name="check" size={12} stroke={2.6} color="#fff" />}</div>
                <span style={{ fontFamily: 'var(--font)', fontSize: 13, color: c.done ? 'var(--ink-2)' : 'var(--ink)', fontWeight: c.done ? 400 : 500 }}>{c.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 18 }}>
          <HelpBanner tone="info" title="Sicher & lokal">
            Die Verifizierung erfolgt einmalig und wird verschlüsselt gespeichert. Du erhältst danach das blaue Häkchen «Verifiziert».
          </HelpBanner>
        </div>
      </Body>

      <div style={{ padding: '12px 20px 24px', borderTop: '1px solid var(--line)', background: 'var(--card)', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Button full size="lg" leading={<Icon name="camera" size={18} color="#fff" />}>Ausweis fotografieren</Button>
        <Button full size="md" variant="ghost">Später erledigen</Button>
      </div>
    </Screen>
  );
}

// ─── 05 · Home / Feed ────────────────────────────────────────
function M05_Home() {
  return (
    <Screen background="var(--surface)">
      {/* Header */}
      <div style={{ padding: '10px 16px 12px', display: 'flex', alignItems: 'center', gap: 10, background: 'var(--surface)' }}>
        <Avatar size={40} initials="AM" verified />
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>Grüezi, Anna</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 1 }}>
            <Icon name="pin" size={12} color="var(--primary)" stroke={2}/>
            <span style={{ fontFamily: 'var(--font)', fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>Egnach Dorf</span>
            <Icon name="chevronDown" size={12} color="var(--ink-2)" stroke={2}/>
          </div>
        </div>
        <IconButton name="bell" badge="3" />
        <IconButton name="qr" />
      </div>

      <Body>
        {/* Search */}
        <div style={{ padding: '4px 16px 12px' }}>
          <div style={{
            height: 44, borderRadius: 22, background: 'var(--card)',
            border: '1px solid var(--line)', padding: '0 16px',
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <Icon name="search" size={18} color="var(--ink-3)"/>
            <span style={{ fontFamily: 'var(--font)', fontSize: 14, color: 'var(--ink-3)', flex: 1 }}>Suche in Egnach…</span>
            <Icon name="mic" size={16} color="var(--ink-3)" />
          </div>
        </div>

        {/* Quartier chips */}
        <HScroll padding="0 16px 4px">
          <Chip active>Alle Quartiere</Chip>
          <Chip>Egnach Dorf</Chip>
          <Chip>Neuhof</Chip>
          <Chip>Seefeld</Chip>
          <Chip>Buchen</Chip>
          <Chip>Steinebrunn</Chip>
        </HScroll>

        {/* Hero — community spotlight */}
        <div style={{ padding: '16px 16px 0' }}>
          <Card padding={0} style={{ overflow: 'hidden' }}>
            <div style={{
              height: 140, position: 'relative',
              background: `linear-gradient(135deg, var(--primary) 0%, #1a4f8a 100%)`,
              padding: '16px',
            }}>
              <div style={{ position: 'absolute', inset: 0, opacity: 0.15, background: `repeating-linear-gradient(135deg, transparent 0 12px, rgba(255,255,255,0.4) 12px 13px)` }}/>
              <Badge tone="accent" size="sm">DORFFEST</Badge>
              <h3 style={{ margin: '10px 0 4px', fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: '#fff', letterSpacing: -0.3, position: 'relative' }}>
                Hafenfest am Bodensee
              </h3>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, fontFamily: 'var(--font)', fontSize: 12, color: 'rgba(255,255,255,0.85)', position: 'relative' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="calendar" size={12} stroke={2}/> Sa, 14. Juni · 14:00</span>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="pin" size={12} stroke={2}/> Seefeld</span>
              </div>
            </div>
          </Card>
        </div>

        {/* In deiner Nähe — events */}
        <SectionHeader title="Anlässe diese Woche" action="Alle" />
        <HScroll>
          {[
            { title: 'Sommerlauf Egnach', date: 'Mi · 18:30', loc: 'Schulhaus', tone: 'moss', cat: 'Sport' },
            { title: 'Sprachcafé DE/EN',  date: 'Do · 19:00', loc: 'Bibliothek', tone: 'lake', cat: 'Sprache' },
            { title: 'Senioren-Zmittag',  date: 'Fr · 11:30', loc: 'Gemeindesaal', tone: 'sand', cat: 'Senioren' },
          ].map((e,i) => (
            <Card key={i} padding={0} style={{ width: 200, flexShrink: 0, overflow: 'hidden' }}>
              <Photo height={104} tone={e.tone} radius={0} hint={e.cat} />
              <div style={{ padding: 12 }}>
                <Badge tone="neutral" size="sm">{e.cat}</Badge>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: 'var(--ink)', marginTop: 8, lineHeight: 1.3 }}>{e.title}</div>
                <div style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-2)', marginTop: 4 }}>{e.date} · {e.loc}</div>
              </div>
            </Card>
          ))}
        </HScroll>

        {/* In deiner Nähe — Marktplatz */}
        <SectionHeader title="Aus der Nachbarschaft" action="Marktplatz" />
        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { title: 'Bohrhammer Bosch GBH', sub: 'Leihen · CHF 12 / Tag', loc: 'Egnach Dorf · 400 m', avatar: 'TH', tone: 'sand' },
            { title: 'Gartenarbeit am Samstag', sub: 'Dienste · CHF 35 / Std.', loc: 'Neuhof · 1.2 km', avatar: 'MR', tone: 'moss' },
          ].map((l,i) => (
            <Card key={i} padding={10}>
              <div style={{ display: 'flex', gap: 12 }}>
                <Photo width={64} height={64} tone={l.tone} hint="bild" />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'var(--font)', fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>{l.title}</div>
                  <div style={{ fontFamily: 'var(--font)', fontSize: 12, color: 'var(--primary)', fontWeight: 600, marginTop: 2 }}>{l.sub}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
                    <Avatar size={22} initials={l.avatar} />
                    <span style={{ fontFamily: 'var(--font)', fontSize: 11, color: 'var(--ink-3)' }}>{l.loc}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div style={{ height: 24 }} />
      </Body>

      <TabBar active={0} />
    </Screen>
  );
}

Object.assign(window, { M01_Splash, M02_Onboarding, M02b_Login, M03_Register, M04_Verify, M05_Home });
