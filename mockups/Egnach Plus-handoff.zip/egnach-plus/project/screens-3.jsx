// Egnach Plus — Screens 10-12

// ─── 10 Anlass Detail ───────────────────────────────────────
function S10_EventDetail() {
  return (
    <Screen pad={false} scroll>
      <div style={{ padding: '8px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <svg width="20" height="20" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <div style={{ display: 'flex', gap: 12 }}>
          <Icon s={20} />
          <Icon s={20} />
        </div>
      </div>

      <div style={{ padding: '0 16px' }}>
        <ImgBox h={170} />
      </div>

      <div style={{ padding: '16px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Bar w={240} h={16} />
        <div style={{ display: 'flex', gap: 6 }}>
          <Chip>Kategorie</Chip>
          <Chip>Familie</Chip>
        </div>
      </div>

      <Hr />

      <div style={{ padding: '4px 16px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <Icon s={20} />
          <div style={{ flex: 1 }}>
            <Bar w={140} h={9} />
            <Bar w={100} h={7} mt={5} soft />
          </div>
          <L size={11} weight={600} c={W.ink}>+ Kalender</L>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <Icon s={20} />
          <div style={{ flex: 1 }}>
            <Bar w={160} h={9} />
            <Bar w={120} h={7} mt={5} soft />
          </div>
          <L size={11} weight={600} c={W.ink}>Karte</L>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <Icon s={20} />
          <div style={{ flex: 1 }}>
            <Bar w={130} h={9} />
            <Bar w={90} h={7} mt={5} soft />
          </div>
        </div>
      </div>

      <Hr />

      <div style={{ padding: '8px 16px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Bar w={140} h={11} />
        <Lines widths={[330, 320, 290, 260, 200]} gap={5} h={7} />
      </div>

      <Hr />

      <div style={{ padding: '8px 16px 16px' }}>
        <Bar w={170} h={11} mb={12} />
        <div style={{ display: 'flex', gap: -6, alignItems: 'center' }}>
          {[0,1,2,3,4].map(i => (
            <div key={i} style={{
              width: 30, height: 30, borderRadius: 15,
              border: `1.4px solid ${W.line}`, background: '#fff',
              marginLeft: i === 0 ? 0 : -8,
            }} />
          ))}
          <div style={{ marginLeft: 8 }}><L size={11}>+ 12 weitere</L></div>
        </div>
      </div>

      <div style={{ height: 100 }} />

      <div style={{
        position: 'sticky', bottom: 0, padding: '12px 16px 16px',
        background: '#fff', borderTop: `1px solid ${W.lineSoft}`,
        display: 'flex', gap: 10,
      }}>
        <Box w={44} h={44} p={0} r={8}>
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon s={18} />
          </div>
        </Box>
        <div style={{ flex: 1 }}><Btn primary>Teilnehmen</Btn></div>
      </div>
    </Screen>
  );
}

// ─── 11 Chat mit Übersetzung ────────────────────────────────
function S11_Chat() {
  // chat bubble helper
  const Bubble = ({ own = false, widths = [120, 80], translated = false }) => (
    <div style={{ display: 'flex', justifyContent: own ? 'flex-end' : 'flex-start' }}>
      <div style={{ maxWidth: '78%' }}>
        <div style={{
          padding: '10px 12px', borderRadius: 14,
          border: `1px solid ${W.line}`,
          background: own ? W.fill : '#fff',
        }}>
          <Lines widths={widths} gap={5} h={6} />
          {translated && (
            <div style={{ marginTop: 8, paddingTop: 8, borderTop: `1px dashed ${W.dash}` }}>
              <L size={9} mb={4}>Übersetzt aus EN</L>
              <Lines widths={widths.map(w => Math.max(20, w - 10))} gap={5} h={6} />
            </div>
          )}
        </div>
        <L size={9} mt={4}>09:42</L>
      </div>
    </div>
  );

  return (
    <Screen pad={false}>
      {/* Custom header with avatar + name */}
      <div style={{ padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: `1px solid ${W.lineSoft}` }}>
        <svg width="18" height="18" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <div style={{ width: 32, height: 32, borderRadius: 16, border: `1.2px solid ${W.line}` }} />
        <div style={{ flex: 1 }}>
          <Bar w={120} h={9} />
          <div style={{ display: 'flex', gap: 5, alignItems: 'center', marginTop: 4 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: W.ink }} />
            <L size={9}>Online · Verifiziert</L>
          </div>
        </div>
        <Icon s={20} />
        <Icon s={20} />
      </div>

      {/* Translate toggle banner */}
      <div style={{ padding: '10px 16px', background: W.fillSoft, borderBottom: `1px solid ${W.lineSoft}`, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icon s={16} shape="circle" />
        <div style={{ flex: 1 }}>
          <L size={11} weight={600} c={W.ink}>Übersetzung aktiv · EN → DE</L>
          <Bar w={150} h={6} mt={4} soft />
        </div>
        {/* Toggle */}
        <div style={{ width: 36, height: 20, borderRadius: 10, border: `1.2px solid ${W.ink}`, background: W.fill, position: 'relative' }}>
          <div style={{ position: 'absolute', right: 2, top: 2, width: 14, height: 14, borderRadius: 7, background: W.ink }} />
        </div>
      </div>

      <div style={{ flex: 1, padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 12, overflow: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <Chip>Heute</Chip>
        </div>
        <Bubble widths={[140, 90]} translated />
        <Bubble own widths={[120, 70]} />
        <Bubble widths={[170, 130, 80]} translated />
        <Bubble own widths={[100]} />
        <Bubble widths={[80]} translated />
      </div>

      {/* Composer */}
      <div style={{ padding: '8px 12px 14px', borderTop: `1px solid ${W.lineSoft}`, display: 'flex', gap: 8, alignItems: 'center' }}>
        <Icon s={26} />
        <Box p={0} r={20} h={40} style={{ flex: 1 }}>
          <div style={{ height: '100%', padding: '0 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Bar w={120} h={7} soft />
            <Icon s={18} />
          </div>
        </Box>
        <div style={{ width: 40, height: 40, borderRadius: 20, border: `1.4px solid ${W.ink}`, background: W.fill, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="16" height="16" viewBox="0 0 16 16"><path d="M2 8 L14 2 L10 14 L8 9 L2 8z" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinejoin="round"/></svg>
        </div>
      </div>
    </Screen>
  );
}

// ─── 12 Profil ──────────────────────────────────────────────
function S12_Profile() {
  // setting row helper
  const Row = ({ icon = true, chevron = true, sub = false, toggle = false }) => (
    <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${W.lineSoft}` }}>
      {icon && <Icon s={20} />}
      <div style={{ flex: 1 }}>
        <Bar w={130} h={9} />
        {sub && <Bar w={90} h={6} mt={5} soft />}
      </div>
      {toggle ? (
        <div style={{ width: 36, height: 20, borderRadius: 10, border: `1.2px solid ${W.line}`, background: '#fff', position: 'relative' }}>
          <div style={{ position: 'absolute', left: 2, top: 2, width: 14, height: 14, borderRadius: 7, background: W.line }} />
        </div>
      ) : chevron && (
        <svg width="8" height="12" viewBox="0 0 8 12"><path d="M1 1 L6 6 L1 11" stroke={W.line} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
      )}
    </div>
  );

  return (
    <Screen pad={false} scroll={false}>
      <div style={{ padding: '8px 16px 10px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <Bar w={70} h={14} />
        <Icon s={22} />
      </div>

      <Body>
        {/* Header card */}
        <div style={{ padding: '8px 16px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 80, height: 80, borderRadius: 40, border: `1.4px solid ${W.line}` }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Bar w={130} h={12} />
            <Box w={62} h={18} p={0} r={9}>
              <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <L size={9} weight={600}>Verifiziert</L>
              </div>
            </Box>
          </div>
          <Bar w={90} h={7} soft />
          <div style={{ display: 'flex', gap: 22, marginTop: 6 }}>
            {['Anlässe', 'Inserate', 'Bewertungen'].map(t => (
              <div key={t} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
                <Bar w={26} h={14} />
                <L size={10}>{t}</L>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 8, width: '100%' }}>
            <div style={{ flex: 1 }}><Btn>Bearbeiten</Btn></div>
            <div style={{ flex: 1 }}><Btn>Teilen</Btn></div>
          </div>
        </div>

        {/* Kompetenzen */}
        <div style={{ padding: '4px 16px 12px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
            <Bar w={110} h={10} />
            <L size={11} weight={600} c={W.ink}>+ Hinzufügen</L>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <Chip>Kompetenz 1</Chip>
            <Chip>Kompetenz 2</Chip>
            <Chip>Kompetenz 3</Chip>
            <Chip>+ 2</Chip>
          </div>
        </div>

        <Hr mt={4} mb={0} soft={false} />

        <L size={10} c={W.ph} mt={14} mb={4}>
          <div style={{ padding: '0 16px' }}>EINSTELLUNGEN</div>
        </L>

        <Row toggle />
        <Row />
        <Row sub />
        <Row toggle />

        <L size={10} c={W.ph} mt={14} mb={4}>
          <div style={{ padding: '0 16px' }}>BARRIEREFREIHEIT</div>
        </L>

        <Row toggle />
        <Row toggle />
        <Row />

        <L size={10} c={W.ph} mt={14} mb={4}>
          <div style={{ padding: '0 16px' }}>RECHTLICHES</div>
        </L>

        <Row />
        <Row />

        <div style={{ padding: '20px 16px 16px' }}>
          <Btn>Abmelden</Btn>
        </div>

        <div style={{ height: 20 }} />
      </Body>

      <TabBar active={4} />
    </Screen>
  );
}

Object.assign(window, { S10_EventDetail, S11_Chat, S12_Profile });
