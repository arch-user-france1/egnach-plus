// Egnach Plus — Login Screen (Bestandskunden)
// Methoden: Passkey (primär), E-Mail/Passwort (sekundär)
// Hilfen: Passwort vergessen, Support kontaktieren

function S_Login() {
  // small fingerprint / passkey glyph (schematic — concentric arcs + dot)
  const PasskeyGlyph = ({ s = 22 }) => (
    <svg width={s} height={s} viewBox="0 0 22 22" fill="none">
      <circle cx="11" cy="9" r="3.2" stroke={W.ink} strokeWidth="1.4" />
      <path d="M5 18 c1.5 -3 3.5 -4 6 -4 s4.5 1 6 4" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round" />
      <path d="M3 11 a8 8 0 0 1 16 0" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );

  return (
    <Screen scroll={false}>
      <TopBar action={false} />

      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '20px 24px 16px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Heading */}
        <div>
          <Bar w={130} h={14} mb={8} />
          <Lines widths={[230, 180]} gap={5} h={7} />
        </div>

        {/* Passkey — primary method */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <L size={10} weight={600} c={W.ink}>Empfohlen</L>
          <div style={{
            border: `1.4px solid ${W.ink}`, borderRadius: 10, background: W.fill,
            padding: '14px 14px', display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              border: `1.2px solid ${W.ink}`, background: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <PasskeyGlyph s={22} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Bar w={150} h={9} />
              <Bar w={190} h={7} mt={6} soft />
            </div>
            <svg width="10" height="14" viewBox="0 0 10 14">
              <path d="M2 1 L8 7 L2 13" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <L size={10}>Face ID · Touch ID · Geräte-PIN</L>
        </div>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, height: 1, background: W.lineSoft }} />
          <L size={10}>oder mit E-Mail</L>
          <div style={{ flex: 1, height: 1, background: W.lineSoft }} />
        </div>

        {/* E-Mail / Passwort */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Field label="E-Mail-Adresse" hint="name@example.ch" />
          <div>
            <Field label="Passwort" />
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 6 }}>
              <div style={{
                fontFamily: W.font, fontSize: 11, color: W.ink, fontWeight: 500,
                textDecoration: 'underline', textUnderlineOffset: 3,
              }}>Passwort vergessen?</div>
            </div>
          </div>

          {/* Angemeldet bleiben */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 2 }}>
            <Box w={18} h={18} p={0} r={3} />
            <Bar w={130} h={7} soft />
          </div>
        </div>

        <Btn>Anmelden</Btn>

        {/* Hinweis */}
        <div style={{
          background: W.fillSoft, border: `1px solid ${W.lineSoft}`,
          borderRadius: 6, padding: 12, display: 'flex', gap: 10,
        }}>
          <Icon s={18} shape="circle" />
          <div style={{ flex: 1 }}>
            <L size={11} weight={600} c={W.ink} mb={4}>Probleme beim Anmelden?</L>
            <Lines widths={[200, 150]} gap={4} h={6} />
          </div>
        </div>
      </div>

      {/* Footer: Support + Registrieren */}
      <div style={{
        padding: '12px 24px 24px', borderTop: `1px solid ${W.lineSoft}`,
        background: '#fff', flexShrink: 0,
        display: 'flex', flexDirection: 'column', gap: 12,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <Icon s={16} shape="circle" />
          <div style={{
            fontFamily: W.font, fontSize: 12, color: W.ink, fontWeight: 500,
            textDecoration: 'underline', textUnderlineOffset: 3,
          }}>Support kontaktieren</div>
        </div>
        <div style={{ height: 1, background: W.lineSoft }} />
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
          <Bar w={100} h={7} soft />
          <Bar w={60} h={7} />
        </div>
      </div>
    </Screen>
  );
}

Object.assign(window, { S_Login });
