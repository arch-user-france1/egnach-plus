// Egnach Plus — Wireframes
// Greyscale, no images, no concrete content. Pure structural sketches.

const W = {
  ink: '#2a2a2a',
  line: '#9a9a9a',
  lineSoft: '#c8c8c8',
  fill: '#ececec',
  fillSoft: '#f4f4f4',
  dash: '#b5b5b5',
  ph: '#7a7a7a',
  font: 'Inter, -apple-system, system-ui, sans-serif',
};

// ─── Primitives ─────────────────────────────────────────────

// horizontal "text" line of given width (placeholder for copy)
function Bar({ w = 100, h = 8, mt = 0, mb = 0, soft = false }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 2,
      background: soft ? W.lineSoft : W.line,
      marginTop: mt, marginBottom: mb, flexShrink: 0,
    }} />
  );
}

// stack of bars, simulating paragraphs
function Lines({ widths = [100, 80, 60], gap = 6, h = 7 }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap }}>
      {widths.map((w, i) => <Bar key={i} w={w} h={h} soft />)}
    </div>
  );
}

// "image" placeholder: rect with two crossing diagonals
function ImgBox({ w = '100%', h = 120, r = 6, style }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: r,
      border: `1px solid ${W.line}`, background: W.fillSoft,
      position: 'relative', ...style,
    }}>
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none"
           style={{ position: 'absolute', inset: 0 }}>
        <line x1="0" y1="0" x2="100" y2="100" stroke={W.line} strokeWidth="0.4" vectorEffect="non-scaling-stroke"/>
        <line x1="100" y1="0" x2="0" y2="100" stroke={W.line} strokeWidth="0.4" vectorEffect="non-scaling-stroke"/>
      </svg>
    </div>
  );
}

// small square icon placeholder (a circle inside a square)
function Icon({ s = 22, shape = 'square' }) {
  if (shape === 'circle') {
    return <div style={{ width: s, height: s, borderRadius: '50%', border: `1.2px solid ${W.line}` }} />;
  }
  return <div style={{
    width: s, height: s, borderRadius: 4,
    border: `1.2px solid ${W.line}`,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  }}>
    <div style={{ width: s * 0.45, height: s * 0.45, borderRadius: '50%', border: `1.2px solid ${W.line}` }} />
  </div>;
}

// generic rectangular box (button/container)
function Box({ children, h, w, p = 10, r = 6, dashed = false, fill, style }) {
  return (
    <div style={{
      width: w, height: h, padding: p, borderRadius: r,
      border: `1px ${dashed ? 'dashed' : 'solid'} ${dashed ? W.dash : W.line}`,
      background: fill,
      boxSizing: 'border-box',
      ...style,
    }}>{children}</div>
  );
}

// label text (small, grey) — for wireframe annotations / structural names
function L({ children, size = 11, weight = 500, mb = 0, mt = 0, c = W.ph }) {
  return <div style={{
    fontFamily: W.font, fontSize: size, fontWeight: weight,
    color: c, marginBottom: mb, marginTop: mt, letterSpacing: 0.1,
    lineHeight: 1.25,
  }}>{children}</div>;
}

// section divider (horizontal hairline)
function Hr({ mt = 12, mb = 12, soft = true }) {
  return <div style={{
    height: 1, background: soft ? W.lineSoft : W.line,
    marginTop: mt, marginBottom: mb,
  }} />;
}

// pill / chip
function Chip({ children, active = false, w }) {
  return <div style={{
    height: 26, padding: '0 10px', borderRadius: 13,
    border: `1px solid ${W.line}`,
    background: active ? W.fill : 'transparent',
    display: 'inline-flex', alignItems: 'center', gap: 6,
    fontFamily: W.font, fontSize: 11, color: W.ph, flexShrink: 0,
    width: w, justifyContent: w ? 'center' : undefined,
  }}>{children}</div>;
}

// button (rectangle with label)
function Btn({ children, primary = false, w = '100%', h = 40 }) {
  return <div style={{
    width: w, height: h, borderRadius: 8,
    border: `1.4px solid ${primary ? W.ink : W.line}`,
    background: primary ? W.fill : 'transparent',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: W.font, fontSize: 12, fontWeight: primary ? 600 : 500,
    color: W.ink, letterSpacing: 0.2,
  }}>{children}</div>;
}

// form field (label + box + optional required marker + hint)
function Field({ label, required = false, hint, value, err, h = 38 }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{ fontFamily: W.font, fontSize: 11, color: W.ink, fontWeight: 500 }}>{label}</span>
        {required && <span style={{ fontFamily: W.font, fontSize: 11, color: W.ink }}>*</span>}
      </div>
      <div style={{
        height: h, borderRadius: 6,
        border: `1px solid ${err ? W.ink : W.line}`,
        background: '#fff', padding: '0 10px',
        display: 'flex', alignItems: 'center',
        fontFamily: W.font, fontSize: 11, color: W.ph,
      }}>{value || <Bar w={120} h={6} soft />}</div>
      {hint && <span style={{ fontFamily: W.font, fontSize: 10, color: W.ph, fontStyle: 'italic' }}>{hint}</span>}
      {err && <span style={{ fontFamily: W.font, fontSize: 10, color: W.ink, fontWeight: 600 }}>{err}</span>}
    </div>
  );
}

// top app bar (back / title placeholder / action)
function TopBar({ back = true, title = true, action = true }) {
  return (
    <div style={{
      height: 44, padding: '0 12px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: `1px solid ${W.lineSoft}`,
    }}>
      <div style={{ width: 28, display: 'flex', alignItems: 'center' }}>
        {back && <svg width="14" height="14" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
      </div>
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
        {title && <Bar w={110} h={9} />}
      </div>
      <div style={{ width: 28, display: 'flex', justifyContent: 'flex-end' }}>
        {action && <Icon s={20} />}
      </div>
    </div>
  );
}

// bottom tab bar (5 tabs) — active highlighted
function TabBar({ active = 0 }) {
  const labels = ['Start', 'Markt', 'Anlässe', 'Chat', 'Profil'];
  return (
    <div style={{
      height: 64, borderTop: `1px solid ${W.line}`,
      display: 'flex', alignItems: 'flex-start',
      paddingTop: 8, paddingBottom: 12,
      background: '#fff',
    }}>
      {labels.map((lab, i) => (
        <div key={i} style={{
          flex: 1, display: 'flex', flexDirection: 'column',
          alignItems: 'center', gap: 4,
          opacity: i === active ? 1 : 0.55,
        }}>
          <div style={{
            width: 24, height: 24, borderRadius: 5,
            border: `1.4px solid ${W.ink}`,
            background: i === active ? W.fill : 'transparent',
          }} />
          <span style={{ fontFamily: W.font, fontSize: 10, color: W.ink, fontWeight: i === active ? 600 : 400 }}>{lab}</span>
        </div>
      ))}
    </div>
  );
}

// floating action button
function Fab({ bottom = 80, right = 16 }) {
  return <div style={{
    position: 'absolute', bottom, right,
    width: 52, height: 52, borderRadius: 26,
    border: `1.6px solid ${W.ink}`, background: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    boxShadow: '0 4px 10px rgba(0,0,0,0.08)', zIndex: 5,
  }}>
    <svg width="20" height="20" viewBox="0 0 20 20">
      <line x1="10" y1="4" x2="10" y2="16" stroke={W.ink} strokeWidth="1.6" strokeLinecap="round"/>
      <line x1="4" y1="10" x2="16" y2="10" stroke={W.ink} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  </div>;
}

// Screen wrapper that fills the iPhone viewport (under the status bar)
function Screen({ children, pad = true, scroll = true }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      boxSizing: 'border-box',
      background: '#fff', display: 'flex', flexDirection: 'column',
      paddingTop: 54, // clear status bar / dynamic island
      position: 'relative',
      overflow: scroll ? 'auto' : 'hidden',
      fontFamily: W.font,
    }}>
      {children}
    </div>
  );
}

// Scrollable body region — use inside Screen with scroll={false}
// so a sticky TabBar / action bar can sit beneath it.
function Body({ children, p = 0, style }) {
  return (
    <div style={{
      flex: 1, minHeight: 0, overflow: 'auto',
      padding: p, ...style,
    }}>{children}</div>
  );
}

// horizontal scroll row helper
function HRow({ children, gap = 8, px = 16 }) {
  return <div style={{ display: 'flex', gap, padding: `0 ${px}px`, overflow: 'hidden' }}>{children}</div>;
}

Object.assign(window, { W, Bar, Lines, ImgBox, Icon, Box, L, Hr, Chip, Btn, Field, TopBar, TabBar, Fab, Screen, Body, HRow });
