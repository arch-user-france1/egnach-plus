// Egnach Plus — Screens 06-12

// ─── 06 Marktplatz (Liste) ──────────────────────────────────
function S06_Marketplace() {
  return (
    <Screen pad={false} scroll={false}>
      <div style={{ padding: '8px 16px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <Bar w={110} h={14} />
        <Icon s={22} />
      </div>

      <Body>
        <div style={{ padding: '0 16px 12px' }}>
          <Box p={0} r={20} h={36}>
            <div style={{ height: '100%', padding: '0 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <Icon s={16} />
              <Bar w={130} h={8} soft />
            </div>
          </Box>
        </div>

        <HRow>
          <Chip active>Alle</Chip>
          <Chip>Leihen</Chip>
          <Chip>Dienste</Chip>
          <Chip>Tausch</Chip>
          <Chip>Jobs</Chip>
        </HRow>

        <div style={{ padding: '12px 16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Bar w={80} h={8} soft />
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <Icon s={16} />
            <Bar w={40} h={7} soft />
          </div>
        </div>

        <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[0,1,2,3].map(i => (
            <Box key={i} p={10}>
              <div style={{ display: 'flex', gap: 12 }}>
                <ImgBox w={72} h={72} />
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
                  <Bar w={150} h={10} />
                  <Bar w={110} h={7} soft />
                  <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                    <Chip>Kategorie</Chip>
                    <Chip>Quartier</Chip>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
                    <Bar w={50} h={9} />
                    <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                      <Icon s={12} shape="circle" />
                      <Bar w={40} h={6} soft />
                    </div>
                  </div>
                </div>
              </div>
            </Box>
          ))}
        </div>

        <div style={{ height: 20 }} />
      </Body>

      <Fab />
      <TabBar active={1} />
    </Screen>
  );
}

// ─── 07 Inserat Detail ──────────────────────────────────────
function S07_ListingDetail() {
  return (
    <Screen pad={false} scroll>
      <div style={{ padding: '8px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <svg width="20" height="20" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <div style={{ display: 'flex', gap: 12 }}>
          <Icon s={20} />
          <Icon s={20} />
        </div>
      </div>

      <div style={{ padding: '0 16px' }}>
        <ImgBox h={210} />
        <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 8 }}>
          <div style={{ width: 16, height: 5, borderRadius: 3, background: W.ink }} />
          <div style={{ width: 5, height: 5, borderRadius: 3, background: W.lineSoft }} />
          <div style={{ width: 5, height: 5, borderRadius: 3, background: W.lineSoft }} />
          <div style={{ width: 5, height: 5, borderRadius: 3, background: W.lineSoft }} />
        </div>
      </div>

      <div style={{ padding: '16px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Bar w={220} h={14} />
        <div style={{ display: 'flex', gap: 6 }}>
          <Chip>Kategorie</Chip>
          <Chip>Quartier</Chip>
        </div>
        <Bar w={100} h={16} mt={4} />
      </div>

      <Hr mt={4} mb={4} />

      <div style={{ padding: '8px 16px 16px', display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ width: 44, height: 44, borderRadius: 22, border: `1.2px solid ${W.line}` }} />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Bar w={110} h={9} />
            <Box w={50} h={16} p={0} r={8}>
              <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <L size={9} weight={600}>Verifiziert</L>
              </div>
            </Box>
          </div>
          <Bar w={80} h={7} mt={6} soft />
        </div>
        <Bar w={36} h={8} soft />
      </div>

      <Hr mt={0} mb={0} />

      <div style={{ padding: '16px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Bar w={100} h={11} />
        <Lines widths={[330, 320, 310, 300, 260, 200]} gap={5} h={7} />
      </div>

      <Hr />

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Bar w={120} h={11} />
        <div style={{ display: 'flex', gap: 16 }}>
          <div>
            <Bar w={36} h={20} />
            <Bar w={56} h={7} mt={6} soft />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4, justifyContent: 'center' }}>
            <Bar w={140} h={6} soft />
            <Bar w={100} h={6} soft />
            <Bar w={120} h={6} soft />
          </div>
        </div>
      </div>

      <div style={{ height: 100 }} />

      <div style={{
        position: 'sticky', bottom: 0, padding: '12px 16px 16px',
        background: '#fff', borderTop: `1px solid ${W.lineSoft}`,
        display: 'flex', gap: 10,
      }}>
        <Box w={44} h={44} p={0} r={8}>
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon s={18} />
          </div>
        </Box>
        <div style={{ flex: 1 }}><Btn primary>Kontaktieren</Btn></div>
      </div>
    </Screen>
  );
}

// ─── 08 Inserat erstellen ───────────────────────────────────
function S08_CreateListing() {
  return (
    <Screen pad={false} scroll>
      <div style={{ height: 54 }} />
      <TopBar />
      <div style={{ padding: '16px 20px 120px', display: 'flex', flexDirection: 'column', gap: 16 }}>

        <L size={10}>Schritt 1 von 3 · Was bietest du an?</L>
        <div style={{ display: 'flex', gap: 6 }}>
          <div style={{ flex: 1, height: 4, borderRadius: 2, background: W.ink }} />
          <div style={{ flex: 1, height: 4, borderRadius: 2, background: W.lineSoft }} />
          <div style={{ flex: 1, height: 4, borderRadius: 2, background: W.lineSoft }} />
        </div>

        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 6 }}>
            <L size={11} weight={500} c={W.ink}>Art des Inserats</L>
            <L size={11} c={W.ink}>*</L>
            <div style={{ flex: 1 }} />
            <Icon s={14} shape="circle" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <Box p={10} fill={W.fill}>
              <Icon s={20} />
              <Bar w={60} h={8} mt={8} />
            </Box>
            <Box p={10}><Icon s={20} /><Bar w={60} h={8} mt={8} /></Box>
            <Box p={10}><Icon s={20} /><Bar w={60} h={8} mt={8} /></Box>
            <Box p={10}><Icon s={20} /><Bar w={60} h={8} mt={8} /></Box>
          </div>
        </div>

        <Field label="Titel" required hint="Kurz und aussagekräftig, max. 60 Zeichen" />

        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
            <L size={11} weight={500} c={W.ink}>Beschreibung</L>
            <L size={11} c={W.ink}>*</L>
            <div style={{ flex: 1 }} />
            <L size={9}>0 / 500</L>
          </div>
          <Box h={84} p={10}>
            <Lines widths={[200, 160, 100]} gap={6} h={6} />
          </Box>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="Preis" required hint="CHF / Std." />
          <Field label="Verfügbar ab" required hint="TT.MM.JJJJ" />
        </div>

        <div>
          <L size={11} weight={500} c={W.ink} mb={6}>Fotos hinzufügen</L>
          <div style={{ display: 'flex', gap: 8 }}>
            <Box w={64} h={64} p={0} dashed>
              <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="20" height="20" viewBox="0 0 20 20">
                  <line x1="10" y1="4" x2="10" y2="16" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round"/>
                  <line x1="4" y1="10" x2="16" y2="10" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round"/>
                </svg>
              </div>
            </Box>
            <ImgBox w={64} h={64} />
            <ImgBox w={64} h={64} />
          </div>
          <L size={10} mt={6}>JPG oder PNG, max. 5 MB</L>
        </div>

        <L size={10}>Pflichtfelder sind mit * markiert</L>
      </div>

      {/* Floating action bar — separated from the form */}
      <div style={{
        position: 'sticky', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 16px',
        pointerEvents: 'none',
        marginTop: -100,
      }}>
        <div style={{
          background: '#fff',
          border: `1px solid ${W.lineSoft}`,
          borderRadius: 14,
          padding: 10,
          display: 'flex',
          gap: 10,
          boxShadow: '0 6px 18px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)',
          pointerEvents: 'auto',
        }}>
          <div style={{ flex: 1 }}><Btn>Entwurf speichern</Btn></div>
          <div style={{ flex: 1 }}><Btn primary>Weiter</Btn></div>
        </div>
      </div>
    </Screen>
  );
}

// ─── 09 Anlässe (Liste + Kalender) ──────────────────────────
function S09_Events() {
  return (
    <Screen pad={false} scroll={false}>
      <div style={{ padding: '8px 16px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <Bar w={90} h={14} />
        <Icon s={22} />
      </div>

      <Body>
      {/* Segmented control: Liste / Kalender */}
      <div style={{ padding: '0 16px 12px' }}>
        <Box p={3} r={20} h={32}>
          <div style={{ height: '100%', display: 'flex', gap: 4 }}>
            <div style={{ flex: 1, background: W.fill, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <L size={11} weight={600} c={W.ink}>Liste</L>
            </div>
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <L size={11}>Kalender</L>
            </div>
          </div>
        </Box>
      </div>

      <HRow>
        <Chip active>Diese Woche</Chip>
        <Chip>Alle</Chip>
        <Chip>Familie</Chip>
        <Chip>Sprache</Chip>
        <Chip>Senioren</Chip>
      </HRow>

      <div style={{ padding: '14px 16px 0' }}>
        <L size={10} mb={8}>Donnerstag, 12. Juni</L>
      </div>

      <div style={{ padding: '0 16px 12px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[0,1].map(i => (
          <Box key={i} p={12}>
            <div style={{ display: 'flex', gap: 12 }}>
              <div style={{
                width: 52, borderRight: `1px solid ${W.lineSoft}`,
                paddingRight: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              }}>
                <L size={9}>JUN</L>
                <Bar w={28} h={18} />
                <L size={9}>14:00</L>
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <Bar w={170} h={10} />
                <Bar w={120} h={7} soft />
                <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                  <Chip>Kategorie</Chip>
                  <Chip>Quartier</Chip>
                </div>
              </div>
            </div>
          </Box>
        ))}
      </div>

      <div style={{ padding: '6px 16px 0' }}>
        <L size={10} mb={8}>Samstag, 14. Juni</L>
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Box p={12}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ width: 52, borderRight: `1px solid ${W.lineSoft}`, paddingRight: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              <L size={9}>JUN</L>
              <Bar w={28} h={18} />
              <L size={9}>10:00</L>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <Bar w={150} h={10} />
              <Bar w={140} h={7} soft />
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                <Chip>Kategorie</Chip>
              </div>
            </div>
          </div>
        </Box>
      </div>

      <div style={{ height: 20 }} />
      </Body>
      <Fab />
      <TabBar active={2} />
    </Screen>
  );
}

Object.assign(window, { S06_Marketplace, S07_ListingDetail, S08_CreateListing, S09_Events });
