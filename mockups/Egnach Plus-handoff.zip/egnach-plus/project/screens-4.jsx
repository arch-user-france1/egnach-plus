// Egnach Plus — Screen 13: Verfügbarkeit verwalten (Kalender)

function S13_Availability() {
  // Month calendar grid — 6 weeks × 7 days
  const days = [];
  // First 2 cells empty (month starts on Wed)
  for (let i = 0; i < 2; i++) days.push({ empty: true });
  for (let d = 1; d <= 30; d++) days.push({ d });
  while (days.length < 42) days.push({ empty: true, trail: true });

  // states: free | partial | booked | selected
  const states = {
    3: 'partial', 4: 'partial', 7: 'booked', 10: 'booked',
    12: 'selected', 13: 'selected', 14: 'selected',
    18: 'partial', 21: 'booked', 25: 'partial',
  };

  const dayCell = (cell, idx) => {
    if (cell.empty) {
      return <div key={idx} style={{ aspectRatio: '1', }} />;
    }
    const s = states[cell.d];
    const isSel = s === 'selected';
    const isBooked = s === 'booked';
    const isPartial = s === 'partial';
    return (
      <div key={idx} style={{
        aspectRatio: '1',
        borderRadius: 6,
        border: `1px solid ${isSel ? W.ink : W.lineSoft}`,
        background: isSel ? W.fill : isBooked ? '#ddd' : 'transparent',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        position: 'relative',
        opacity: isBooked ? 0.55 : 1,
      }}>
        <span style={{
          fontFamily: W.font, fontSize: 12,
          fontWeight: isSel ? 700 : 500,
          color: W.ink,
        }}>{cell.d}</span>
        {isPartial && (
          <div style={{
            position: 'absolute', bottom: 4,
            display: 'flex', gap: 2,
          }}>
            <div style={{ width: 3, height: 3, borderRadius: 2, background: W.ink }} />
            <div style={{ width: 3, height: 3, borderRadius: 2, background: W.ink }} />
          </div>
        )}
        {isBooked && (
          <div style={{
            position: 'absolute', bottom: 4,
            width: 12, height: 2, background: W.ink,
          }} />
        )}
      </div>
    );
  };

  // time slot row
  const Slot = ({ from, to, booked = false }) => (
    <div style={{
      padding: '10px 12px',
      border: `1px solid ${booked ? W.line : W.lineSoft}`,
      borderRadius: 6,
      background: booked ? W.fillSoft : '#fff',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <Icon s={16} />
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', gap: 4, alignItems: 'baseline' }}>
          <span style={{ fontFamily: W.font, fontSize: 12, fontWeight: 600, color: W.ink }}>{from}</span>
          <span style={{ fontFamily: W.font, fontSize: 11, color: W.ph }}>–</span>
          <span style={{ fontFamily: W.font, fontSize: 12, fontWeight: 600, color: W.ink }}>{to}</span>
        </div>
        <Bar w={booked ? 130 : 90} h={6} mt={4} soft />
      </div>
      {booked ? (
        <Box w={56} h={20} p={0} r={10}>
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <L size={9} weight={600}>Gebucht</L>
          </div>
        </Box>
      ) : (
        <Icon s={16} />
      )}
    </div>
  );

  return (
    <Screen pad={false} scroll={false}>
      <TopBar />

      <Body>
      <div style={{ padding: '14px 16px 8px' }}>
        <Bar w={170} h={13} mb={6} />
        <Bar w={210} h={7} soft />
      </div>

      {/* Segmented: Monat / Woche / Tag */}
      <div style={{ padding: '8px 16px 6px' }}>
        <Box p={3} r={20} h={32}>
          <div style={{ height: '100%', display: 'flex', gap: 4 }}>
            <div style={{ flex: 1, background: W.fill, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <L size={11} weight={600} c={W.ink}>Monat</L>
            </div>
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><L size={11}>Woche</L></div>
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><L size={11}>Tag</L></div>
          </div>
        </Box>
      </div>

      {/* Month header with prev/next */}
      <div style={{ padding: '12px 16px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <svg width="14" height="14" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <span style={{ fontFamily: W.font, fontSize: 13, fontWeight: 600, color: W.ink }}>Juni</span>
          <span style={{ fontFamily: W.font, fontSize: 12, color: W.ph }}>2026</span>
        </div>
        <svg width="14" height="14" viewBox="0 0 14 14"><path d="M5 2 L10 7 L5 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </div>

      {/* Weekday header */}
      <div style={{
        padding: '0 16px',
        display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4,
        marginBottom: 6,
      }}>
        {['M','D','M','D','F','S','S'].map((d, i) => (
          <div key={i} style={{
            textAlign: 'center',
            fontFamily: W.font, fontSize: 10, fontWeight: 500,
            color: W.ph,
          }}>{d}</div>
        ))}
      </div>

      {/* Days grid */}
      <div style={{
        padding: '0 16px',
        display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4,
      }}>
        {days.map(dayCell)}
      </div>

      {/* Legend */}
      <div style={{
        padding: '14px 16px 8px',
        display: 'flex', gap: 14, flexWrap: 'wrap',
      }}>
        {[
          { label: 'Frei', sw: { border: `1px solid ${W.lineSoft}`, background: 'transparent' } },
          { label: 'Teilweise', sw: { border: `1px solid ${W.lineSoft}` }, dot: true },
          { label: 'Gebucht', sw: { background: '#ddd', border: `1px solid ${W.lineSoft}` } },
          { label: 'Auswahl', sw: { background: W.fill, border: `1px solid ${W.ink}` } },
        ].map((it, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 14, height: 14, borderRadius: 4, ...it.sw, position: 'relative' }}>
              {it.dot && <div style={{ position: 'absolute', bottom: 2, left: '50%', transform: 'translateX(-50%)', width: 3, height: 3, borderRadius: 2, background: W.ink }} />}
            </div>
            <span style={{ fontFamily: W.font, fontSize: 10, color: W.ph }}>{it.label}</span>
          </div>
        ))}
      </div>

      <Hr mt={8} mb={0} />

      {/* Selected date + add slot */}
      <div style={{ padding: '14px 16px 8px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <span style={{ fontFamily: W.font, fontSize: 13, fontWeight: 600, color: W.ink }}>Sa, 13. Juni</span>
          <Bar w={120} h={6} mt={6} soft />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <svg width="14" height="14" viewBox="0 0 14 14">
            <line x1="7" y1="2" x2="7" y2="12" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round"/>
            <line x1="2" y1="7" x2="12" y2="7" stroke={W.ink} strokeWidth="1.4" strokeLinecap="round"/>
          </svg>
          <L size={11} weight={600} c={W.ink}>Zeitfenster</L>
        </div>
      </div>

      <div style={{ padding: '0 16px 8px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Slot from="09:00" to="11:00" />
        <Slot from="13:30" to="15:00" booked />
        <Slot from="16:00" to="18:00" />
      </div>

      {/* New slot — dashed form */}
      <div style={{ padding: '4px 16px 12px' }}>
        <Box dashed p={12} r={6}>
          <L size={11} weight={600} c={W.ink} mb={8}>Neues Zeitfenster</L>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label="Von" required hint="HH:MM" h={34} />
            <Field label="Bis" required hint="HH:MM" h={34} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 10, alignItems: 'center' }}>
            <Box w={18} h={18} p={0} r={3} />
            <L size={10}>Wöchentlich wiederholen</L>
          </div>
        </Box>
      </div>

      {/* Help banner */}
      <div style={{ padding: '0 16px 12px' }}>
        <div style={{
          background: W.fillSoft, border: `1px solid ${W.lineSoft}`,
          borderRadius: 6, padding: 12, display: 'flex', gap: 10,
        }}>
          <Icon s={18} shape="circle" />
          <div style={{ flex: 1 }}>
            <L size={11} weight={600} c={W.ink} mb={4}>Hinweis</L>
            <Lines widths={[210, 180, 130]} gap={4} h={6} />
          </div>
        </div>
      </div>

      <Hr mt={0} mb={0} />

      </Body>

      {/* Floating action bar — separated from form, sits above TabBar */}
      <div style={{ padding: '10px 16px 10px', background: 'transparent', flexShrink: 0 }}>
        <div style={{
          background: '#fff',
          border: `1px solid ${W.lineSoft}`,
          borderRadius: 14,
          padding: 10,
          display: 'flex',
          gap: 10,
          boxShadow: '0 6px 18px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)',
        }}>
          <div style={{ flex: 1 }}><Btn>Verwerfen</Btn></div>
          <div style={{ flex: 1 }}><Btn primary>Speichern</Btn></div>
        </div>
      </div>

      <TabBar active={4} />
    </Screen>
  );
}

Object.assign(window, { S13_Availability });
