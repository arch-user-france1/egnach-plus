// Egnach Plus — Screen wireframes (12 screens)

// ─── 01 Splash + Sprache ────────────────────────────────────
function S01_Splash() {
  return (
    <Screen scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, padding: '0 32px', minHeight: 0 }}>
        <div style={{ width: 84, height: 84, borderRadius: 18, border: `1.4px solid ${W.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <L size={10}>LOGO</L>
        </div>
        <Bar w={170} h={14} />
        <Bar w={130} h={9} soft />
      </div>
      <div style={{ padding: '16px 24px 28px', display: 'flex', flexDirection: 'column', gap: 12, borderTop: `1px solid ${W.lineSoft}`, background: '#fff', flexShrink: 0 }}>
        <L size={10} mb={2}>Sprache · Language · Lingua</L>
        <Box p={0} r={8}>
          <div style={{ height: 42, padding: '0 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Bar w={70} h={9} />
            <svg width="12" height="8" viewBox="0 0 12 8"><path d="M1 1l5 5 5-5" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </div>
        </Box>
        <Btn primary>Weiter</Btn>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 14, marginTop: 2 }}>
          <Bar w={70} h={7} soft />
          <Bar w={70} h={7} soft />
        </div>
      </div>
    </Screen>
  );
}

// ─── 02 Onboarding (1 of 3) ─────────────────────────────────
function S02_Onboarding() {
  return (
    <Screen scroll={false}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 16px', flexShrink: 0 }}>
        <L size={11} weight={500}>Überspringen</L>
      </div>
      <div style={{ flex: 1, padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 20, overflow: 'auto', minHeight: 0 }}>
        <ImgBox h={200} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Bar w={220} h={14} />
          <Bar w={180} h={9} soft />
          <Lines widths={[260, 240, 200]} gap={6} />
        </div>
      </div>
      <div style={{ padding: '14px 24px 28px', display: 'flex', flexDirection: 'column', gap: 14, borderTop: `1px solid ${W.lineSoft}`, background: '#fff', flexShrink: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
          <div style={{ width: 18, height: 6, borderRadius: 3, background: W.ink }} />
          <div style={{ width: 6, height: 6, borderRadius: 3, background: W.lineSoft }} />
          <div style={{ width: 6, height: 6, borderRadius: 3, background: W.lineSoft }} />
        </div>
        <Btn primary>Weiter</Btn>
      </div>
    </Screen>
  );
}

// ─── 03 Registrierung (Pflichtfelder + Hinweise) ────────────
function S03_Register() {
  return (
    <Screen scroll={false}>
      <TopBar action={false} />
      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '16px 20px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <Bar w={150} h={14} mb={6} />
          <Bar w={210} h={8} soft />
          <L size={10} mt={8}>Pflichtfelder sind mit * markiert</L>
        </div>
        <Field label="Vorname" required hint="z. B. Anna" />
        <Field label="Nachname" required hint="z. B. Müller" />
        <Field label="E-Mail-Adresse" required hint="name@example.ch" />
        <Field label="Telefonnummer" required hint="+41 79 123 45 67" />
        <Field label="Geburtsdatum" required hint="TT.MM.JJJJ" />
        <Field label="Adresse / Quartier" required hint="Strasse Nr., Egnach" />
        <Field label="Passwort" required hint="Mind. 8 Zeichen, 1 Zahl" />
        <Field label="Passwort bestätigen" required err="Passwörter stimmen nicht überein" />
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginTop: 4 }}>
          <Box w={18} h={18} p={0} r={3} />
          <div style={{ flex: 1 }}>
            <Lines widths={[240, 200]} gap={4} h={7} />
          </div>
        </div>
      </div>
      <div style={{ padding: '12px 20px 24px', borderTop: `1px solid ${W.lineSoft}`, background: '#fff', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn primary>Konto erstellen</Btn>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
          <Bar w={80} h={7} soft />
          <Bar w={50} h={7} />
        </div>
      </div>
    </Screen>
  );
}

// ─── 04 Identitätsverifikation ──────────────────────────────
function S04_Verify() {
  // Anforderungs-Checkliste (was geprüft wird)
  const CheckItem = ({ done = false }) => (
    <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
      <div style={{
        width: 18, height: 18, borderRadius: 9,
        border: `1.4px solid ${done ? W.ink : W.line}`,
        background: done ? W.fill : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {done && <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5 L4.2 7 L8 3" stroke={W.ink} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
      </div>
      <Bar w={done ? 170 : 200} h={7} soft={!done} />
    </div>
  );

  return (
    <Screen scroll={false}>
      <TopBar action={false} />
      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '18px 24px 18px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <Bar w={170} h={14} mb={8} />
          <Lines widths={[260, 240, 180]} gap={5} h={7} />
        </div>

        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ width: 26, height: 26, borderRadius: 13, border: `1.4px solid ${W.ink}`, background: W.fill, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <L size={11} weight={700} c={W.ink}>1</L>
          </div>
          <div style={{ flex: 1, height: 1, background: W.lineSoft }} />
          <div style={{ width: 26, height: 26, borderRadius: 13, border: `1.4px solid ${W.line}` }}><div style={{display:'flex',justifyContent:'center',alignItems:'center',height:'100%'}}><L size={11}>2</L></div></div>
          <div style={{ flex: 1, height: 1, background: W.lineSoft }} />
          <div style={{ width: 26, height: 26, borderRadius: 13, border: `1.4px solid ${W.line}` }}><div style={{display:'flex',justifyContent:'center',alignItems:'center',height:'100%'}}><L size={11}>3</L></div></div>
        </div>

        <Box dashed h={150} p={0}>
          <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <Icon s={28} />
            <Bar w={150} h={8} soft />
            <L size={10}>Vorder- und Rückseite scannen</L>
          </div>
        </Box>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <L size={11} weight={600} c={W.ink}>Was geprüft wird</L>
          <CheckItem done />
          <CheckItem done />
          <CheckItem />
          <CheckItem />
        </div>

        <div style={{ background: W.fillSoft, border: `1px solid ${W.lineSoft}`, borderRadius: 6, padding: 12, display: 'flex', gap: 10 }}>
          <Icon s={18} shape="circle" />
          <div style={{ flex: 1 }}>
            <L size={11} weight={600} c={W.ink} mb={4}>Hinweis</L>
            <Lines widths={[200, 160]} gap={4} h={6} />
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 24px 24px', borderTop: `1px solid ${W.lineSoft}`, background: '#fff', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn primary>Ausweis fotografieren</Btn>
        <Btn>Später erledigen</Btn>
      </div>
    </Screen>
  );
}

// ─── 05 Home / Feed ─────────────────────────────────────────
function S05_Home() {
  return (
    <Screen pad={false} scroll={false}>
      <div style={{ padding: '8px 16px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <L size={10}>Guten Tag</L>
          <Bar w={120} h={12} mt={4} />
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Icon s={24} />
          <Icon s={24} shape="circle" />
        </div>
      </div>

      <Body>
        <div style={{ padding: '0 16px 10px' }}>
          <Box p={0} r={20} h={36}>
            <div style={{ height: '100%', padding: '0 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <Icon s={16} />
              <Bar w={120} h={8} soft />
            </div>
          </Box>
        </div>

        <HRow>
          <Chip active>Alle Quartiere</Chip>
          <Chip>Egnach Dorf</Chip>
          <Chip>Neuhof</Chip>
          <Chip>Seefeld</Chip>
        </HRow>

        <div style={{ padding: '16px 16px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <Bar w={140} h={11} />
          <Bar w={50} h={8} soft />
        </div>

        <HRow gap={10}>
          {[0,1,2].map(i => (
            <Box key={i} w={170} p={10} style={{ flexShrink: 0 }}>
              <ImgBox h={86} />
              <Bar w={130} h={9} mt={10} />
              <Bar w={90} h={7} mt={6} soft />
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 10 }}>
                <Icon s={14} shape="circle" />
                <Bar w={70} h={7} soft />
              </div>
            </Box>
          ))}
        </HRow>

        <div style={{ padding: '20px 16px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <Bar w={120} h={11} />
          <Bar w={50} h={8} soft />
        </div>

        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[0,1].map(i => (
            <Box key={i} p={12}>
              <div style={{ display: 'flex', gap: 12 }}>
                <ImgBox w={54} h={54} />
                <div style={{ flex: 1 }}>
                  <Bar w={140} h={9} />
                  <Bar w={170} h={7} mt={6} soft />
                  <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <Chip>Sa 14:00</Chip>
                    <Chip>Egnach Dorf</Chip>
                  </div>
                </div>
              </div>
            </Box>
          ))}
        </div>

        <div style={{ height: 20 }} />
      </Body>

      <TabBar active={0} />
    </Screen>
  );
}

Object.assign(window, { S01_Splash, S02_Onboarding, S03_Register, S04_Verify, S05_Home });
