// Egnach Plus — Karte (Veranstaltungen + Jobs, neben Start/Feed)
// Wireframe-Karte: schematische Strassen, Block-Flächen, Seeufer,
// kategorisierte Pins, Filter, Such-/Standort-Header, Bottom-Sheet mit Liste.

function S_Map() {
  // ─── Schematische Karte (SVG) ─────────────────────────────
  // koordinatensystem 0..390 x 0..520; alle linien vector-effect: non-scaling-stroke
  // strassen (graue linien), bloecke (subtile fills), see (links unten)
  const MapBg = () => (
    <svg width="100%" height="100%" viewBox="0 0 390 520" preserveAspectRatio="xMidYMid slice"
         style={{ position: 'absolute', inset: 0, display: 'block' }}>
      {/* Hintergrund */}
      <rect x="0" y="0" width="390" height="520" fill={W.fillSoft} />

      {/* See / Wasserflaeche (unten links) */}
      <path d="M -20 420 Q 80 380 160 410 Q 220 432 200 540 L -20 540 Z"
            fill="#e7e7e2" stroke={W.lineSoft} strokeWidth="1" />
      <path d="M 20 470 Q 60 460 100 472" stroke={W.line} strokeWidth="0.6" fill="none" opacity="0.5" />
      <path d="M 40 490 Q 80 482 120 492" stroke={W.line} strokeWidth="0.6" fill="none" opacity="0.5" />

      {/* Bloecke (sehr dezente Felder) */}
      <rect x="40"  y="60"  width="120" height="80"  fill="#f8f8f4" />
      <rect x="180" y="40"  width="80"  height="60"  fill="#f8f8f4" />
      <rect x="280" y="80"  width="90"  height="100" fill="#f8f8f4" />
      <rect x="60"  y="180" width="80"  height="80"  fill="#f8f8f4" />
      <rect x="180" y="160" width="110" height="80"  fill="#f8f8f4" />
      <rect x="220" y="280" width="120" height="80"  fill="#f8f8f4" />
      <rect x="40"  y="300" width="100" height="60"  fill="#f8f8f4" />

      {/* Strassen — Hauptachsen */}
      <line x1="0"   y1="120" x2="390" y2="140" stroke={W.line} strokeWidth="1.6" />
      <line x1="0"   y1="260" x2="390" y2="270" stroke={W.line} strokeWidth="1.4" />
      <line x1="170" y1="0"   x2="190" y2="520" stroke={W.line} strokeWidth="1.4" />
      <line x1="290" y1="0"   x2="280" y2="420" stroke={W.line} strokeWidth="1.2" />

      {/* Nebenstrassen */}
      <line x1="0"   y1="60"  x2="180" y2="70"  stroke={W.lineSoft} strokeWidth="1" />
      <line x1="0"   y1="200" x2="290" y2="210" stroke={W.lineSoft} strokeWidth="1" />
      <line x1="0"   y1="360" x2="220" y2="370" stroke={W.lineSoft} strokeWidth="1" />
      <line x1="80"  y1="0"   x2="70"  y2="280" stroke={W.lineSoft} strokeWidth="1" />
      <line x1="240" y1="0"   x2="232" y2="430" stroke={W.lineSoft} strokeWidth="1" />
      <line x1="340" y1="0"   x2="346" y2="380" stroke={W.lineSoft} strokeWidth="1" />

      {/* Bahnlinie (gestrichelt, diagonal) */}
      <line x1="0" y1="430" x2="390" y2="380"
            stroke={W.line} strokeWidth="1" strokeDasharray="4 4" />

      {/* Park (rundes feld) */}
      <ellipse cx="120" cy="240" rx="36" ry="22" fill="#eeeee8" stroke={W.lineSoft} strokeWidth="0.8" />

      {/* Quartiernamen — schematisch (kleine labels) */}
      <text x="92"  y="100" fontFamily={W.font} fontSize="9" fill={W.ph} letterSpacing="1">EGNACH DORF</text>
      <text x="310" y="60"  fontFamily={W.font} fontSize="9" fill={W.ph} letterSpacing="1">NEUHOF</text>
      <text x="220" y="320" fontFamily={W.font} fontSize="9" fill={W.ph} letterSpacing="1">SEEFELD</text>
      <text x="50"  y="460" fontFamily={W.font} fontSize="9" fill={W.ph} letterSpacing="1">BODENSEE</text>
    </svg>
  );

  // ─── Pin: rund mit kategorie-glyphe ────────────────────────
  // kind: 'event' (kreis) | 'job' (quadrat) | 'cluster' (zahl)
  const Pin = ({ x, y, kind = 'event', label, active = false }) => {
    const size = 30;
    const glyph = kind === 'event'
      ? <circle cx="0" cy="0" r="4.5" stroke={W.ink} strokeWidth="1.4" fill="#fff" />
      : kind === 'job'
      ? <rect x="-4.5" y="-4.5" width="9" height="9" stroke={W.ink} strokeWidth="1.4" fill="#fff" />
      : null;
    return (
      <div style={{
        position: 'absolute',
        left: x, top: y, transform: 'translate(-50%, -100%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
        filter: active ? 'none' : undefined,
      }}>
        <div style={{
          width: active ? 38 : size, height: active ? 38 : size,
          borderRadius: '50% 50% 50% 0',
          transform: 'rotate(-45deg)',
          background: active ? W.ink : '#fff',
          border: `1.6px solid ${W.ink}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 2px 4px rgba(0,0,0,0.15)',
        }}>
          <svg width="14" height="14" viewBox="-7 -7 14 14" style={{ transform: 'rotate(45deg)' }}>
            {kind === 'cluster' ? (
              <text x="0" y="3" textAnchor="middle" fontFamily={W.font} fontSize="9" fontWeight="700"
                    fill={active ? '#fff' : W.ink}>{label}</text>
            ) : (
              kind === 'event'
                ? <circle cx="0" cy="0" r="3.5" stroke={active ? '#fff' : W.ink} strokeWidth="1.4" fill={active ? W.ink : '#fff'} />
                : <rect x="-3.5" y="-3.5" width="7" height="7" stroke={active ? '#fff' : W.ink} strokeWidth="1.4" fill={active ? W.ink : '#fff'} />
            )}
          </svg>
        </div>
      </div>
    );
  };

  // "Du bist hier" punkt
  const Me = ({ x, y }) => (
    <div style={{
      position: 'absolute', left: x, top: y, transform: 'translate(-50%, -50%)',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 18,
        background: 'rgba(42,42,42,0.10)',
      }} />
      <div style={{
        position: 'absolute', inset: 0, margin: 'auto',
        width: 14, height: 14, borderRadius: 7,
        background: '#fff', border: `2.2px solid ${W.ink}`,
        top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
      }} />
    </div>
  );

  return (
    <Screen pad={false} scroll={false}>
      {/* Search + back header (Overlay-Stil; Karte beginnt ganz oben) */}
      <div style={{ position: 'relative', flex: 1, minHeight: 0, overflow: 'hidden' }}>

        {/* Karten-Layer */}
        <MapBg />

        {/* Pins */}
        <Pin x={110} y={170} kind="event" />
        <Pin x={210} y={150} kind="job" />
        <Pin x={300} y={210} kind="event" active />
        <Pin x={170} y={290} kind="job" />
        <Pin x={250} y={340} kind="cluster" label="5" />
        <Pin x={90}  y={340} kind="event" />
        <Pin x={330} y={130} kind="job" />

        {/* Du bist hier */}
        <Me x={195} y={250} />

        {/* Header: Suche + Filter (floating) */}
        <div style={{
          position: 'absolute', top: 10, left: 12, right: 12,
          display: 'flex', flexDirection: 'column', gap: 8, zIndex: 4,
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: '#fff', border: `1px solid ${W.line}`,
            borderRadius: 22, height: 40, padding: '0 12px',
            boxShadow: '0 2px 6px rgba(0,0,0,0.06)',
          }}>
            <svg width="16" height="14" viewBox="0 0 14 14"><path d="M9 2 L4 7 L9 12" stroke={W.ink} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <div style={{ flex: 1 }}><Bar w={150} h={8} soft /></div>
            <Icon s={18} />
          </div>

          {/* Filter chips */}
          <div style={{ display: 'flex', gap: 6, overflow: 'hidden' }}>
            <Chip active>Alle</Chip>
            <Chip>
              <span style={{
                display: 'inline-block', width: 8, height: 8, borderRadius: 4,
                border: `1.4px solid ${W.ink}`, background: '#fff',
              }} />
              Anlässe
            </Chip>
            <Chip>
              <span style={{
                display: 'inline-block', width: 8, height: 8,
                border: `1.4px solid ${W.ink}`, background: '#fff',
              }} />
              Jobs
            </Chip>
            <Chip>Heute</Chip>
            <Chip>2 km</Chip>
          </div>
        </div>

        {/* Karten-Controls rechts: Standort, Zoom, Schichten */}
        <div style={{
          position: 'absolute', right: 12, top: 110, zIndex: 3,
          display: 'flex', flexDirection: 'column', gap: 8,
        }}>
          {[0,1,2].map(i => (
            <div key={i} style={{
              width: 38, height: 38, borderRadius: 10,
              background: '#fff', border: `1px solid ${W.line}`,
              boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {i === 0 && (
                // crosshair
                <svg width="16" height="16" viewBox="-8 -8 16 16">
                  <circle cx="0" cy="0" r="3" stroke={W.ink} strokeWidth="1.4" fill="none"/>
                  <line x1="-7" y1="0" x2="-4" y2="0" stroke={W.ink} strokeWidth="1.4"/>
                  <line x1="7"  y1="0" x2="4"  y2="0" stroke={W.ink} strokeWidth="1.4"/>
                  <line x1="0" y1="-7" x2="0" y2="-4" stroke={W.ink} strokeWidth="1.4"/>
                  <line x1="0" y1="7"  x2="0" y2="4"  stroke={W.ink} strokeWidth="1.4"/>
                </svg>
              )}
              {i === 1 && (
                <svg width="14" height="14" viewBox="0 0 14 14">
                  <line x1="7" y1="2" x2="7" y2="12" stroke={W.ink} strokeWidth="1.6" strokeLinecap="round"/>
                  <line x1="2" y1="7" x2="12" y2="7" stroke={W.ink} strokeWidth="1.6" strokeLinecap="round"/>
                </svg>
              )}
              {i === 2 && (
                <svg width="14" height="14" viewBox="0 0 14 14">
                  <line x1="2" y1="7" x2="12" y2="7" stroke={W.ink} strokeWidth="1.6" strokeLinecap="round"/>
                </svg>
              )}
            </div>
          ))}
        </div>

        {/* Legende (klein, oben rechts unter Controls — hier links unten) */}
        <div style={{
          position: 'absolute', left: 12, bottom: 12, zIndex: 3,
          background: '#fff', border: `1px solid ${W.lineSoft}`,
          borderRadius: 8, padding: '8px 10px',
          display: 'flex', flexDirection: 'column', gap: 5,
          boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 9, height: 9, borderRadius: 5, border: `1.4px solid ${W.ink}`, background: '#fff' }} />
            <L size={9} c={W.ink}>Anlass</L>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 9, height: 9, border: `1.4px solid ${W.ink}`, background: '#fff' }} />
            <L size={9} c={W.ink}>Job</L>
          </div>
        </div>

        {/* Bottom Sheet — Vorschau-Liste in der Nähe */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 4,
          background: '#fff',
          borderTopLeftRadius: 18, borderTopRightRadius: 18,
          borderTop: `1px solid ${W.line}`,
          boxShadow: '0 -6px 18px rgba(0,0,0,0.08)',
          padding: '8px 14px 14px',
          display: 'flex', flexDirection: 'column', gap: 10,
        }}>
          {/* Drag handle */}
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <div style={{ width: 40, height: 4, borderRadius: 2, background: W.lineSoft }} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <Bar w={130} h={10} />
              <Bar w={90}  h={6} mt={5} soft />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <L size={10}>Liste</L>
              <div style={{
                width: 30, height: 18, borderRadius: 9,
                background: W.fill, border: `1px solid ${W.line}`,
                position: 'relative',
              }}>
                <div style={{
                  position: 'absolute', top: 1, left: 13, width: 14, height: 14,
                  borderRadius: 7, background: W.ink,
                }} />
              </div>
            </div>
          </div>

          {/* Mini-cards (peek) */}
          <div style={{ display: 'flex', gap: 8, overflow: 'hidden' }}>
            {[
              { kind: 'event' },
              { kind: 'job' },
              { kind: 'event' },
            ].map((it, i) => (
              <Box key={i} w={180} p={10} style={{ flexShrink: 0 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 11,
                    border: `1.4px solid ${W.ink}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    {it.kind === 'event'
                      ? <span style={{ width: 7, height: 7, borderRadius: 4, border: `1.4px solid ${W.ink}` }} />
                      : <span style={{ width: 7, height: 7, border: `1.4px solid ${W.ink}` }} />}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <Bar w={100} h={8} />
                    <Bar w={70}  h={6} mt={5} soft />
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                  <Chip>{it.kind === 'event' ? 'Sa 14:00' : 'CHF 28/h'}</Chip>
                  <Chip>0.6 km</Chip>
                </div>
              </Box>
            ))}
          </div>
        </div>
      </div>

      <TabBar active={0} />
    </Screen>
  );
}

Object.assign(window, { S_Map });
